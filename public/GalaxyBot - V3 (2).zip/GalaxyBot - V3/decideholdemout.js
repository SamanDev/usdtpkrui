function decide() {}

decide.getDecide = function (obj, callback) {
    //utils.checkStatus(obj);

    if (obj.state > 0) {
        if (obj.Helper.indexOf("a Royal Flush") > -1 || obj.Helper.indexOf("a Straight Flush") > -1) {
            var _val = decide.actionSend(callback, obj);

            actions.handTen(_val[0], _val[1], _val[2], _val[3], _val[4]);

            return false;
        }
    }

    switch (obj.state) {
        case 0:
            decide.preFlop(obj, callback);
            return false;
            break;
        case 1:
            decide.flop(obj, callback);
            return false;
            break;
        case 2:
            decide.flop(obj, callback);
            return false;
            break;
        case 3:
            decide.flop(obj, callback);
            return false;
            break;
    }
};
decide.GetOtherOdds = function (obj) {
    var oDDs = [];
    var showAllObj = utils.checkShow(obj);
    var showAll = parseInt(showAllObj.showAll + showAllObj.showAllbots);
    var AllBots = showAllObj.players == 0 ? true : false;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Bot == false) {
                var PlayeroDDs = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll, obj);
                for (var prop in PlayeroDDs) {
                    if (PlayeroDDs.hasOwnProperty(prop)) {
                        if (PlayeroDDs[prop].nuts) {
                            var _odds = PlayeroDDs[prop];
                            _odds.player = PlayeroDDs.Player;
                            _odds.handname = prop;
                            oDDs.push(_odds);
                        } else {
                            if (PlayeroDDs["flush"].length > 0 && prop == "flush") {
                                for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
                                    var _odds = PlayeroDDs["flush"][i];
                                    _odds.player = PlayeroDDs.Player;
                                    _odds.handname = "flush";

                                    oDDs.push(_odds);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    //console.log(oDDs.length+showAllObj.showAll+showAllObj.showAllbots);
    return oDDs.length + showAll;
};
function getCenStrOdds(cards, flop, nuts, num, showAll) {
    // console.log(cards, flop,nuts,num)
    if (num >= 14) {
        return [];
    }
    var mynum = nuts > 0 ? nuts : 0;
    var finalCardUser = [];
    var finalCardFlop = [];
    var strOds = [];
    var cardsHigh = utils.SortStraight(cards.concat(flop));
    var cardsHighFlop = utils.SortStraight(cards.concat(flop));

    var isNuts = false;

    var carStr = 0;

    for (var j = 0; j < cardsHigh.length - 1; j++) {
        if (cardsHigh[j] - 4 <= cardsHigh[j + 1]) {
            if (!finalCardUser.includes(cardsHigh[j])) {
                finalCardUser.push(cardsHigh[j]);
            }
            if (!finalCardUser.includes(cardsHigh[j + 1])) {
                finalCardUser.push(cardsHigh[j + 1]);
            }
        }
    }
    for (var j = 0; j < cardsHighFlop.length - 1; j++) {
        if (cardsHighFlop[j] - 4 <= cardsHighFlop[j + 1]) {
            if (!finalCardFlop.includes(cardsHighFlop[j])) {
                finalCardFlop.push(cardsHighFlop[j]);
            }
            if (!finalCardFlop.includes(cardsHighFlop[j + 1])) {
                finalCardFlop.push(cardsHighFlop[j + 1]);
            }
        }
    }
    finalCardFlop.sort(utils.compareNumbers);
    finalCardUser.sort(utils.compareNumbers);

    var start = cardsHighFlop[1] + 4;
    if (start > 14) {
        start = 14;
    }

    var end = cardsHighFlop[cardsHighFlop.length - 3] - 2;
    if (end < 1) {
        end = 1;
    }
    var defflop = finalCardFlop;
    var newnuts = mynum;
    for (var i = start; i >= end; i--) {
        //console.log(finalCardFlop,i,strOds.includes(i))
        var res = [];

        if (!finalCardFlop.includes(i) && !strOds.includes(i)) {
            defflop = finalCardFlop;

            //defflop = defflop.concat(cards);
            defflop.push(i);

            res = getCenStrOddsIs(cards, defflop, showAll);

            if (res.nuts && num - 4 < i && res.flop[4] <= i && res.nuts > newnuts && res.high > num) {
                //console.log(res)
                if (num) {
                    newnuts = res.nuts;
                }
                strOds.push(i);
            }
            defflop.pop();
        }
        // defflop=  defflop.slice(0,(flop.length+1) * -1)
    }
    if (strOds.length == 0 || flop.length == 5 || utils.getHigh(finalCardFlop) <= num) {
        return [];
    }
    var straight = {
        flop: finalCardFlop,

        nuts: strOds.length > 2 ? 14 : num > 0 ? newnuts : (strOds.length * 14) / (flop.length + 1),
        cards: strOds,
        high: utils.getHigh(finalCardFlop),
        notRaise: true,
        num: num,
    };
    straight = decide.CleanOddsNuts(straight, "straight", showAll, flop);
    return straight;
}
function getCenStrOddsIs(myCards, flop, showAll) {
    var cards = myCards.concat(flop);

    var cardArr = {};
    if (cards.toString().indexOf("A") > -1 && !cards.includes("1")) {
        cards.push("1");
    }

    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) - 4 <= utils.getHigh(cards[i]);
            if (utils.getHigh(cards[j]) < utils.getHigh(cards[i])) {
                canAdd = utils.getHigh(cards[i]) - 4 <= utils.getHigh(cards[j]);
                count = cards[i][0] + cards[j][0];
            }
            if (utils.getHigh(cards[j]) == utils.getHigh(cards[i])) {
                canAdd = false;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    cards = utils.SortStraight(cards);
    //console.log(myCards, flop,cards)
    //console.log(cardArr)
    var isstr8 = false;
    var strcards = [];
    var strtotalcards = [];

    var cardsHighFlop = utils.SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1);
    }

    for (var prop in cardArr) {
        var defflop = cardsHighFlop;
        var finalCardFlop = [];
        var myhand = utils.SortStraight(cardArr[prop]);
        defflop = defflop.concat(myhand);
        defflop = utils.SortStraight(defflop);
        //console.log(defflop)
        if (defflop.includes(14)) {
            defflop.push(1);
        }
        for (var j = 0; j < defflop.length - 1; j++) {
            if (defflop[j] - 4 <= defflop[j + 1] && defflop[j] - 4 <= myhand[1]) {
                if (!finalCardFlop.includes(defflop[j]) && finalCardFlop.length <= 5) {
                    finalCardFlop.push(defflop[j]);
                }
                if (!finalCardFlop.includes(defflop[j + 1]) && finalCardFlop.length <= 5) {
                    finalCardFlop.push(defflop[j + 1]);
                }
            }
        }
        //console.log(finalCardFlop,utils.SortStraight(cardArr[prop]))
        //finalCardFlop = utils.SortStraight(finalCardFlop);

        var defstr = utils.isStraight(finalCardFlop);
        var defcard = utils.SortStraight(cardArr[prop]);

        if (defstr && defstr.includes(defcard[0]) && defstr.includes(defcard[1])) {
            strcards = defcard;
            strtotalcards = defstr;
            isstr8 = true;
        }
    }
    if (isstr8) {
        //console.log(finalCardFlop,strtotalcards)
        var muhighCard = strcards[0] - strcards[1] > 3 ? (14 - (strtotalcards[0] - strcards[0]) + (14 - (strtotalcards[1] - strcards[1]))) / 2 : 14 - (strtotalcards[0] - strcards[0]);
        if ((cardsHighFlop.includes(strcards[0]) || cardsHighFlop.includes(strcards[1])) && muhighCard == 14) {
            muhighCard = muhighCard - 1;
        }

        var fnuts = strtotalcards[0] == 14 ? strtotalcards[0] : muhighCard;

        var straight = {
            flop: strtotalcards,
            cards: strcards,
            high: strtotalcards[0] == 14 ? strtotalcards[0] : utils.getHigh(strcards),
            nuts: fnuts,
            notRaise: false,
        };
        straight = decide.CleanOddsNuts(straight, "straight", showAll, flop);
        return straight;
    }

    return [];
}
function haveFlushOdds(cards, flop, showAll, obj) {
    var flopOdds = utils.groupBy(flop, (v) => v[1]);
    var flushOdds = utils.groupBy(cards, (v) => v[1]);
    var flush = [];
    var cartFlush = [];
    var count = flop.length - 2;

    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop) && flushOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= count) {
                if (flushOdds[prop].length >= 2) {
                    var _out = utils.getFlushOddsOut(obj, prop, flushOdds[prop]);
                    if (_out < 8 || flopOdds[prop].length >= 3) {
                        flush.push({
                            cartName: prop,
                            flopCard: flopOdds[prop],
                            high: utils.getHigh(flopOdds[prop]),
                            out: _out,
                        });
                    }
                }
            }
        }
    }
    for (var propflush in flush) {
        for (var prop in flushOdds) {
            if (flushOdds.hasOwnProperty(prop)) {
                if (flushOdds[prop].length >= 2 && flush[propflush].cartName == prop) {
                    var _nuts = utils.getNust("flush", flushOdds[prop], flush[propflush].flopCard);

                    cartFlush.push({
                        cartName: prop,
                        Card: flushOdds[prop],
                        Flop: flush[propflush].flopCard,
                        out: flush[propflush].out,
                        notRaise: flush[propflush].flopCard.length >= 3 ? false : true,

                        high: utils.getHigh(flushOdds[prop]),
                        nuts: _nuts,
                    });
                }
            }
        }
    }
    if (cartFlush.length == 0) {
        flush = [];
        count = flop.length - 1;
        for (var prop in flopOdds) {
            if (flopOdds.hasOwnProperty(prop) && flushOdds.hasOwnProperty(prop)) {
                if (flopOdds[prop].length >= count) {
                    if (flushOdds[prop].length >= 1) {
                        var _out = utils.getFlushOddsOut(obj, prop, flushOdds[prop]);
                        if (_out < 8 || flopOdds[prop].length >= 3) {
                            flush.push({
                                cartName: prop,
                                flopCard: flopOdds[prop],
                                high: utils.getHigh(flopOdds[prop]),
                                out: _out,
                            });
                        }
                    }
                }
            }
        }
        for (var propflush in flush) {
            for (var prop in flushOdds) {
                if (flushOdds.hasOwnProperty(prop)) {
                    if (flushOdds[prop].length + flush[propflush].flopCard.length >= 4 && flush[propflush].cartName == prop) {
                        var _nuts = utils.getNust("flush", flushOdds[prop], flush[propflush].flopCard);

                        cartFlush.push({
                            cartName: prop,
                            Card: flushOdds[prop],
                            Flop: flush[propflush].flopCard,
                            out: flush[propflush].out,
                            notRaise: flush[propflush].flopCard.length + flushOdds[prop].length >= 5 ? false : true,

                            high: utils.getHigh(flushOdds[prop]),
                            nuts: _nuts,
                        });
                    }
                }
            }
        }
    }

    if (cartFlush.length == 0) {
        flush = [];
        count = flop.length;
        for (var prop in flopOdds) {
            if (flopOdds.hasOwnProperty(prop)) {
                if (flopOdds[prop].length >= count) {
                    if (flopOdds[prop].length >= 5) {
                        flush.push({
                            cartName: prop,
                            flopCard: flopOdds[prop],
                            high: utils.getHigh(flopOdds[prop]),
                            out: 1,
                        });
                    }
                }
            }
        }

        for (var propflush in flush) {
            if (flush[propflush].flopCard.length >= 5) {
                var _nuts = 2;

                cartFlush.push({
                    cartName: propflush,
                    Card: [],
                    Flop: flush[propflush].flopCard,

                    notRaise: true,

                    high: 1,
                    out: flush[propflush].out,
                    nuts: _nuts,
                });
            }
        }
    }
    if (cartFlush.length == 0) {
        return [];
    }
    cartFlush = decide.CleanOddsNuts(cartFlush, "flush", showAll, flop);
    return cartFlush;
}
function haveFullOdds(cards, flop, showAll) {
    var full = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);

    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    //console.log(showAll)
    if (havePerUp3Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < utils.getHigh(prop)) {
                    highPer = utils.getHigh(prop);
                }
            }
        }
        full = {
            set: havePerUp3Flop,
            per: highPer,
            highSet: utils.getHigh(havePerUp3Flop),
            highPer: utils.getHigh(highPer),

            nuts: highPer - showAll,
            notRaise: !showAll ? false : true,
        };
        if (highPer == 0) {
            full = [];
        }
        return full;
    }

    if (!havePerUpFlop) {
        return full;
    }
    var cardArr = {};
    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) == utils.getHigh(cards[i]);
            //console.log(showAll)
            if (!canAdd) {
                canAdd = true;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    // console.log(cardArr)
    var perUp2 = 0;
    var perUp3 = 0;
    var high = 0;
    for (var propcard in cardArr) {
        var total = flop.concat(cardArr[propcard]);

        var tot = utils.groupBy(total, (v) => v[0]);

        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length >= 3 && utils.getHigh(perUp3) <= utils.getHigh(prop)) {
                    perUp3 = prop;
                }
            }
        }

        //console.log(cardArr[propcard])
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //console.log(perUp3,perUp2)

        for (var prop in flopPer) {
            if (flopPer.hasOwnProperty(prop)) {
                if (flopPer[prop].length == 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    } else {
        //console.log(perUp3,perUp2,handPer,flopPer)
        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length == 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    }
    if (perUp3 == 0 || perUp2 == 0) {
        return [];
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //Hidden Full
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp3, flop);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: !showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: !showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        }
    } else {
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp2, flop.toString().replace(perUp3, "").replace(perUp3, ""));
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: !showAll || fnuts > 9 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop.toString().replace(perUp2, "").replace(perUp2, "").replace(perUp3, "").replace(perUp3, "")) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: !showAll || fnuts > 8 ? false : true,
                nuts: fnuts,
            };
        }
    }

    return full;
}
function haveSetOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var havePerUpHand = false;
    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length >= 2) {
                havePerUpHand = true;
            }
        }
    }

    if (!havePerUpHand) {
        return [];
    }
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            var h = utils.getHigh(prop);
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && high < h) {
                var fnuts = utils.getNust("set", tot[prop], flop);

                high = h;
                set = {
                    set: prop,
                    high: h,
                    nuts: fnuts,
                    notRaise: false,
                };
                set = decide.CleanOddsNuts(set, "set", showAll, flop);
            }
        }
    }

    return set;
}
function haveTreeOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (!havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            var h = utils.getHigh(prop);
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && cards.toString().indexOf(prop) > -1 && high < h) {
                high = h;
                var fnuts = utils.getNust("three", cards.toString().replace(prop, "").replace(prop, "").replace(prop, ""), flop);
                if (fnuts < 12) {
                    fnuts = 12;
                }

                set = {
                    set: prop,
                    high: h,
                    nuts: fnuts,
                    notRaise: false,
                };
                set = decide.CleanOddsNuts(set, "set", showAll, flop);
            }
        }
    }

    return set;
}

function getTwoPerOdds(cards, flop, showAll) {
    var per = [];

    var handPer = utils.getDouble(cards);
    var flopPer = utils.getDouble(flop);
    var cardsflop = [];
    var cardsflopDeck = [];
    var arrayLength = flop.length;
    if (handPer) {
        cardsflop.push(handPer);
    }
    if (flopPer) {
        cardsflop.push(flopPer);
    }

    for (var i = 0; i < arrayLength; i++) {
        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(utils.getHigh(flop[i]));
        }
        cardsflopDeck.push(utils.getHigh(flop[i]));
    }

    cardsflop.sort(utils.compareNumbers);
    cardsflopDeck.sort(utils.compareNumbers);

    // console.log(cardsflop,cardsflopDeck)
    if (cardsflop.length >= 2) {
        var fnuts = (14 - cardsflopDeck[0] + cardsflop[0] + (14 - cardsflopDeck[1] + cardsflop[1])) / 2;

        per = {
            //notRaise: showAll ? false : true,
            highOne: cardsflop[0],
            hightTwo: cardsflop[1],

            notRaise: !showAll || flop.length == 3 ? false : true,
            nuts: fnuts,
        };
        per = decide.CleanOddsNuts(per, "two", showAll, flop);
    }

    return per;
}
function getPerOdds(cards, flop, showAll) {
    var per = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);
    var cardsflop = [];
    var cardsflopDeck = [];

    var arrayLength = flop.length;
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (havePerUpFlop) {
        return [];
    }
    for (var i = 0; i < arrayLength; i++) {
        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(utils.getHigh(flop[i]));
        }
        cardsflopDeck.push(utils.getHigh(flop[i]));
    }
    if (cardsflop.length < 1 && utils.getDouble(cards)) {
        //cardsflop = [];
        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2) {
                    cardsflop.push(utils.getHigh(handPer[prop]));
                }
            }
        }
        //cardsflop.push(utils.getHigh(utils.getDouble(flop)));
    }
    //console.log(cardsflop,cardsflopDeck)
    cardsflopDeck.sort(utils.compareNumbers);
    cardsflop.sort(utils.compareNumbers);

    if (cardsflop.length >= 1) {
        var handPer = utils.getHigh(cards[0]);
        var handPer2 = utils.getHigh(cards[1]);
        var flophigh = utils.getHigh(flop);
        var perCount = (handPer + handPer2) / 2;
        if (flophigh <= handPer && flophigh <= handPer2) {
            perCount = perCount + 1;
        }
        var fnuts = (14 - cardsflopDeck[0] + perCount) / 2;
        fnuts = fnuts + handPer;
        if (fnuts > 14) {
            //fnuts = 14;
        }
        per = {
            highOne: cardsflop[0],

            notRaise: !showAll || flop.length == 3 ? false : true,
            nuts: fnuts,
            perCount: perCount,
        };
        per = decide.CleanOddsNuts(per, "two", showAll, flop);
    }

    return per;
}
function getHighOdds(cards, flop, showAll, obj) {
    var per = [];
    var noOut = 0;
    var handPer = utils.getHigh(cards[0]);
    var handPer2 = utils.getHigh(cards[1]);
    var flophigh = utils.getHigh(flop);
    if (flophigh < handPer && flophigh < handPer2) {
        var perCount = (handPer + handPer2) / 2;
        var AllCards = utils.remove_duplicates_es6(obj, cards);

        var uOdds = utils.groupBy(AllCards, (v) => v[0]);

        for (var propplayer in uOdds) {
            if (uOdds.hasOwnProperty(propplayer)) {
                var propHigh = utils.getHigh(propplayer);
                if (propHigh == handPer) {
                    noOut = noOut + uOdds[propplayer].length;
                }
                if (propHigh == handPer2) {
                    noOut = noOut + uOdds[propplayer].length;
                }
            }
        }
        if (noOut < 3) {
            per = {
                highOne: handPer,
                hightTwo: handPer2,
                notRaise: true,
                nuts: perCount,
            };
            per = decide.CleanOddsNuts(per, "high", showAll, flop);
        }
    }
    if (showAll) {
        // per = [];
    }
    return per;
}

function haveFourOdds(cards, flop, showAll) {
    var four = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 4) {
                havePerUp4Flop = true;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = prop;
            }
        }
    }
    if (havePerUp4Flop) {
        four = {
            nuts: utils.getHigh(cards),
            high: utils.getHigh(cards),
            notRaise: flop.length == 5 ? false : true,
        };
        return four;
    }

    if (havePerUp3Flop) {
        if (cards.toString().indexOf(havePerUp3Flop) > -1) {
            four = {
                nuts: 14,
                high: utils.getHigh(havePerUp3Flop),
                notRaise: flop.length == 5 ? false : true,
            };
            return four;
        }
    }

    if (!havePerUpFlop) {
        return four;
    }
    var total = flop.concat(cards);

    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 4) {
                four = {
                    nuts: utils.getHigh(prop),
                    high: utils.getHigh(havePerUpFlop),
                    notRaise: false,
                };
            }
        }
    }

    return four;
}
decide.CleanOddsNuts = function (data, name, showAll, flop) {
    var _data = data;
    var fnuts = _data.nuts;
    var canRaise = _data.notRaise ? _data.notRaise : false;
    var rank = utils.getHandRank(name);
    if (showAll && flop.length >= 3) {
        if (name == "set" || name == "two" || name == "straight" || name == "high") {
            if (utils.checkHaveFlushOdds(flop)) {
                if (flop.length >= 3 || name == "straight") {
                    fnuts = fnuts / ((rank + flop.length) / 3);
                }
                canRaise = true;
            }
        }
        if (name == "two" || name == "straight" || name == "high") {
            if (utils.getDouble(flop)) {
                fnuts = fnuts / ((rank + flop.length) / 3);
                canRaise = true;
            }
        }

        if (name == "set" || name == "two" || name == "high") {
            if (utils.checkHaveStrOdds(flop)) {
                if (flop.length >= 3) {
                    fnuts = fnuts / ((rank + flop.length) / 3);
                }

                canRaise = true;
            }
        }
        if (flop.length == 3 && fnuts >= 12) {
            if (name != "straight" && name != "flush") {
                //canRaise = false;
            }
        }
    }
    if (!showAll && flop.length >= 3) {
        if (name == "two" || name == "straight" || name == "high") {
            if (utils.checkHaveFlushOdds(flop)) {
                canRaise = true;
            }
        }
        if (name == "two" || name == "straight" || name == "high") {
            if (utils.getDouble(flop)) {
                canRaise = true;
            }
        }
        if (name == "two" || name == "high") {
            if (utils.checkHaveStrOdds(flop)) {
                canRaise = true;
            }
        }
    }

    if (name == "flush") {
        var flushdata = data;
        for (var j = 0; j < flushdata.length; j++) {
            _data = flushdata[j];
            fnuts = _data.nuts;
            canRaise = _data.notRaise ? _data.notRaise : false;

            if (utils.getDouble(flop)) {
                canRaise = true;
                if (showAll) {
                    fnuts = fnuts / (showAll + flop.length);
                }
            }
            if (_data.Flop.length == 2) {
                fnuts = fnuts - _data.out;
            }
            if (_data.Flop.length == 1) {
                fnuts = fnuts / 3;
            }
            //console.log(_data)
            if (_data.Flop.length + _data.Card.length < 5 && _data.Flop.length >= 3) {
                fnuts = fnuts - (7 - (_data.Flop.length + _data.Card.length));
            }
            _data.nuts = fnuts;
            _data.notRaise = canRaise;
            flushdata[j] = _data;
        }
        //console.log(flushdata);
        return flushdata;
    }

    _data.nuts = fnuts;
    _data.notRaise = canRaise;

    return _data;
};
decide.CreateOdds = function (cards, flop, player, showAll, obj) {
    var Odds = {};
    Odds.four = [];
    Odds.full = [];
    Odds.flush = [];
    Odds.set = [];
    Odds.straight = [];
    Odds.isstraight = [];
    Odds.three = [];
    Odds.two = [];
    Odds.per = [];
    Odds.high = [];

    Odds.Player = player;
    Odds.four = haveFourOdds(cards, flop, showAll);

    if (!Odds.four.nuts) {
        Odds.full = haveFullOdds(cards, flop, showAll);

        if (!Odds.full.nuts) {
            Odds.flush = haveFlushOdds(cards, flop, showAll, obj);

            Odds.set = haveSetOdds(cards, flop, showAll);
            Odds.three = haveTreeOdds(cards, flop, showAll);
            if (!Odds.set.nuts && !Odds.three.nuts) {
                Odds.two = getTwoPerOdds(cards, flop, showAll);
                if (!Odds.two.nuts) {
                    Odds.per = getPerOdds(cards, flop, showAll);
                    if (!Odds.per.nuts) {
                        Odds.high = getHighOdds(cards, flop, showAll, obj);
                    }
                }
            }
            try {
                if (Odds.flush.length == 0 || Odds.flush[0].notRaise || flop.length < 5) {
                    if (Odds.flush[0].notRaise) {
                        var isstr = getCenStrOddsIs(cards, flop, showAll);
                        Odds.isstraight = isstr;

                        if (!Odds.isstraight.nuts || flop.length < 5) {
                            Odds.straight = getCenStrOdds(cards, flop, isstr.cards ? isstr.flop[0] : 0, isstr.cards ? isstr.flop[0] : 0, showAll);
                            // Odds.straight =[]
                        }
                    }
                }
                if (Odds.flush.length > 0 && !Odds.flush[0].notRaise) {
                    if (flop.length == 5) {
                        Odds.set = [];
                        Odds.three = [];
                        Odds.two = [];

                        // Odds.straight =[]
                    }
                    Odds.straight = [];
                    Odds.isstraight = [];
                    Odds.per = [];
                    Odds.high = [];
                }
            } catch (err) {
                var isstr = getCenStrOddsIs(cards, flop, showAll);

                Odds.isstraight = isstr;

                if (!Odds.isstraight.nuts || flop.length < 5) {
                    Odds.straight = getCenStrOdds(cards, flop, isstr.cards ? isstr.flop[0] : 0, isstr.cards ? isstr.flop[0] : 0, showAll);
                    // Odds.straight =[]
                }
            }
            if (Odds.isstraight.nuts) {
                if (flop.length == 5) {
                    Odds.set = [];
                    Odds.three = [];
                    Odds.two = [];
                    // Odds.straight =[]
                }
                Odds.per = [];
                Odds.high = [];
            }
        }
    }

    return Odds;
};
decide.GetOdds = function (obj) {
    var oDDs = [];
    var fourHigh = 0;
    var flushHigh = 0;
    var setHigh = 0;
    var str8High = 0;
    var fullHigh = 0;
    var twoHigh = 0;
    var perHigh = 0;
    var highHigh = 0;
    var showAllObj = utils.checkShow(obj);
    var showAll = parseInt(showAllObj.showAll + showAllObj.showAllbots);
    var AllBots = showAllObj.players == 0 ? true : false;
    //var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll);
    var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll, obj);

    var havePlayer = utils.GetCleanOdds(PlayeroDDs);

    if (havePlayer) {
        //havePlayer = utils.PrintCleanOdds(PlayeroDDs, false, obj, false, PlayeroDDs);
        //console.log("PlayeroDDs1", obj.Player + " ---  " + obj.state, PlayeroDDs);
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop) && havePlayer) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && (obj.pls[prop].Chips > 0 || obj.pls[prop].inPot[obj.state] > 0)) {
                    var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll, obj);
                    var havePlayerUser = utils.GetCleanOdds(uOdds);
                    if (havePlayerUser) {
                        //console.log("uOdds", obj.Player + "  " + obj.pls[prop].Player + " ---  " + obj.pls[prop].Cards, uOdds);
                        if (obj.pls[prop].Helper.indexOf("a Royal Flush") > -1 || obj.pls[prop].Helper.indexOf("a Straight Flush") > -1) {
                            PlayeroDDs.full = [];
                            PlayeroDDs.flush = [];
                            PlayeroDDs.set = [];
                            PlayeroDDs.straight = [];
                            PlayeroDDs.isstraight = [];
                            PlayeroDDs.three = [];
                            PlayeroDDs.two = [];
                            PlayeroDDs.per = [];
                            PlayeroDDs.four = [];
                            PlayeroDDs.high = [];
                        }
                        if (!AllBots) {
                            if (uOdds.four.nuts) {
                                if (fourHigh < uOdds.four.high) {
                                    fourHigh = uOdds.four.high;
                                }
                                if (PlayeroDDs.four.high) {
                                    if (fourHigh > PlayeroDDs.four.high) {
                                        PlayeroDDs.four = [];
                                    }
                                }
                                PlayeroDDs.full = [];
                                PlayeroDDs.flush = [];
                                PlayeroDDs.isstraight = [];
                                PlayeroDDs.straight = [];
                                PlayeroDDs.set = [];
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.three = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "four", obj, prop, PlayeroDDs);
                            }

                            if (uOdds.full.nuts) {
                                if (fullHigh < uOdds.full.nuts + uOdds.full.highSet) {
                                    fullHigh = uOdds.full.nuts + uOdds.full.highSet;
                                }
                                if (PlayeroDDs.full.nuts) {
                                    if (fullHigh > PlayeroDDs.full.nuts + PlayeroDDs.full.highSet) {
                                        PlayeroDDs.full = [];
                                    }
                                }
                                PlayeroDDs.flush = [];
                                PlayeroDDs.isstraight = [];
                                PlayeroDDs.straight = [];
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set = [];
                                    PlayeroDDs.three = [];
                                } else {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three.notRaise = true;
                                    if (PlayeroDDs.set.nuts) {
                                        if (uOdds.full.highSet > PlayeroDDs.set.nuts || (uOdds.full.highSet == PlayeroDDs.set.nuts && uOdds.full.highPer > utils.getHigh(obj.convertedCards))) {
                                            PlayeroDDs.set = [];
                                        }
                                    }
                                    if (PlayeroDDs.three.nuts) {
                                        if (uOdds.full.highSet > PlayeroDDs.three.high || (uOdds.full.highSet == PlayeroDDs.three.high && uOdds.full.highPer > utils.getHigh(obj.convertedCards))) {
                                            PlayeroDDs.three = [];
                                        }
                                    }
                                }
                                havePlayer = utils.PrintCleanOdds(uOdds, "full", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.flush.length > 0) {
                                for (var j = 0; j < uOdds.flush.length; j++) {
                                    if (flushHigh < uOdds.flush[j].nuts) {
                                        flushHigh = uOdds.flush[j].nuts;
                                    }
                                    if (PlayeroDDs.flush.length > 0) {
                                        if (flushHigh > PlayeroDDs.flush[0].nuts && uOdds.flush[j].cartName == PlayeroDDs.flush[0].cartName) {
                                            PlayeroDDs.flush[0] = [];
                                        }
                                    }
                                    if (uOdds.flush[j].Flop.length + uOdds.flush[j].Card.length >= 5 && uOdds.flush[j].Flop.length >= 3) {
                                        PlayeroDDs.isstraight = [];
                                        PlayeroDDs.straight = [];
                                        PlayeroDDs.per = [];
                                        PlayeroDDs.high = [];
                                        if (obj.flopCards.length == 5) {
                                            PlayeroDDs.set = [];
                                            PlayeroDDs.three = [];
                                            PlayeroDDs.two = [];
                                        } else {
                                            PlayeroDDs.set.notRaise = true;
                                            PlayeroDDs.three.notRaise = true;
                                            PlayeroDDs.two.notRaise = true;
                                        }
                                    }
                                }
                                havePlayer = utils.PrintCleanOdds(uOdds, "flush", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.isstraight.high) {
                                if (str8High < uOdds.isstraight.high + uOdds.isstraight.nuts) {
                                    str8High = uOdds.isstraight.high + uOdds.isstraight.nuts;
                                }
                                if (PlayeroDDs.isstraight.high) {
                                    if (str8High > PlayeroDDs.isstraight.high + PlayeroDDs.isstraight.nuts) {
                                        PlayeroDDs.isstraight = [];
                                    }
                                }
                                if (PlayeroDDs.straight.high) {
                                    if (str8High >= PlayeroDDs.straight.high + PlayeroDDs.straight.nuts) {
                                        PlayeroDDs.straight = [];
                                    }
                                }
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set = [];
                                    PlayeroDDs.three = [];
                                    PlayeroDDs.two = [];

                                    PlayeroDDs.straight = [];
                                } else {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three.notRaise = true;
                                    PlayeroDDs.two.notRaise = true;
                                }
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "isstraight", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.straight.high) {
                                if (str8High < uOdds.straight.high + uOdds.straight.nuts) {
                                    str8High = uOdds.straight.high + uOdds.straight.nuts;
                                }
                                if (PlayeroDDs.straight.high) {
                                    if (str8High > PlayeroDDs.straight.high + PlayeroDDs.straight.nuts) {
                                        PlayeroDDs.straight = [];
                                    }
                                }

                                havePlayer = utils.PrintCleanOdds(uOdds, "straight", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.set.nuts) {
                                if (setHigh < uOdds.set.nuts) {
                                    setHigh = uOdds.set.nuts;
                                }
                                if (PlayeroDDs.set.nuts) {
                                    if (setHigh > PlayeroDDs.set.nuts) {
                                        PlayeroDDs.set = [];
                                    }
                                }
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "set", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.three.nuts) {
                                if (setHigh < uOdds.three.nuts) {
                                    setHigh = uOdds.three.nuts;
                                }
                                if (PlayeroDDs.three.nuts) {
                                    if (setHigh > PlayeroDDs.three.nuts) {
                                        PlayeroDDs.three = [];
                                    }
                                }
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];

                                havePlayer = utils.PrintCleanOdds(uOdds, "three", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.two.nuts) {
                                if (twoHigh < uOdds.two.nuts + uOdds.two.highOne) {
                                    twoHigh = uOdds.two.nuts + uOdds.two.highOne;
                                }
                                if (PlayeroDDs.two.nuts) {
                                    if (twoHigh > PlayeroDDs.two.nuts + PlayeroDDs.two.highOne) {
                                        PlayeroDDs.two = [];
                                    }
                                    if (twoHigh == PlayeroDDs.two.nuts + PlayeroDDs.two.highOne) {
                                        PlayeroDDs.two.notRaise = true;
                                    }
                                }
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "two", obj, prop, PlayeroDDs);
                                //utils.PrintCleanOdds(uOdds,"two",obj,prop)
                            }
                            if (uOdds.per.nuts) {
                                if (perHigh < uOdds.per.nuts + uOdds.per.highOne) {
                                    perHigh = uOdds.per.nuts + uOdds.per.highOne;
                                }
                                if (PlayeroDDs.per.nuts) {
                                    if (perHigh > PlayeroDDs.per.nuts + PlayeroDDs.per.highOne) {
                                        PlayeroDDs.per = [];
                                    }
                                    if (perHigh == PlayeroDDs.per.nuts + PlayeroDDs.per.highOne) {
                                        PlayeroDDs.per.notRaise = true;
                                    }
                                }
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "per", obj, prop, PlayeroDDs);
                                //utils.PrintCleanOdds(uOdds,"per",obj,prop)
                            }
                            if (uOdds.high.nuts) {
                                if (highHigh < uOdds.high.nuts) {
                                    highHigh = uOdds.high.nuts;
                                }
                                if (PlayeroDDs.high.nuts) {
                                    if (highHigh > PlayeroDDs.high.nuts) {
                                        PlayeroDDs.high = [];
                                    }
                                    if (highHigh == PlayeroDDs.high.nuts) {
                                        PlayeroDDs.high.notRaise = true;
                                    }

                                    havePlayer = utils.PrintCleanOdds(uOdds, "high", obj, prop, PlayeroDDs);
                                }
                            }
                        } else {
                            if (uOdds.four.nuts) {
                                PlayeroDDs.isstraight = [];
                                PlayeroDDs.straight = [];
                                PlayeroDDs.set = [];
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.three = [];
                                PlayeroDDs.high = [];
                                PlayeroDDs.full.notRaise = true;
                                havePlayer = utils.PrintCleanOdds(uOdds, "four", obj, prop, PlayeroDDs);
                            }

                            if (uOdds.full.nuts) {
                                if (fullHigh < uOdds.full.nuts + uOdds.full.highSet) {
                                    fullHigh = uOdds.full.nuts + uOdds.full.highSet;
                                }
                                if (PlayeroDDs.full.nuts) {
                                    if (fullHigh > PlayeroDDs.full.nuts + PlayeroDDs.full.highSet) {
                                        PlayeroDDs.full.notRaise = true;
                                    }
                                }
                                PlayeroDDs.flush.notRaise = true;
                                PlayeroDDs.isstraight.notRaise = true;
                                PlayeroDDs.straight = [];
                                PlayeroDDs.two = [];
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three.notRaise = true;
                                } else {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three.notRaise = true;
                                }
                                havePlayer = utils.PrintCleanOdds(uOdds, "full", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.flush.length > 0) {
                                for (var j = 0; j < uOdds.flush.length; j++) {
                                    if (flushHigh < uOdds.flush[j].nuts) {
                                        flushHigh = uOdds.flush[j].nuts;
                                    }
                                    if (PlayeroDDs.flush.length > 0) {
                                        if (flushHigh > PlayeroDDs.flush[0].nuts && uOdds.flush[j].cartName == PlayeroDDs.flush[0].cartName) {
                                            PlayeroDDs.flush[0].notRaise = true;
                                        }
                                    }
                                    if (uOdds.flush[j].Flop.length + uOdds.flush[j].Card.length >= 5 && uOdds.flush[j].Flop.length >= 3) {
                                        PlayeroDDs.isstraight.notRaise = true;
                                        PlayeroDDs.straight = [];
                                        PlayeroDDs.per = [];
                                        PlayeroDDs.high = [];
                                        if (obj.flopCards.length == 5) {
                                            PlayeroDDs.set.notRaise = true;
                                            PlayeroDDs.three = [];
                                            PlayeroDDs.two = [];
                                        } else {
                                            PlayeroDDs.set.notRaise = true;
                                            PlayeroDDs.three.notRaise = true;
                                            PlayeroDDs.two = [];
                                        }
                                    }
                                }
                                havePlayer = utils.PrintCleanOdds(uOdds, "flush", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.isstraight.high) {
                                if (str8High < uOdds.isstraight.high + uOdds.isstraight.nuts) {
                                    str8High = uOdds.isstraight.high + uOdds.isstraight.nuts;
                                }
                                if (PlayeroDDs.isstraight.high) {
                                    if (str8High > PlayeroDDs.isstraight.high + PlayeroDDs.isstraight.nuts) {
                                        PlayeroDDs.isstraight.notRaise = true;
                                    }
                                }
                                if (PlayeroDDs.straight.high) {
                                    if (str8High >= PlayeroDDs.straight.high + PlayeroDDs.straight.nuts) {
                                        PlayeroDDs.straight = [];
                                    }
                                }
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three = [];
                                    PlayeroDDs.two = [];
                                    PlayeroDDs.straight = [];
                                } else {
                                    PlayeroDDs.set.notRaise = true;
                                    PlayeroDDs.three = [];
                                    PlayeroDDs.two = [];
                                }
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "isstraight", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.straight.high) {
                                if (str8High < uOdds.straight.high + uOdds.straight.nuts) {
                                    str8High = uOdds.straight.high + uOdds.straight.nuts;
                                }
                                if (PlayeroDDs.straight.high) {
                                    if (str8High > PlayeroDDs.straight.high + PlayeroDDs.straight.nuts) {
                                        PlayeroDDs.straight = [];
                                    }
                                }

                                havePlayer = utils.PrintCleanOdds(uOdds, "straight", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.set.nuts) {
                                if (setHigh < uOdds.set.nuts) {
                                    setHigh = uOdds.set.nuts;
                                }
                                if (PlayeroDDs.set.nuts) {
                                    if (setHigh > PlayeroDDs.set.nuts) {
                                        PlayeroDDs.set.notRaise = true;
                                    }
                                }
                                PlayeroDDs.two.notRaise = true;
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "set", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.three.nuts) {
                                if (setHigh < uOdds.three.nuts) {
                                    setHigh = uOdds.three.nuts;
                                }
                                if (PlayeroDDs.three.nuts) {
                                    if (setHigh > PlayeroDDs.three.nuts) {
                                        PlayeroDDs.three.notRaise = true;
                                    }
                                }
                                PlayeroDDs.two.notRaise = true;
                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];

                                havePlayer = utils.PrintCleanOdds(uOdds, "three", obj, prop, PlayeroDDs);
                            }
                            if (uOdds.two.nuts) {
                                if (twoHigh < uOdds.two.nuts + uOdds.two.highOne) {
                                    twoHigh = uOdds.two.nuts + uOdds.two.highOne;
                                }
                                if (PlayeroDDs.two.nuts) {
                                    if (twoHigh > PlayeroDDs.two.nuts + PlayeroDDs.two.highOne) {
                                        PlayeroDDs.two = [];
                                    }
                                    if (twoHigh == PlayeroDDs.two.nuts + PlayeroDDs.two.highOne) {
                                        PlayeroDDs.two.notRaise = true;
                                    }
                                }

                                PlayeroDDs.per = [];
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "two", obj, prop, PlayeroDDs);
                                //utils.PrintCleanOdds(uOdds,"two",obj,prop)
                            }
                            if (uOdds.per.nuts) {
                                if (perHigh < uOdds.per.nuts + uOdds.per.highOne) {
                                    perHigh = uOdds.per.nuts + uOdds.per.highOne;
                                }
                                if (PlayeroDDs.per.nuts) {
                                    if (perHigh > PlayeroDDs.per.nuts + PlayeroDDs.per.highOne) {
                                        PlayeroDDs.per = [];
                                    }
                                    if (perHigh == PlayeroDDs.per.nuts + PlayeroDDs.per.highOne) {
                                        PlayeroDDs.per.notRaise = true;
                                    }
                                }
                                PlayeroDDs.high = [];
                                havePlayer = utils.PrintCleanOdds(uOdds, "per", obj, prop, PlayeroDDs);
                                //utils.PrintCleanOdds(uOdds,"per",obj,prop)
                            }
                            if (uOdds.high.nuts) {
                                if (highHigh < uOdds.high.nuts) {
                                    highHigh = uOdds.high.nuts;
                                }
                                if (PlayeroDDs.high.nuts) {
                                    if (highHigh > PlayeroDDs.high.nuts) {
                                        PlayeroDDs.high = [];
                                    }
                                    havePlayer = utils.PrintCleanOdds(uOdds, "high", obj, prop, PlayeroDDs);
                                }
                            }
                        }
                        havePlayer = utils.GetCleanOdds(PlayeroDDs);
                    }
                }
            }
        }
    }

    var odds = 0;
    var oddsName = "";
    var oddsStr = [];
    var oddsCount = 0;
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop)) {
            if (PlayeroDDs[prop].nuts) {
                //console.log("odds", odds,"oddsName",oddsName,PlayeroDDs[prop].nuts)
                if (odds < PlayeroDDs[prop].nuts || (odds <= PlayeroDDs[prop].nuts && !PlayeroDDs[prop].notRaise)) {
                    odds = PlayeroDDs[prop].nuts;
                    oddsStr = PlayeroDDs[prop];
                    oddsName = prop;
                }
                if (!PlayeroDDs[prop].notRaise) {
                    oddsCount = oddsCount + 1;
                }
                // odds = odds + PlayeroDDs[prop].nuts
                //oddsCount = oddsCount + 1
            }
        }
    }

    if (PlayeroDDs["flush"].length > 0) {
        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
            if (PlayeroDDs["flush"][i].nuts) {
                var flushInfo = utils.getOutInfoFlush(obj);
                if (odds < PlayeroDDs["flush"][i].nuts || (odds <= PlayeroDDs["flush"][i].nuts && !PlayeroDDs["flush"][i].notRaise)) {
                    odds = PlayeroDDs["flush"][i].nuts;
                    if (flushInfo[PlayeroDDs["flush"][i].cartName].nuts <= odds) {
                        odds = 14;
                    }
                    oddsStr = PlayeroDDs["flush"][i];
                    oddsName = "flush";
                    if (!PlayeroDDs["flush"][i].notRaise) {
                        oddsCount = oddsCount + 1;
                    }
                }
            }
        }
    }

    var finalcount = oddsCount > 0 ? oddsCount : 1;
    var finalOds = parseInt((odds * 100) / 14);
    if (finalOds > 100 || oddsName == "four") {
        finalOds = 100;
    }
    if (!showAll && oddsName == "full") {
        finalOds = 100;
    }
    if (showAll) {
        if (oddsName != "four" && oddsName != "full" && finalOds < 100 && finalOds > 0) {
            //finalOds = finalOds - showAll * 10;
        }
    }
    var isFlush = true;
    if (oddsStr.notRaise) {
        isFlush = false;
    }
    if (oddsName == "") {
        isFlush = false;
    }

    //console.log("PlayeroDDs", obj.tablename + " " + obj.handnumber + " " + obj.Player + " ---  " + obj.state, oddsStr, finalOds, isFlush, showAll, oddsName);
    return [finalOds, isFlush, showAll, oddsName, AllBots, oddsStr];
};
decide.CleanOddsHigh = function (obj) {
    var TotalHigh = 0;
    var noOut = 0;
    var DHigh = 0;
    var hPer = utils.getHigh(obj.convertedCards[0]);
    var hPer2 = utils.getHigh(obj.convertedCards[1]);

    var handPer = hPer;
    var handPer2 = hPer2;

    var infoHand = utils.getOut(obj, obj.convertedCards);
    if (infoHand[0].out > 2) {
        handPer = handPer / 2;
    }
    if (infoHand[0].out > 3) {
        handPer = 0;
    }
    if (infoHand[1].out > 2) {
        handPer2 = handPer2 / 2;
    }
    if (infoHand[1].out > 3) {
        handPer2 = 0;
    }
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = utils.CleanOddsPerPlayer(obj, obj.pls[prop].Player, obj.pls[prop].Cards);
                if (uOdds[0]) {
                    if (handPer < uOdds[0] && hPer2 != uOdds[0]) {
                        handPer = handPer / 2;
                    }
                    if (handPer2 < uOdds[0] && hPer != uOdds[0]) {
                        handPer2 = handPer2 / 2;
                    }
                    // console.log(uOdds)
                }
            }
        }
    }

    var perCount = (handPer + handPer2) / 2;
    noOut = infoHand[0].out + infoHand[1].out;
    TotalHigh = (infoHand[0].high + infoHand[1].high) * 2;

    return [perCount, noOut, TotalHigh];
};

decide.actionSend = function (callback, obj, amount) {
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll + showAllObj.showAllbots;
    showAll = showAll == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;

    var OtherBlof = obj.state > 0 ? decide.GetOtherOdds(obj) : 0;

    if (amount) {
        return [amount, callback, obj, showAll, AllBots, OtherBlof];
    }
    return [callback, obj, showAll, AllBots, OtherBlof];
};

decide.call = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.call(_val[0], _val[1], _val[2], _val[3], _val[4]);
};
decide.fold = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.fold(_val[0], _val[1], _val[2], _val[3], _val[4]);
};
decide.raise = function (amount, callback, obj) {
    var _val = decide.actionSend(callback, obj, amount);

    actions.raise(_val[0], _val[1], _val[2], _val[3], _val[4], _val[5]);
};
decide.check = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.check(_val[0], _val[1], _val[2], _val[3], _val[4]);
};

decide.callfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];
    var canRaise = myprecentage[1];
    var showAll = myprecentage[2] == 0 ? true : false;
    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var pNum = utils.checkPlayerNumber(obj) + 1;
    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;
    var Uipot = utils.checkInpot(obj);
    var _am = utils.getRaiseAnount(obj, precentage);
    if (callAm > 0) {
        //total = total + callAm;
    }
    var inPotPercent = 100 - (inPot * 100) / total;
    var inCallPercent = (callAm * 100) / total;
    var inPotCallPercent = parseInt((inCallPercent + inPotPercent) / (pNum - 1));
    //console.log(myprecentage, inPotCallPercent);
    if (myprecentage[3] != "" && canRaise && showAll) {
        if (!Uipot && 100 != precentage) {
            decide.call(callback, obj);
            return false;
        }
        if (myprecentage[3] == "high" || myprecentage[3] == "full") {
            if (!bcore.Clients[obj.Player.toLowerCase()].Tables[obj.tablename].showCard) {
                bcore.Clients[obj.Player.toLowerCase()].Tables[obj.tablename].showCard = true;
            }
        }
        decide.raise(_am, callback, obj);
        return false;
    }
    if (myprecentage[3] != "" && canRaise && !showAll && precentage >= 50) {
        if (90 >= precentage) {
            decide.call(callback, obj);
            return false;
        }
        decide.raise(_am, callback, obj);
        return false;
    }

    if (myprecentage[3] != "" && !canRaise && !showAll && precentage >= inPotCallPercent) {
        decide.call(callback, obj);
        return false;
    }

    if (myprecentage[3] != "" && !canRaise && showAll && precentage >= inPotCallPercent) {
        decide.call(callback, obj);
        return false;
    }

    decide.fold(callback, obj);
    return false;
};
decide.checkfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];
    var canRaise = myprecentage[1];
    var showAll = myprecentage[2] == 0 ? true : false;
    var AllBots = myprecentage[4];

    var _am = utils.getRaiseAnount(obj, precentage);
    var Uipot = utils.checkInpotLastState(obj);

    if (myprecentage[3] != "" && canRaise && showAll) {
        decide.raise(_am, callback, obj);
        return false;
    }

    if (myprecentage[3] != "" && canRaise && !showAll) {
        if (50 <= precentage) {
            decide.raise(_am, callback, obj);
            return false;
        }
    }
    if (myprecentage[3] != "" && 70 <= precentage && !canRaise && !AllBots && Uipot) {
        if (myprecentage[3] != "flush" && myprecentage[3] != "straight") {
            if (!bcore.Clients[obj.Player.toLowerCase()].Tables[obj.tablename].showCard) {
                bcore.Clients[obj.Player.toLowerCase()].Tables[obj.tablename].showCard = true;
            }
            decide.raise(_am, callback, obj);
            return false;
        }
    }
    decide.check(callback, obj);
    return false;
};
decide.preFlop = function (obj, callback) {
    var rest = obj.Chips;
    var stt = utils.checkBankStat(obj);
    var winner = stt > 0 ? true : false;
    var looser = stt < 0 ? true : false;
    var getflushOdds = utils.CleanOddsFlsuh(obj);

    var perOdds = utils.CleanOddsPer(obj);

    var gethighOdds = decide.CleanOddsHigh(obj);
    var highOdds = (gethighOdds[0] - gethighOdds[1] - gethighOdds[2]) / 2;

    var showAllObj = utils.checkShow(obj);
    var showAll = parseInt(showAllObj.showAll + showAllObj.showAllbots);
    showAll = showAll == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;
    var canCall = 0;

    if (getflushOdds.length > 0) {
        if (showAll || getflushOdds[0].high >= getflushOdds[0].nuts) {
            canCall = canCall + (7 - getflushOdds[0].out);
        } else {
            if (looser || getflushOdds[0].high >= getflushOdds[0].nuts - 5) {
                canCall = canCall + (5 - getflushOdds[0].out);
            }
        }
    }

    if (perOdds[0] >= 2) {
        if (showAll) {
            canCall = canCall + perOdds[0] - (perOdds[1] - 2) - perOdds[2];
        } else {
            if (winner || perOdds[0] >= 7) {
                canCall = canCall + perOdds[0] - (perOdds[1] - 2) - perOdds[2];
            }
        }
    } else {
        canCall = canCall + highOdds;
    }

    canCall = parseInt(canCall);
    //console.info(getflushOdds, perOdds, gethighOdds, highOdds, canCall);
    var inPot = obj.inPot > 0 ? obj.inPot : 0;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
    if (callAm > 0) {
        if (callAm > rest) {
            callAm = rest;
        }
        total = total + callAm;
    }
    if (obj.Button2 == "Call") {
        var carereaise = canCall * obj.amounts.BB > inPot + callAm;
        //console.info(canCall * obj.amounts.BB > inPot + callAm);
        if (canCall >= 14 && carereaise) {
            decide.raise(total, callback, obj);
            return false;
        }
        if (perOdds[0] == 14) {
            total = total + obj.amounts.BB * canCall;

            decide.raise(total, callback, obj);
            return false;
        }
        if (canCall >= 6 && inPot <= obj.amounts.BB && carereaise) {
            decide.raise(total, callback, obj);
            return false;
        }

        var canusercall = false;
        if (canCall >= 2) {
            canusercall = true;
        }
        if (canCall >= 1 && inPot + callAm <= obj.amounts.BB * 10) {
            canusercall = true;
        }
        if (callAm <= obj.amounts.BB && inPot > 0) {
            canusercall = true;
        }
        if (callAm <= inPot) {
            canusercall = true;
        }
        if (canusercall) {
            decide.call(callback, obj);
            return false;
        }
        decide.fold(callback, obj);
        return false;
    } else if (obj.Button2 == "Check") {
        if (canCall > 5) {
            decide.raise(canCall * obj.amounts.BB, callback, obj);
            return false;
        }

        decide.check(callback, obj);
        return false;
    }
};

decide.flop = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {
        decide.checkfunction(obj, callback, precentage, precentage);
        return false;
    } else if (obj.Button2 == "Call") {
        decide.callfunction(obj, callback, precentage, precentage);

        return false;
    }
};

module.exports = decide;
