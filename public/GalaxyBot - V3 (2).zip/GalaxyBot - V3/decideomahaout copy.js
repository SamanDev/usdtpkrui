function decide() {}

decide.getDecide = function (obj, callback) {
    //  utils.checkStatus(obj);
    if (obj.state > 0) {
        if (obj.Helper.indexOf("a Royal Flush") > -1) {
            actions.handTen(obj, callback);
            return false;
        }
        if (obj.Helper.indexOf("a Straight Flush") > -1) {
            actions.handTen(obj, callback);
            return false;
        }
    }

    switch (obj.state) {
        case 0:
            decide.preFlop(obj, callback);
            return false;
            break;
        case 1:
            decide.flop(obj, callback);
            return false;
            break;
        case 2:
            decide.flop(obj, callback);
            return false;
            break;
        case 3:
            decide.flop(obj, callback);
            return false;
            break;
    }
};

function isStraight(data) {
    var ranks = [];

    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        if (!ranks.includes(data[i])) {
            ranks.push(data[i]);
        }

        //Do something
    }
    if (ranks.includes(14)) {
        ranks.push(1);
    }
    ranks.sort(utils.compareNumbers);

    return getLoopStrOdds(ranks);
}

function getLoopStrOdds(ranks) {
    var isStr = false;
    var myRankFinal = [];
    var myRank = ranks;

    var arrayLength = myRank.length;

    for (var i = 0; i < arrayLength - 4; i++) {
        if (!isStr) {
            isStr = myRank[i] - 1 == myRank[i + 1] && myRank[i + 1] - 1 == myRank[i + 2] && myRank[i + 2] - 1 == myRank[i + 3] && myRank[i + 3] - 1 == myRank[i + 4];
            if (isStr) {
                myRankFinal = [myRank[i], myRank[i + 1], myRank[i + 2], myRank[i + 3], myRank[i + 4]];
            }
        }
    }
    //console.log(ranks,isStr)
    if (!isStr && arrayLength > 5) {
        var newRank = myRank.slice(1);

        return getLoopStrOdds(newRank);
    } else {
        if (!isStr) {
            return isStr;
        } else {
            return myRankFinal;
        }
    }
}
function getCenStrOdds(cards, flop, nuts, num, showAll) {
    //console.log(cards, flop,nuts,num)
    if (num >= 14) {
        return [];
    }
    var mynum = nuts > 0 ? nuts : 0;
    var finalCardUser = [];
    var finalCardFlop = [];
    var strOds = [];

    var cardsHigh = utils.SortStraight(cards);
    var cardsHighFlop = utils.SortStraight(flop);

    var isNuts = false;

    var carStr = 0;

    for (var j = 0; j < cardsHigh.length - 1; j++) {
        if (cardsHigh[j] - 4 <= cardsHigh[j + 1]) {
            if (!finalCardUser.includes(cardsHigh[j])) {
                finalCardUser.push(cardsHigh[j]);
            }
            if (!finalCardUser.includes(cardsHigh[j + 1])) {
                finalCardUser.push(cardsHigh[j + 1]);
            }
        }
    }
    for (var j = 0; j < cardsHighFlop.length - 1; j++) {
        if (cardsHighFlop[j] - 4 <= cardsHighFlop[j + 1]) {
            if (!finalCardFlop.includes(cardsHighFlop[j])) {
                finalCardFlop.push(cardsHighFlop[j]);
            }
            if (!finalCardFlop.includes(cardsHighFlop[j + 1])) {
                finalCardFlop.push(cardsHighFlop[j + 1]);
            }
        }
    }
    finalCardFlop.sort(utils.compareNumbers);
    finalCardUser.sort(utils.compareNumbers);
    var start = finalCardFlop[1] + 4;
    if (start > 14) {
        start = 14;
    }

    var end = finalCardFlop[finalCardFlop.length - 2] - 5;
    if (end < 1) {
        end = 1;
    }
    // console.log(finalCardFlop, finalCardUser,start,end)

    var defflop = finalCardFlop;
    var newnuts = mynum;
    for (var i = start; i >= end; i--) {
        //console.log(finalCardFlop,i,strOds.includes(i))
        var res = [];

        if (!finalCardFlop.includes(i) && !strOds.includes(i)) {
            defflop = finalCardFlop;

            //defflop = defflop.concat(cards);
            defflop.push(i);

            res = getCenStrOddsIs(cards, defflop, showAll);

            if (res.nuts && num - 4 < i && res.flop[4] <= i && res.nuts > newnuts && res.high > num) {
                //console.log(res)
                if (num) {
                    newnuts = res.nuts;
                }
                strOds.push(i);
            }
            defflop.pop();
        }
        // defflop=  defflop.slice(0,(flop.length+1) * -1)
    }
    if (strOds.length == 0 || flop.length == 5) {
        return [];
    }
    return {
        flop: finalCardFlop,

        nuts: strOds.length > 2 ? 14 : num > 0 ? newnuts : (strOds.length * 14) / 2,
        cards: strOds,
        high: utils.getHigh(finalCardFlop),
        notRaise: true,
        num: num,
    };
}
function getCenStrOddsIs(myCards, flop, showAll) {
    var cards = myCards;
    var cardArr = {};
    if (cards.toString().indexOf("A") > -1 && !cards.includes("1")) {
        cards.push("1");
    }
    //console.log(cards)
    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) - 4 <= utils.getHigh(cards[i]);
            if (utils.getHigh(cards[j]) < utils.getHigh(cards[i])) {
                canAdd = utils.getHigh(cards[i]) - 4 <= utils.getHigh(cards[j]);
                count = cards[i][0] + cards[j][0];
            }
            if (utils.getHigh(cards[j]) == utils.getHigh(cards[i])) {
                canAdd = false;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    //console.log(cardArr)

    var isstr8 = false;
    var strcards = [];
    var strtotalcards = [];

    var cardsHighFlop = utils.SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1);
    }

    for (var prop in cardArr) {
        if (strcards.length >= 0) {
            var defflop = cardsHighFlop;
            var finalCardFlop = [];
            var myhand = utils.SortStraight(cardArr[prop]);
            defflop = defflop.concat(myhand);
            defflop = utils.SortStraight(defflop);
            //console.log(defflop)
            if (defflop.includes(14)) {
                defflop.push(1);
            }
            for (var j = 0; j < defflop.length - 1; j++) {
                if (defflop[j] - 4 <= defflop[j + 1] && defflop[j] - 4 <= myhand[1]) {
                    if (!finalCardFlop.includes(defflop[j]) && finalCardFlop.length <= 5) {
                        finalCardFlop.push(defflop[j]);
                    }
                    if (!finalCardFlop.includes(defflop[j + 1]) && finalCardFlop.length <= 5) {
                        finalCardFlop.push(defflop[j + 1]);
                    }
                }
            }
            //console.log(finalCardFlop,SortStraight(cardArr[prop]))
            //finalCardFlop = SortStraight(finalCardFlop);

            var defstr = isStraight(finalCardFlop);
            var defcard = utils.SortStraight(cardArr[prop]);
            if (defstr && defstr.includes(defcard[0]) && defstr.includes(defcard[1])) {
                strcards = defcard;
                strtotalcards = defstr;
                isstr8 = true;
            }
        }
    }
    if (isstr8) {
        // console.log(finalCardFlop,strtotalcards)
        var muhighCard = strcards[0] - strcards[1] > 3 ? (14 - (strtotalcards[0] - strcards[0]) + (14 - (strtotalcards[1] - strcards[1]))) / 2 : 14 - (strtotalcards[0] - strcards[0]);
        if ((cardsHighFlop.includes(strcards[0]) || cardsHighFlop.includes(strcards[1])) && muhighCard == 14) {
            muhighCard = muhighCard - 1;
        }
        var fnuts = strtotalcards[0] == 14 ? strtotalcards[0] : muhighCard;
        if (flop.length >= 3) {
            if (utils.checkHaveFlushOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (utils.getDouble(flop)) {
                fnuts = fnuts / 2;
            }
        }
        return {
            flop: strtotalcards,
            cards: strcards,
            high: strtotalcards[0] == 14 ? strtotalcards[0] : utils.getHigh(strcards),
            nuts: fnuts,
            notRaise: !utils.checkHaveFlushOdds(flop) && !utils.getDouble(flop) ? false : true,
        };
    }
    return [];
}
function haveFlushOdds(cards, flop, showAll, obj) {
    //console.log(obj);
    var flopOdds = utils.groupBy(flop, (v) => v[1]);
    var flushOdds = utils.groupBy(cards, (v) => v[1]);
    var flush = [];
    var cartFlush = [];
    var count = flop.length - 2;

    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop) && flushOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= count) {
                if (flushOdds[prop].length >= 2) {
                    var _out = utils.getFlushOddsOut(obj, prop);
                    if (_out <= 6 || flopOdds[prop].length >= 3) {
                        flush.push({
                            cartName: prop,
                            flopCard: flopOdds[prop],
                            high: utils.getHigh(flopOdds[prop]),
                            out: _out,
                        });
                    }
                }
            }
        }
    }

    for (var propflush in flush) {
        for (var prop in flushOdds) {
            if (flushOdds.hasOwnProperty(prop)) {
                if (flushOdds[prop].length >= 2 && flush[propflush].cartName == prop) {
                    var _nuts = utils.getNust("flush", flushOdds[prop], flush[propflush].flopCard);
                    if (flush[propflush].flopCard.length == 2) {
                        _nuts = _nuts - count;
                    }
                    if (flush[propflush].flopCard.length < 2) {
                        _nuts = _nuts / 2;
                    }
                    if (!showAll) {
                        //_nuts = _nuts / 2;
                        if (utils.getDouble(flop)) {
                            _nuts = _nuts / 2;
                        }
                    }
                    cartFlush.push({
                        cartName: prop,
                        Card: flushOdds[prop],
                        Flop: flush[propflush].flopCard,
                        out: flush[propflush].out,
                        notRaise: flush[propflush].flopCard.length >= 3 && !utils.getDouble(flop) ? false : true,

                        high: utils.getHigh(flushOdds[prop]),
                        nuts: _nuts,
                    });
                }
            }
        }
    }
    if (cartFlush.length == 0) {
        return [];
    }
    return cartFlush;
}
function haveFullOdds(cards, flop, showAll) {
    var full = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 4) {
                havePerUp4Flop = prop;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }
    if (havePerUp4Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < utils.getHigh(prop)) {
                    highPer = utils.getHigh(prop);
                }
            }
        }
        if (highPer == 0) {
            full = [];
        } else {
            full = {
                highSet: utils.getHigh(havePerUp4Flop),
                highPer: highPer,
                nuts: highPer,
                notRaise: highPer > 10 ? false : true,
            };
        }

        return full;
    }
    //console.log(showAll)
    if (havePerUp3Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < utils.getHigh(prop)) {
                    highPer = utils.getHigh(prop);
                }
            }
        }
        if (highPer == 0) {
            full = [];
        } else {
            full = {
                highSet: utils.getHigh(havePerUp3Flop),
                highPer: highPer,
                nuts: showAll ? highPer : highPer / 4,
                notRaise: showAll && highPer > 10 ? false : true,
            };
        }

        return full;
    }

    if (!havePerUpFlop) {
        return full;
    }
    var cardArr = {};
    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) == utils.getHigh(cards[i]);
            //console.log(showAll)
            if (!canAdd && flop.toString().indexOf(cards[j][0]) > -1 && flop.toString().indexOf(cards[i][0]) > -1) {
                canAdd = true;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    //console.log(cardArr)
    var perUp2 = 0;
    var perUp3 = 0;
    var high = 0;
    for (var propcard in cardArr) {
        var total = flop.concat(cardArr[propcard]);

        var tot = utils.groupBy(total, (v) => v[0]);

        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length >= 3 && utils.getHigh(perUp3) <= utils.getHigh(prop)) {
                    perUp3 = prop;
                }
            }
        }

        //console.log(cardArr[propcard])
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //console.log(perUp3,perUp2)

        for (var prop in flopPer) {
            if (flopPer.hasOwnProperty(prop)) {
                if (flopPer[prop].length >= 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    } else {
        //console.log(perUp3,perUp2,handPer,flopPer)
        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length >= 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    }
    if (perUp3 == 0 || perUp2 == 0) {
        return [];
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //Hidden Full
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp3, flop);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        }
    } else {
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp2, flop.toString().replace(perUp3, "").replace(perUp3, ""));
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 9 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop.toString().replace(perUp2, "").replace(perUp2, "").replace(perUp3, "").replace(perUp3, "")) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 8 ? false : true,
                nuts: fnuts,
            };
        }
    }
    //return false

    return full;
}

function haveSetOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var havePerUpHand = false;
    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length >= 2) {
                havePerUpHand = true;
            }
        }
    }

    if (!havePerUpHand) {
        return [];
    }
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            var h = utils.getHigh(prop);
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && high < h) {
                var fnuts = utils.getNust("set", tot[prop], flop);

                if (flop.length == 5) {
                    if (utils.checkHaveFlushOdds(flop)) {
                        fnuts = fnuts / 2;
                    }
                    if (utils.checkHaveStrOdds(flop)) {
                        fnuts = fnuts / 2;
                    }
                }
                high = h;
                set = {
                    set: prop,
                    high: high,
                    nuts: fnuts,
                    notRaise: utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop) ? true : false,
                };
            }
        }
    }

    return set;
}
function haveTreeOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (!havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && cards.toString().indexOf(prop) > -1 && high < utils.getHigh(prop)) {
                high = utils.getHigh(prop);
                var fnuts = utils.getNust("three", cards.toString().replace(prop, "").replace(prop, "").replace(prop, ""), flop);

                set = {
                    set: prop,
                    high: utils.getHigh(prop),
                    nuts: fnuts,
                    notRaise: utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop) ? true : false,
                };
            }
        }
    }

    return set;
}
function getPerOdds(cards, flop, showAll) {
    var per = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);
    var cardsflop = [];
    var cardsflopDeck = [];

    var arrayLength = flop.length;
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    for (var i = 0; i < arrayLength; i++) {
        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(utils.getHigh(flop[i]));
        }
        cardsflopDeck.push(utils.getHigh(flop[i]));
    }
    if (cardsflop.length < 2 && utils.getDouble(flop)) {
        cardsflop = [];
        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2) {
                    cardsflop.push(utils.getHigh(handPer[prop]));
                }
            }
        }
        cardsflop.push(utils.getHigh(utils.getDouble(flop)));
    }

    cardsflopDeck.sort(utils.compareNumbers);
    cardsflop.sort(utils.compareNumbers);
    //console.log(cardsflop)

    if (cardsflop.length >= 2) {
        var fnuts = (cardsflop[0] + cardsflop[1]) / 2;

        if (flop.length >= 3) {
            if (utils.checkHaveFlushOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (utils.checkHaveStrOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (havePerUpFlop) {
                fnuts = fnuts / 2;
            }
        }

        per = {
            //notRaise: showAll ? false : true,
            highOne: cardsflop[0],
            hightTwo: cardsflop[1],

            notRaise: utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop) || havePerUpFlop ? true : false,
            nuts: fnuts,
        };
    }

    return per;
}
function haveFourOdds(cards, flop, showAll) {
    var four = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 4) {
                havePerUp4Flop = true;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = prop;
            }
        }
    }
    if (havePerUp4Flop) {
        return four;
    }

    if (havePerUp3Flop) {
        if (cards.toString().indexOf(havePerUp3Flop) > -1) {
            four = {
                nuts: 14,
                notRaise: flop.length == 5 ? false : true,
            };
        }
        return four;
    }

    if (!havePerUpFlop) {
        return four;
    }
    var total = flop.concat(cards);

    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 4) {
                four = {
                    nuts: utils.getHigh(prop),
                    notRaise: false,
                };
            }
        }
    }

    return four;
}

decide.CreateOdds = function (cards, flop, player, showAll, obj) {
    var Odds = {};
    Odds.four = [];
    Odds.full = [];
    Odds.flush = [];
    Odds.set = [];
    Odds.straight = [];
    Odds.isstraight = [];
    Odds.three = [];
    Odds.per = [];

    Odds.Player = player;
    Odds.four = haveFourOdds(cards, flop, showAll);

    if (Odds.four.length == 0) {
        Odds.full = haveFullOdds(cards, flop, showAll);

        if (Odds.full.length == 0) {
            Odds.flush = haveFlushOdds(cards, flop, showAll, obj);
            Odds.set = haveSetOdds(cards, flop, showAll);
            Odds.three = haveTreeOdds(cards, flop, showAll);

            Odds.per = getPerOdds(cards, flop, showAll);
            var isstr = getCenStrOddsIs(cards, flop, showAll);
            Odds.isstraight = isstr;

            if (flop.length < 5) {
                Odds.straight = getCenStrOdds(cards, flop, isstr.cards ? isstr.flop[0] : 0, isstr.cards ? isstr.flop[0] : 0, showAll);
                // Odds.straight =[]
            }
        }
    }
    return Odds;
};
decide.GetOdds = function (obj) {
    var oDDs = [];
    var fourHigh = 0;
    var flushHigh = 0;
    var setHigh = 0;
    var str8High = 0;
    var fullHigh = 0;
    var perHigh = 0;
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll == 0 && showAllObj.showAllbots == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;
    if (AllBots) {
        // showAll = false;
    }
    //console.log("showAll",showAll)
    // console.log("showAll", showAll, "AllBots", AllBots);
    var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll, obj);

    //console.log("PlayeroDDs1", PlayeroDDs);
    if (!AllBots || 1 == 1) {
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop)) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                    var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll, obj);
                    //console.log(uOdds)
                    if (uOdds.flush.length > 0) {
                        for (var j = 0; j < uOdds.flush.length; j++) {
                            if (flushHigh < uOdds.flush[j].nuts) {
                                flushHigh = uOdds.flush[j].nuts;
                            }
                            if (uOdds.flush[j].Flop.length >= 3) {
                                PlayeroDDs.isstraight = [];
                                PlayeroDDs.straight = [];
                                PlayeroDDs.per.notRaise = true;
                                PlayeroDDs.set.notRaise = true;
                                PlayeroDDs.three.notRaise = true;
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set = [];
                                    PlayeroDDs.three = [];
                                    PlayeroDDs.per = [];
                                }
                            }
                        }
                    }
                    if (uOdds.four.nuts) {
                        if (fourHigh < uOdds.four.nuts) {
                            fourHigh = uOdds.four.nuts;
                        }
                        PlayeroDDs.full = [];
                        PlayeroDDs.flush = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.set = [];
                        PlayeroDDs.per = [];
                        PlayeroDDs.three = [];
                    }
                    if (uOdds.full.nuts) {
                        if (fullHigh < uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet) {
                            fullHigh = uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet;
                        }
                        //console.log("fullHigh",fullHigh)
                        PlayeroDDs.flush = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.per = [];
                        if (uOdds.full.highSet > PlayeroDDs.set.nuts || (uOdds.full.highSet == PlayeroDDs.set.nuts && uOdds.full.highPer > utils.getHigh(obj.convertedCards)) || obj.flopCards.length == 5) {
                            PlayeroDDs.set = [];
                        }

                        if (uOdds.full.highSet > PlayeroDDs.three.high || (uOdds.full.highSet == PlayeroDDs.three.high && uOdds.full.highPer > utils.getHigh(obj.convertedCards)) || obj.flopCards.length >= 4) {
                            PlayeroDDs.three = [];
                        } else {
                            // console.log(uOdds.full.highSet , PlayeroDDs.three.high)
                            if (uOdds.full.highSet <= PlayeroDDs.three.high) {
                                //console.log(PlayeroDDs.three)
                                PlayeroDDs.three.notRaise = true;
                            }
                        }
                    }

                    if (uOdds.set.nuts) {
                        if (setHigh < uOdds.set.nuts) {
                            setHigh = uOdds.set.nuts;
                        }

                        PlayeroDDs.per = [];
                        try {
                            if (obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3) {
                                PlayeroDDs.flush = [];
                            }
                        } catch (err) {}
                    }
                    if (uOdds.three.nuts) {
                        if (setHigh < uOdds.three.nuts) {
                            setHigh = uOdds.three.nuts;
                        }
                        PlayeroDDs.per = [];
                        try {
                            if (obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3) {
                                PlayeroDDs.flush = [];
                            }
                        } catch (err) {}
                    }
                    if (uOdds.per.nuts) {
                        if (perHigh < uOdds.per.nuts) {
                            perHigh = uOdds.per.nuts;
                        }
                    }
                    if (uOdds.isstraight.high) {
                        if (str8High < uOdds.isstraight.high) {
                            str8High = uOdds.isstraight.high;
                        }
                        PlayeroDDs.set.notRaise = true;
                        PlayeroDDs.three.notRaise = true;
                        PlayeroDDs.per.notRaise = true;

                        if (str8High > PlayeroDDs.straight.high || obj.flopCards.length == 5) {
                            PlayeroDDs.straight = [];
                        }
                        if (obj.flopCards.length == 5) {
                            PlayeroDDs.three = [];
                            PlayeroDDs.set = [];
                            PlayeroDDs.per = [];
                        }
                    }
                    if (uOdds.straight.high && uOdds.isstraight.high) {
                        if (uOdds.straight.high >= PlayeroDDs.straight.high || obj.flopCards.length == 5) {
                            PlayeroDDs.straight = [];
                        }
                    }
                    if (obj.pls[prop].Helper.indexOf("a Royal Flush") > -1 || obj.pls[prop].Helper.indexOf("a Straight Flush") > -1) {
                        PlayeroDDs.four = [];
                        PlayeroDDs.full = [];
                        PlayeroDDs.flush = [];
                        PlayeroDDs.set = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.three = [];
                        PlayeroDDs.per = [];
                    }
                    oDDs.push(uOdds);
                }
            }
        }
    }
    if (PlayeroDDs.four.nuts) {
        if (fourHigh > PlayeroDDs.four.nuts) {
            PlayeroDDs.four = [];
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        } else {
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.full.nuts) {
        if (fullHigh > PlayeroDDs.full.nuts + PlayeroDDs.full.highPer + PlayeroDDs.full.highSet) {
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        } else {
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }

    if (PlayeroDDs.flush.length > 0) {
        for (var j = 0; j < PlayeroDDs.flush.length; j++) {
            if (flushHigh > PlayeroDDs.flush[j].nuts) {
                if (PlayeroDDs.flush[j].Flop.length >= 3) {
                    PlayeroDDs.isstraight = [];
                    PlayeroDDs.straight = [];
                }
                PlayeroDDs.flush = [];

                if (obj.flopCards.length == 5) {
                    PlayeroDDs.set = [];
                    PlayeroDDs.three = [];
                    PlayeroDDs.per = [];
                }
            } else {
                if (PlayeroDDs.flush[j].Flop.length >= 3) {
                    PlayeroDDs.isstraight = [];
                    PlayeroDDs.straight = [];
                    if (obj.flopCards.length == 5) {
                        PlayeroDDs.set = [];
                        PlayeroDDs.three = [];
                        PlayeroDDs.per = [];
                    }
                } else {
                    if (obj.flopCards.length == 5) {
                        PlayeroDDs.straight = [];
                        PlayeroDDs.per = [];
                    }
                }
            }
        }
    }
    if (PlayeroDDs.set.nuts) {
        if (setHigh > PlayeroDDs.set.nuts) {
            PlayeroDDs.set = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.three.nuts) {
        if (setHigh > PlayeroDDs.three.nuts) {
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.per.nuts) {
        if (perHigh > PlayeroDDs.per.nuts) {
            PlayeroDDs.per = [];
        }
    }

    if (PlayeroDDs.isstraight.high) {
        if (str8High > PlayeroDDs.isstraight.high) {
            PlayeroDDs.isstraight = [];
            PlayeroDDs.straight.notRaise = true;
            if (obj.flopCards.length == 5) {
                PlayeroDDs.set = [];
                PlayeroDDs.three = [];
                PlayeroDDs.per = [];
            }
        }
        if (obj.flopCards.length == 5) {
            PlayeroDDs.set = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    //console.log("PlayeroDDs2", PlayeroDDs);
    var odds = 0;
    var oddsName = "";
    var oddsStr = [];
    var oddsCount = 0;
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop)) {
            if (PlayeroDDs[prop].nuts) {
                //console.log("odds", odds,"oddsName",oddsName,PlayeroDDs[prop].nuts)
                if (odds < PlayeroDDs[prop].nuts || (odds <= PlayeroDDs[prop].nuts && !PlayeroDDs[prop].notRaise)) {
                    odds = PlayeroDDs[prop].nuts;
                    oddsStr = PlayeroDDs[prop];
                    oddsName = prop;
                }
                if (!PlayeroDDs[prop].notRaise) {
                    oddsCount = oddsCount + 1;
                }
                // odds = odds + PlayeroDDs[prop].nuts
                //oddsCount = oddsCount + 1
            }
        }
    }

    if (PlayeroDDs["flush"].length > 0) {
        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
            if (PlayeroDDs["flush"][i].nuts) {
                if (odds < PlayeroDDs["flush"][i].nuts || (odds <= PlayeroDDs["flush"][i].nuts && !PlayeroDDs["flush"][i].notRaise)) {
                    odds = PlayeroDDs["flush"][i].nuts;
                    oddsStr = PlayeroDDs["flush"][i];
                    oddsName = "flush";
                    if (!PlayeroDDs["flush"][i].notRaise) {
                        oddsCount = oddsCount + 1;
                    }
                }

                //odds = odds + PlayeroDDs[prop][i].nuts
                // oddsCount = oddsCount + 1
            }
        }
    }

    var finalcount = oddsCount > 0 ? oddsCount : 1;
    //var finalOds = (odds * 100) / 14 / finalcount;
    var finalOds = (odds * 100) / 14;
    var isFlush = true;
    if (oddsStr.notRaise && oddsCount == 0) {
        isFlush = false;
    }
    if (oddsName == "") {
        isFlush = false;
    }

    if (oddsName == "four") {
        finalOds = 100;
    }
    if (AllBots && !showAll) {
        //showAll = true;
    }
    // console.log("PlayeroDDs", oddsStr, finalOds, isFlush, showAll, oddsName, oddsCount);
    // if(oddsName=="full" && showAll){finalOds=100}
    return [finalOds, isFlush, showAll, oddsName];
};
decide.GetOtherOdds = function (obj) {
    var oDDs = [];
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll == 0 && showAllObj.showAllbots == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Bot == false) {
                var PlayeroDDs = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll, obj);
                for (var prop in PlayeroDDs) {
                    if (PlayeroDDs.hasOwnProperty(prop)) {
                        if (PlayeroDDs[prop].nuts) {
                            var _odds = PlayeroDDs[prop];
                            _odds.player = PlayeroDDs.Player;
                            _odds.handname = prop;
                            oDDs.push(_odds);
                        } else {
                            if (PlayeroDDs["flush"].length > 0 && prop == "flush") {
                                for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
                                    var _odds = PlayeroDDs["flush"][i];
                                    _odds.player = PlayeroDDs.Player;
                                    _odds.handname = "flush";
                                    oDDs.push(_odds);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    //console.log(oDDs.length+showAllObj.showAll+showAllObj.showAllbots);
    return oDDs.length + showAllObj.showAll + showAllObj.showAllbots;
};
decide.GetOtherOddsStr = function (obj) {
    var oDDs = [];
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll == 0 && showAllObj.showAllbots == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll, obj);

                oDDs.push(uOdds);
            }
        }
    }

    //console.log(oDDs.length)
    return oDDs;
};

decide.actionSend = function (callback, obj, amount) {
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll == 0 && showAllObj.showAllbots == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;

    var OtherBlof = obj.state > 0 ? decide.GetOtherOdds(obj) : 0;

    if (amount) {
        return [amount, callback, obj, showAll, AllBots, OtherBlof];
    }
    return [callback, obj, showAll, AllBots, OtherBlof];
};

decide.call = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.call(_val[0], _val[1], _val[2], _val[3], _val[4]);
};
decide.fold = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.fold(_val[0], _val[1], _val[2], _val[3], _val[4]);
};
decide.raise = function (amount, callback, obj) {
    var _val = decide.actionSend(callback, obj, amount);

    actions.raise(_val[0], _val[1], _val[2], _val[3], _val[4], _val[5]);
};
decide.check = function (callback, obj) {
    var _val = decide.actionSend(callback, obj);

    actions.check(_val[0], _val[1], _val[2], _val[3], _val[4]);
};

decide.callfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];
    var canRaise = myprecentage[1];

    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;
    var Uipot = utils.checkInpot(obj);

    if (100 == precentage && canRaise) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (50 <= precentage && canRaise && myprecentage[2]) {
        if (!Uipot) {
            decide.call(callback, obj);
            return false;
        }

        decide.raise(total, callback, obj);
        return false;
    }
    if (50 <= precentage && canRaise && !myprecentage[2]) {
        decide.call(callback, obj);
        return false;
    }
    if (85 <= precentage) {
        decide.call(callback, obj);
        return false;
    }
    // console.log(myprecentage, inPot, (callAm * 100) / (total + inPot));

    if ((callAm * 100) / (total + inPot) <= precentage) {
        decide.call(callback, obj);
        return false;
    }
    if (precentage > 0 && canRaise && myprecentage[2]) {
        decide.call(callback, obj);
        return false;
    }
    if (precentage > 0) {
        if (rest <= total / 4) {
            decide.call(callback, obj);
            return false;
        }
    }
    if (rest <= (rest + inPot) / 4) {
        decide.call(callback, obj);
        return false;
    }

    decide.fold(callback, obj);
    return false;
};

decide.checkfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];
    var canRaise = myprecentage[1];
    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;

    var pNum = utils.checkPlayerNumber(obj);
    //pNum = 2
    var OtherBlof = decide.GetOtherOdds(obj);
    var stt = utils.checkBankStat(obj);
    //console.log(stt, myprecentage)

    if (stt != 1 && OtherBlof == 0 && myprecentage[2] && obj.state == 1) {
        console.log(OtherBlof, stt);
        decide.raise(total, callback, obj);
        return false;
    }
    var inPotPercent = ((inPot * (pNum / 2)) / total) * 100 * pNum;
    if (inPotPercent > 100) {
        inPotPercent = 100;
    }
    //console.log(inPotPercent,myprecentage)
    if (myprecentage[3] != "" && canRaise && myprecentage[2] && obj.state < 3) {
        decide.raise(total, callback, obj);
        return false;
    }
    if ((myprecentage[3] == "full" || myprecentage[3] == "set" || myprecentage[3] == "flush" || myprecentage[3] == "isstraight") && canRaise && myprecentage[2]) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (myprecentage[3] == "four" && obj.state == 3) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (100 == precentage && canRaise) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (100 == precentage && !canRaise) {
        if (stt == -1) {
            //console.log(stt,myprecentage)
            decide.raise(total, callback, obj);
            return false;
        }
    }
    if (inPotPercent <= precentage && canRaise) {
        if (86 < precentage) {
            decide.raise(total, callback, obj);
            return false;
        }
    }

    if (precentage > 0) {
        if (rest <= (rest + inPot) / 10) {
            decide.raise(rest, callback, obj);
            return false;
        }
    }

    decide.check(callback, obj);
    return false;
};

function calculateFlushOddsOut(obj) {
    var totalout = 0;

    for (var prop in obj) {
        totalout = totalout + obj[prop].out;
    }
    //console.log(totalout / obj.length)
    return totalout / obj.length;
}
decide.preFlop = function (obj, callback) {
    var rest = obj.Chips;
    var stt = utils.checkBankStat(obj);
    var winner = stt > 0 ? true : false;
    var looser = stt < 0 ? true : false;
    var flushOdds = utils.CleanOddsFlsuh(obj);
    var perOdds = utils.CleanOddsPer(obj);
    var showAllObj = utils.checkShow(obj);
    var showAll = showAllObj.showAll == 0 && showAllObj.showAllbots == 0 ? true : false;
    var AllBots = showAllObj.players == 0 ? true : false;

    //console.log("showAllObj", showAllObj);
    //console.log("showAll", showAll, "AllBots", AllBots);

    var flushout = calculateFlushOddsOut(flushOdds);
    var canCall = false;
    if (flushOdds.length >= 1) {
        canCall = true;
    }
    if (perOdds[0] > 0 && perOdds[1] < 2) {
        canCall = true;
    }
    //console.log(flushOdds, perOdds, flushout);
    //console.log("showAll", showAll);

    var inPot = obj.inPot > 0 ? obj.inPot : 0;

    if (looser) {
        if (flushOdds.length >= 1) {
            canCall = true;
        }
    }
    //console.log("canCall",canCall,obj.convertedCards)

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
    if (obj.Button2 == "Call") {
        if (utils.getThreeple(obj.convertedCards)) {
            decide.fold(callback, obj);
            return false;
        }

        if (canCall || (callAm <= obj.amounts.BB && inPot > 0)) {
            decide.call(callback, obj);
            return false;
        }

        decide.fold(callback, obj);
        return false;
    } else if (obj.Button2 == "Check") {
        if (canCall && !winner) {
            decide.raise(total, callback, obj);
            return false;
        }
        if (rest <= total / 4) {
            decide.raise(rest, callback, obj);
            return false;
        }
        decide.check(callback, obj);
        return false;
    }
};
decide.flop = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {
        decide.checkfunction(obj, callback, precentage, precentage);
        return false;
    } else if (obj.Button2 == "Call") {
        decide.callfunction(obj, callback, precentage, precentage);

        return false;
    }
};
module.exports = decide;
