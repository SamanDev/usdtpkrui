var CP = function(data)
{

	var t = this;
	t.Player = "";
	t.Status = "empty";
	t.Chips = 0;
	t.Seat = data.Seat;
	t.CLType = false;
	t.Action = 15;
	t.Helper = "";
	t.cardDeal = false;
	t.Cards = [0,0,0,0,0];
	t.CCards = "";
	t.place = -1;
	t.point = -1;
	t.inPot = [0,0,0,0];
	t.state = 0;
	t.sitingOut = false;
	t.handpoint = 0;
	t._handlimit = 0;
	t._timelimit = 0;
	t._startplay = 0;
	t._played = 0;
	t._deciding = false;


} 
CP.prototype.reCreate = function(data){
		var t = this;
	t.Player = data.Player;
	t.Status = data.Status;
	t.Chips = data.Chips;
	t.Seat = data.Seat;
	t.CLType = data.CLType;
	t.Action = data.Action;
	t.Helper =data.Helper;
	t.Cards = data.Cards;
	t.CCards = data.CCards;
	t.place =data.place;
	t.point =data.point;
	t.inPot = data.inPot;
	t.state = data.state;
	t.sitingOut = data.sitingOut;
	t.handpoint = data.handpoint;
	t._handlimit = data._handlimit;
	t._timelimit = data._timelimit;
	t._startplay = data._startplay;
	t._played =data._played;
	t._deciding = false;
	
}
CP.prototype.isBot = function(){
	return this.CLType == "Bot";
	
}
CP.prototype.reset = function(data){
	
	var t = this;

	t.Helper = "";
	t.cardDeal = false;
	t.Cards = [0,0,0,0,0];
	t.CCards = "";
	t.place = -1;
	t.point = -1;
	t.handpoint = -1;
	t.inPot  = [0,0,0,0];
	t.state = 0;
	
	
	
}
CP.prototype.sitOut = function(callback){
	
	var t = this;
	if(t.Status != "empty")
	{
		t.Player = "";
		t.Status = "empty";
		t.Chips = 0;
		t.CLType = false;
		t.Action = 15;
		t.Helper = "";
		t.Cards = [0,0,0,0,0];
		t.place = -1;
		t.point = -1;
		t.inPot = 0;
		t.state = 0;
		t._handlimit = 0;
		t._timelimit = 0;
		t._startplay = 0;
		t._played = 0;
		t._deciding = false;
		callback();
	}else{
		callback();
		
		
	}
}
CP.prototype.setPlayer = function(data){
	
	var t = this;
	t.Status = data.Status;
	t.Chips = data.Chips;
	t.Action = data.Action;
	t.Status = data.Status;
	if(typeof data.CLType != "undefined")
	{
	//	////console.log("===============CL",data.CLType);
		t.CLType = data.CLType;
	//	////console.log("===============CL1",t.CLType);
		
	}
	t.Player = data.Player;
	
	//////console.log("Set plaer",data,t);
}
CP.prototype.update = function(data){
	var t = this;
	t.Chips = data.Chips;
	t.Action = data.Action;
	t.Status = data.Status;
	
	
}

CP.prototype.checkSitout = function(){
	
	var t = this;
	if(t._played > t._handlimit)
	{
		/*
						bot.played ++;
						bot.Tables[dt.Table].Cards = decoders.ECards(dt);
						
						var bettime = Date.now() - bot.timestart;
						bettime = Math.floor(bettime / 1000);
						
						
						if(bot.played > bot.Hands || bettime > (bot.Times * 60) )
						{
							
							bot.PNum++;
							var resp  = {"Response":"LeaveSeat","Table":dt.Table,"Type":"R","PNum": bot.PNum ,"ID":bot.ID }
							var str = JSON.stringify(resp);
							var secs = Math.floor((Math.random() * (4 - 1)) + 1);
							setTimeout(function(){
								
								bot["ws"].send(str); 
									
									bot.PNum++;
								var resp  = {"Response":"CloseTable","Table":dt.Table,"Type":"R","PNum": bot.PNum ,"ID":bot.ID }
									
									
									bot["ws"].send(str); 
									
									
									
									
								},(secs * 1000));
								
							
							
							
						}
							
					
	*/				
	
		
	}
	
}
CP.prototype.setCard = function(){
}
	
CP.prototype.Reserve = function(callback)
{
	var t= this;
	t.Status = "Reserve";
	t.Action = 12;
	callback();
}
CP.prototype.Sit = function(data,callback)
{
	
	var t = this;
	t.Player = data.Player;
	t.Chips = data.Chips;
	t.Action = 0;
	t.Status = "playing";
	t.CLType = "Bot";
	
	callback();
} 
	
	
	
	

module.exports = CP;