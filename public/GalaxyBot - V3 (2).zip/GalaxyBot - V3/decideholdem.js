function decide() { }

decide.getDecide = function (obj, callback) {

    checkStatus(obj)

    if (obj.state > 0) {
        if (obj.Helper.indexOf("a Royal Flush") > -1) {
            decide.handTen(obj, callback);
            return false
        }
        if (obj.Helper.indexOf("a Straight Flush") > -1) {
            decide.handNine(obj, callback);
            return false
        }
  

    }

    switch (obj.state) {
        case 0:
            decide.preFlop(obj, callback);
            return false
            break;
        case 1:

            decide.flop(obj, callback);
            return false
            break;
        case 2:

            decide.turn(obj, callback);
            return false
            break;
        case 3:

            decide.river(obj, callback);
            return false
            break;
    }
};
function removeItemAll(arr, value) {
  var i = 0;
  while (i < arr.length) {
    if (arr[i] === value) {
      arr.splice(i, 1);
    } else {
      ++i;
    }
  }
  return arr;
}
// Usage

var groupBy = function (xy, f) {
var x = removeItemAll(xy,"15c")
    return x.reduce(function (a, b, i) {
        var _a;
    
         return ((a[_a = f(b, i, x)] || (a[_a] = [])).push(b), a);
        
       
    }, {});
};

function getRank(num) {
    var _next = parseFloat(num);
    if (num == 'T') { _next = 10 }
    if (num == 'J') { _next = 11 }
    if (num == 'Q') { _next = 12 }
    if (num == 'K') { _next = 13 }
    if (num == 'A') { _next = 14 }
    return _next
}
function getHighRep(data, rep) {

    var hand = data.toString();
    if (hand.indexOf("A") > -1 && rep == 0)
        return 14;
    if (hand.indexOf("K") > -1 && (rep == 0 || rep == 14))
        return 13;
    if (hand.indexOf("Q") > -1 && (rep == 0 || rep >= 13))
        return 12;
    if (hand.indexOf("J") > -1 && (rep == 0 || rep >= 12))
        return 11;
    if (hand.indexOf("T") > -1)
        return 10;
    if (hand.indexOf("9") > -1)
        return 9;
    if (hand.indexOf("8") > -1)
        return 8;
    if (hand.indexOf("7") > -1)
        return 7;
    if (hand.indexOf("6") > -1)
        return 6;
    if (hand.indexOf("5") > -1)
        return 5;
    return rep
}


function compareNumbers(a, b) {
    return b - a;
}

function getKeyNum(cn) {
    var inte = 2;
    switch (cn) {
        case "Aces":
            inte = 14;
            break;
        case "Kings":
            inte = 13;
            break;
        case "Queens":
            inte = 12;
            break;
        case "Jacks":
            inte = 11;
            break;
        case "Tens":
            inte = 10;
            break;
        case "Nines":
            inte = 9;
            break;
        case "Eights":
            inte = 8;
            break;
        case "Sevens":
            inte = 7;
            break;
        case "Sixes":
            inte = 6;
            break;
        case "Fives":
            inte = 5;
            break;

        case "Fours":
            inte = 4;
            break;
        case "Threes":
            inte = 3;
            break;
        case "Ace":
            inte = 14;
            break;
        case "King":
            inte = 13;
            break;
        case "Queen":
            inte = 12;
            break;
        case "Jack":
            inte = 11;
            break;
        case "Ten":
            inte = 10;
            break;
        case "Nine":
            inte = 9;
            break;
        case "Eight":
            inte = 8;
            break;
        case "Seven":
            inte = 7;
            break;
        case "Six":
            inte = 6;
            break;
        case "Five":
            inte = 5;
            break;

        case "Four":
            inte = 4;
            break;
        case "Three":
            inte = 3;
            break;
    }

    return inte;
}

function getNumofCard(cn) {
    var inte = cn;
    switch (cn) {
        case 10:
            inte = "T";
            break;
        case 11:
            inte = "J";
            break;
        case 12:
            inte = "Q";
            break;
        case 13:
            inte = "K";
            break;
        case 14:
            inte = "A";
            break;

    }

    return inte + "";
}

function SortStraight(data) {

    var ranks = []
    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        var high = getHigh(data[i])
        if (!ranks.includes(high)) {
            ranks.push(high)
        }

        //Do something
    }

    ranks.sort(compareNumbers);
    //console.log(ranks)
    return ranks
}

function isStraight(data) {

    var ranks = []

    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        if (!ranks.includes((data[i]))) {
            ranks.push((data[i]))
        }

        //Do something
    }
    if (ranks.includes(14)) {
        ranks.push(1)
    }
    ranks.sort(compareNumbers);

    return getLoopStrOdds(ranks)
}

function getLoopStrOdds(ranks) {

    var isStr = false;
    var myRankFinal = [];
    var myRank = ranks;

    var arrayLength = myRank.length;
//console.log("ranks", ranks) 
    for (var i = 0; i < arrayLength - 4; i++) {
        if (!isStr) {
            isStr = (myRank[i] - 1 == myRank[i + 1]) &&
                (myRank[i + 1] - 1 == myRank[i + 2]) &&
                (myRank[i + 2] - 1 == myRank[i + 3]) &&
                (myRank[i + 3] - 1 == myRank[i + 4]);
            if (isStr) {
                myRankFinal = [myRank[i], myRank[i + 1], myRank[i + 2], myRank[i + 3], myRank[i + 4]]
            }
        }

    }
    //console.log(ranks,isStr)
    if (!isStr && arrayLength > 5) {
        var newRank = myRank.slice(1)

        return getLoopStrOdds(newRank)
    } else {
        if (!isStr) {

            return isStr
        } else {

            return myRankFinal
        }

    }
}

function getCenStrOdds(cards, flop, nuts, num,showAll) {
    //console.log(cards, flop,nuts,num) 
    if (num >= 14) { return [] }
    var mynum = nuts > 0 ? nuts : 0
    var finalCardUser = [];
    var finalCardFlop = [];
    var strOds = [];
 var defflop = flop.concat(cards);

    var cardsHighFlop = SortStraight(defflop);

    var isNuts = false;

    var carStr = 0;

    var start = cardsHighFlop[1] + 4;
    if (start > 14) {
        start = 14
    }

    var end = cardsHighFlop[cardsHighFlop.length - 2] - 5;
    if (end < 1) {
        end = 1
    }

    

 
    var newnuts = 0;
    for (var i = start; i >= end; i--) {
       // console.log(finalCardFlop,i,finalCardFlop.includes(i))
        var res = []

        if (!finalCardFlop.includes(i) && !strOds.includes(i)) {

            defflop = cardsHighFlop;
//console.log("defflop", defflop) 
            //defflop = defflop.concat(cards);
            defflop.push(i);
//console.log("defflop", defflop) 
            res = getCenStrOddsIs(cards, defflop, showAll)
       
            if (res.nuts  && num - 4 < i && res.nuts > newnuts) {
             if ( res.flop.includes(i)) {
            //console.log( res.flop,i)
                if(num){newnuts = res.nuts}
                strOds.push(i)
            }
            }
            defflop.pop();
        }
        // defflop=  defflop.slice(0,(flop.length+1) * -1)
    }
    if (strOds.length == 0 || flop.length == 5) {
        return []
    }
    return {

        nuts: strOds.length > 2 ? 14 : num > 0 ? newnuts : strOds.length*14/2,
        cards: strOds,
        high: getHigh(strOds),
        notRaise: num > 0 ? false : true

    }

}
function getCenStrOddsIs(myCards, flop, showAll) {
 //console.log(myCards, flop) 
    var cards = myCards;
    var cardArr = {}
    if (cards.toString().indexOf("A")>-1 && !cards.includes("1")) {
        cards.push("1")
    }
    
    for (var j = 0; j < cards.length-1; j++) {

        for (var i = (j+1); i < cards.length; i++) {
        var count = cards[j][0]+cards[i][0]
        var canAdd = getHigh(cards[j]) - 4 <= getHigh(cards[i]);
        if(getHigh(cards[j]) < getHigh(cards[i])){
        canAdd = getHigh(cards[i]) - 4 <= getHigh(cards[j]);
        count = cards[i][0]+cards[j][0]
        }
        if(getHigh(cards[j]) == getHigh(cards[i]) ){
        canAdd = false;
        }
       
        if (canAdd) {
cardArr[""+count+""]= [cards[j], cards[i]]
}
       
    }
    }
  
   
    var isstr8 = false;
    var strcards = [];
    var strtotalcards = [];


    var cardsHighFlop = SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1)
    }
  
    for (var prop in cardArr) {
   

            var defflop = cardsHighFlop;
            var finalCardFlop = [];
            var myhand = SortStraight(cardArr[prop]);
            defflop = defflop.concat(myhand);
            defflop = SortStraight(defflop);
           // console.log(defflop)
            if (defflop.includes(14)) {
                defflop.push(1)
            }
            for (var j = 0; j < defflop.length - 1; j++) {

                if (defflop[j] - 4 <= defflop[j + 1] && defflop[j] - 4 <= myhand[ 1] ) {

                    if (!finalCardFlop.includes((defflop[j])) && finalCardFlop.length <= 5) {
                        finalCardFlop.push((defflop[j]))
                    }
                    if (!finalCardFlop.includes((defflop[j + 1])) && finalCardFlop.length <= 5) {
                        finalCardFlop.push((defflop[j + 1]))
                    }

                }
            }
            //console.log(finalCardFlop,SortStraight(cardArr[prop]))
            //finalCardFlop = SortStraight(finalCardFlop);

            var defstr = isStraight(finalCardFlop);
            var defcard = SortStraight(cardArr[prop]);
            if (defstr && defstr.includes(defcard[0]) && defstr.includes(defcard[1]) ) {
                  
                strcards = defcard;
                strtotalcards = defstr
                isstr8 = true
            }


        
    }
    if (isstr8) {
//console.log(finalCardFlop,strtotalcards)
        var muhighCard = strcards[0] - strcards[1] > 3 ? ((14 - (strtotalcards[0] - strcards[0])) + (14 - (strtotalcards[1] - strcards[1]))) / 2 : ((14 - (strtotalcards[0] - strcards[0])));
        if ((cardsHighFlop.includes(strcards[0]) || cardsHighFlop.includes(strcards[1])) && muhighCard == 14) { muhighCard = muhighCard - 1 }
        var fnuts = strtotalcards[0] == 14 ? strtotalcards[0] : muhighCard;
        if (flop.length >= 3 && !showAll) {
            if (checkHaveFlushOdds(flop)) { fnuts = fnuts / 2 }
            if (getDouble(flop)) { fnuts = fnuts / 2 }
        }
        return {

            flop: strtotalcards,
            cards: strcards,
            high: strtotalcards[0] == 14 ? strtotalcards[0] : getHigh(strcards),
            nuts: fnuts
        }
    }
    return []
}
function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}

const checkOccurrence = (array, element, nega) => {
    let counter = 0;
    var cards = []
    for (var j = 0; j < array.length; j++) {

        if (element.includes(array[j])) {
            if (!nega.includes(array[j])) {
                cards.push(array[j])
                counter++;
            } else if (counter < 1) {
                cards.push(array[j])
                counter++;
            }

        }
    }
    return cards

};
function getHigh(data) {

    var hand = removeItemAll(data,"15c")
    try {
        hand = data.toString();
    } catch (error) { }
//console.log(hand)
    if (hand.indexOf("A") > -1 || hand == "14" || hand.indexOf("14") > -1)
        return 14;
    if (hand.indexOf("K") > -1 || hand == "13" || hand.indexOf("13") > -1)
        return 13;
    if (hand.indexOf("Q") > -1 || hand == "12" || hand.indexOf("12") > -1)
        return 12;
    if (hand.indexOf("J") > -1 || hand == "11" || hand.indexOf("11") > -1)
        return 11;
    if (hand.indexOf("T") > -1 || hand == "10" || hand.indexOf("10") > -1)
        return 10;
    if (hand.indexOf("9") > -1)
        return 9;
    if (hand.indexOf("8") > -1)
        return 8;
    if (hand.indexOf("7") > -1)
        return 7;
    if (hand.indexOf("6") > -1)
        return 6;
    if (hand.indexOf("5") > -1)
        return 5;
    if (hand.indexOf("4") > -1)
        return 4;
    if (hand.indexOf("3") > -1)
        return 3;
    if (hand.indexOf("2") > -1)
        return 2;
    if (hand.indexOf("1") > -1)
        return 1;
    if (hand.indexOf("0") > -1)
        return 0;
       
    return getKeyNum(hand)

}

function getNust(mode, cards, flop) {
    var highofcard = getHigh(cards)
    if (mode == "flush") {
        var nust = 14 - highofcard;

        for (var i = highofcard + 1; i <= 14; i++) {

            if (flop.toString().indexOf(getNumofCard(i)) > -1) {
                nust = nust - 1

            }

        }
        return 14 - nust;
    }
    if (mode == "set") {
        var nust = highofcard;

        for (var i = nust + 1; i <= 14; i++) {

            if (flop.toString().indexOf(getNumofCard(i)) == -1) {
                nust = nust + 1

            }

        }
        return nust;
    }
    if (mode == "three") {
        var nust = highofcard;


        return nust;
    }
    if (mode == "full") {
        var nust = 14;

        for (var i = highofcard + 1; i <= 14; i++) {

            if (flop.toString().indexOf(getNumofCard(i)) > -1) {
                nust = nust - 1

            }

        }
        return nust;
    }

}
function haveFlushOdds(cards, flop, showAll) {
    var flopOdds = groupBy(flop, v => v[1]);
    var flushOdds = groupBy(cards, v => v[1]);
    var flush = [];
    var cartFlush = [];
    var count = flop.length == 5 ? 3 : 2;

    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= count) {
                flush.push({
                    cartName: prop,
                    flopCard: flopOdds[prop],
                    high: getHigh(flopOdds[prop])
                })
            }

        }
    }
    for (var propflush in flush) {
        for (var prop in flushOdds) {

            if (flushOdds.hasOwnProperty(prop)) {
                if ((flushOdds[prop].length + flush[propflush].flopCard.length >= 5 && flush[propflush].cartName == prop)) {

                    cartFlush.push({
                        cartName: prop,
                        Card: flushOdds[prop],
                        Flop: flush[propflush].flopCard,
                        notRaise: flush[propflush].flopCard.length + flushOdds[prop].length >= 5 && (!getDouble(flop) || showAll) ? false : true,

                        high: getHigh(flushOdds[prop]),
                        nuts: getNust("flush", flushOdds[prop], flush[propflush].flopCard)
                    })

                }

            }
        }
    }
     if (cartFlush.length == 0) {
  for (var propflush in flush) {
      if (flush[propflush].flopCard.length >= 5) {

                    cartFlush.push({
                  
                    
                        Flop: flush[propflush].flopCard,
                        notRaise: flush[propflush].flopCard.length >= 3 && (!getDouble(flop) || showAll) ? false : true,

               
                        nuts:1
                    })

                }
                }
                }
    if (cartFlush.length == 0) {
        return []
    }
    return cartFlush

    return {
        //haveFlush : flush,

        flushOdds: cartFlush
    }

}
function haveFullOdds(cards, flop, showAll) {
    var full = [];

    var handPer = groupBy(cards, v => v[0]);

    var flopPer = groupBy(flop, v => v[0]);
 
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {

    
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = true;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }

        }
    }
    
    //console.log(showAll)
    if (havePerUp3Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < getHigh(prop)) {
                    highPer = getHigh(prop);

                }
            }

        }
        full = {

            high: highPer,
            nuts: highPer / 4,
            notRaise:showAll?false:true
        }
if(highPer==0){
    full= []
    }
        return full
    }
    
    if (!havePerUpFlop) {

        return full
    }
		var cardArr ={}
    for (var j = 0; j < cards.length-1; j++) {

        for (var i = (j+1); i < cards.length; i++) {
        var count = cards[j][0]+cards[i][0]
        var canAdd = getHigh(cards[j]) == getHigh(cards[i]);
       //console.log(showAll)
        if(!canAdd ) {
        canAdd = true;
        }
       
        if (canAdd) {
cardArr[""+count+""]= [cards[j], cards[i]]
}
       
    }
    }
   // console.log(cardArr)
    var perUp2 = 0;
    var perUp3 = 0;
    var high = 0;
     for (var propcard in cardArr) {
     
    var total = flop.concat(cardArr[propcard]);
    
    var tot = groupBy(total, v => v[0]);

    for (var prop in tot) {
    
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 3 &&  getHigh(perUp3) <= getHigh(prop)) {
                perUp3 = prop

            }
            

        }
    }
    
//console.log(cardArr[propcard])
      
    }
  if(handPer[perUp3] && handPer[perUp3].length >= 2){
      //console.log(perUp3,perUp2)
   
    for (var prop in flopPer) {
    
        if (flopPer.hasOwnProperty(prop)) {
          
            if (flopPer[prop].length == 2 &&  getHigh(perUp2) <= getHigh(prop) && perUp3 != prop) {
                perUp2 = prop

            }

        }
    }
    }else{
     //console.log(perUp3,perUp2,handPer,flopPer)
    for (var prop in tot) {
    
        if (tot.hasOwnProperty(prop)) {
          
            if (tot[prop].length == 2 &&  getHigh(perUp2) <= getHigh(prop) && perUp3 != prop) {
                perUp2 = prop

            }

        }
    }
    }
    if(perUp3==0 ||perUp2==0){
    return []
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
            //Hidden Full
            if (getHigh(perUp3) > getHigh(perUp2)) {
                //Good Full

                full = {
                    set: perUp3,
                    per: perUp2,
                    highSet: getHigh(perUp3),
                    highPer: getHigh(perUp2),
                    //notRaise:showAll?false:true,
                    nuts: getNust("full", perUp3, flop) 
                }

            } else {
                full = {
                    set: perUp3,
                    per: perUp2,
                    highSet: getHigh(perUp3),
                    highPer: getHigh(perUp2),
                    //notRaise:showAll?false:true,
                    nuts: getNust("full", perUp3, flop) - (flop.length-2)
                }

            }
        } else {
            if (getHigh(perUp3) > getHigh(perUp2)) {
                //Good Full

                full = {
                    set: perUp3,
                    per: perUp2,
                    highSet: getHigh(perUp3),
                    highPer: getHigh(perUp2),
                    //notRaise:showAll?false:true,
                    nuts: getNust("full", perUp2, flop.toString().replace(perUp3,"").replace(perUp3,""))
                }
            } else {
                full = {
                    set: perUp3,
                    per: perUp2,
                    highSet: getHigh(perUp3),
                    highPer: getHigh(perUp2),
                    //notRaise:showAll?false:true,
                    nuts: getNust("full", perUp3, flop.toString().replace(perUp2,"").replace(perUp2,"").replace(perUp3,"").replace(perUp3,""))- (flop.length-2)
                }

            }
        }
    //return false
    


    return full

}
function haveSetOdds(cards, flop, showAll) {

    var handPer = groupBy(cards, v => v[0]);


    var havePerUpHand = false;
    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length >= 2) {
                havePerUpHand = true;
            }

        }
    }

    if (!havePerUpHand) {

        return []
    }
    var flopPer = groupBy(flop, v => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }

        }
    }

    if (havePerUpFlop) {

        return []
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = groupBy(total, v => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && high < getHigh(prop)) {
                var fnuts = getNust("set", tot[prop], flop);
                
                high = getHigh(prop);
                set = {
                    set: prop,
                    high: getHigh(prop),
                    nuts: fnuts,
                    notRaise:(!showAll && (checkHaveFlushOdds(flop)||checkHaveStrOdds(flop)))?true:false
                }
            }

        }
    }

    return set

}
function haveTreeOdds(cards, flop, showAll) {

    var handPer = groupBy(cards, v => v[0]);

    var flopPer = groupBy(flop, v => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }

        }
    }

    if (!havePerUpFlop) {

        return []
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = groupBy(total, v => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && cards.toString().indexOf(prop) > -1 && high < getHigh(prop)) {
                high = getHigh(prop);
                var fnuts = getNust("three", cards.toString().replace(prop, "").replace(prop, "").replace(prop, ""), flop);
               
                set = {
                    set: prop,
                    high: getHigh(prop),
                    nuts: fnuts,
                    notRaise:(!showAll && (checkHaveFlushOdds(flop)||checkHaveStrOdds(flop)))?true:false
                }
            }

        }
    }

    return set

}

function getTwoPerOdds(cards, flop, showAll) {
    var per = []


    var handPer = groupBy(cards, v => v[0]);
    var cardsflop = [];
    var cardsflopDeck = [];


    var arrayLength = flop.length;

    for (var i = 0; i < arrayLength; i++) {

        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(getHigh(flop[i]))

        }
        cardsflopDeck.push(getHigh(flop[i]))

    }
     var flopPer = groupBy(flop, v => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }

        }
    }

   
 
    if (cardsflop.length < 2 && getDouble(flop)) {
     if (!havePerUpFlop) {

     cardsflop = [];
    }
        
        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2) {
                    cardsflop.push(getHigh(handPer[prop]))
                }

            }
        }
        cardsflop.push(getHigh(getDouble(flop)))
    }

    cardsflopDeck.sort(compareNumbers);
    cardsflop.sort(compareNumbers);
      // console.log(cardsflop,cardsflopDeck)
    if (cardsflop.length >= 2) {
        per = {
            notRaise: showAll?false:true,
            nuts: (cardsflop[0] + cardsflop[1]) / 2
        }
    }

    return per


}
function getPerOdds(cards, flop, showAll) {
    var per = []


    var handPer = groupBy(cards, v => v[0]);
    var cardsflop = [];
    var cardsflopDeck = [];


    var arrayLength = flop.length;
   var flopPer = groupBy(flop, v => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }

        }
    }

    if (havePerUpFlop) {

        return []
    }
    for (var i = 0; i < arrayLength; i++) {

        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(getHigh(flop[i]))

        }
        cardsflopDeck.push(getHigh(flop[i]))

    }
    if (cardsflop.length < 2 && getDouble(flop)) {
        cardsflop = [];
        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2) {
                    cardsflop.push(getHigh(handPer[prop]))
                }

            }
        }
        cardsflop.push(getHigh(getDouble(flop)))
    }

    cardsflopDeck.sort(compareNumbers);
    cardsflop.sort(compareNumbers);
    var defflop = SortStraight(cards);
    const index = defflop.indexOf(cardsflop[0]);
if (index > -1) { // only splice array when item is found
  defflop.splice(index, 1); // 2nd parameter means remove one item only
}
   // console.log(defflop)
    if (cardsflop.length >= 1) {
        per = {
            notRaise: showAll?false:true,
            nuts: (defflop[0]+cardsflop[0])/2
        }
    }

    return per


}

function haveFourOdds(cards, flop, showAll) {
    var four = [];

    var handPer = groupBy(cards, v => v[0]);

    var flopPer = groupBy(flop, v => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {

            if (flopPer[prop].length == 4) {
                havePerUp4Flop = true;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = prop;
            }

        }
    }
    if (havePerUp4Flop) {
        
   four = {

            nuts: getHigh(cards),
            notRaise:flop.length == 5 ? false : true,
        }
        return four
    }
   
    if (havePerUp3Flop) {
       if(cards.toString().indexOf(havePerUp3Flop)>-1) {
         four = {

            nuts:  getHigh(havePerUp3Flop),
            notRaise:flop.length == 5 ? false : true,
        }
        }
        return four
    }
     
    if (!havePerUpFlop) {
    return four
    }
     var total = flop.concat(cards);
    
    var tot = groupBy(total, v => v[0]);

    for (var prop in tot) {
    
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 4) {
                four = {

            nuts: getHigh(prop),
            notRaise:false
        }
        }
       
            }
            

        }
    

    return four

}

decide.CreateOdds = function (cards, flop, player, showAll) {
    var Odds = {};
    Odds.four = []
     Odds.full = []
    Odds.flush = []
    Odds.set = []
    Odds.straight = []
    Odds.isstraight = []
    Odds.three = []
     Odds.two = []
    Odds.per = []

    Odds.Player = player;
 Odds.four = haveFourOdds(cards, flop, showAll);

    if (Odds.four.length == 0) {
    Odds.full = haveFullOdds(cards, flop, showAll);

    if (Odds.full.length == 0) {
        Odds.flush = haveFlushOdds(cards, flop, showAll);
        if ((Odds.flush.length == 0 || Odds.flush[0].notRaise) || flop.length < 5) {
            var isstr = getCenStrOddsIs(cards, flop, showAll)
            Odds.isstraight = isstr;

            if (Odds.isstraight.length == 0 || flop.length < 5) {
                Odds.set = haveSetOdds(cards, flop, showAll);

                Odds.straight = getCenStrOdds(cards, flop, isstr.cards ? isstr.high : 0, isstr.cards ? isstr.cards[0] : 0,showAll);
                // Odds.straight =[]
                if (Odds.set.length == 0) {
                    Odds.three = haveTreeOdds(cards, flop, showAll);
                    if (Odds.three.length == 0) {
                        Odds.two = getTwoPerOdds(cards, flop, showAll);
                         if (Odds.two.length == 0) {
                        Odds.per = getPerOdds(cards, flop, showAll);
                    }
                    }
                }
            }
        }

    }
}
    return Odds

};
decide.GetOdds = function (obj) {
    var oDDs = [];
    var fourHigh = 0;
      var flushHigh = 0;
    var setHigh = 0;
    var str8High = 0;
    var fullHigh = 0;
    var twoHigh = 0;
    var perHigh = 0;
    var showAll = checkShow(obj);
	var AllBots = checkAllBots(obj)
    //console.log("showAll",showAll)
	console.info("showAll",showAll,"AllBots",AllBots)
    //var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll);
var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll);
    //console.log("PlayeroDDs1", PlayeroDDs)
	if(!AllBots){
   // console.log("showAll",showAll)
    

   //console.log("PlayeroDDs1", PlayeroDDs)
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {

                var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll);
                //console.log(uOdds)
                if (uOdds.flush.length > 0) {
                    if (flushHigh < uOdds.flush[0].nuts) {
                        flushHigh = uOdds.flush[0].nuts
                    }
                    for (var j = 0; j < uOdds.flush.length; j++) {
                        if (uOdds.flush[j].Flop.length >= 3) {
                            PlayeroDDs.isstraight = [];
                            PlayeroDDs.straight = []
                            PlayeroDDs.per.notRaise = true
                            if (obj.flopCards.length == 5) {
                                PlayeroDDs.set = []
                                PlayeroDDs.three = []
                                PlayeroDDs.two = []
                                   PlayeroDDs.per = []
                            }

                        }

                    }

                }
                if (uOdds.four.nuts) {
if (fourHigh < uOdds.four.nuts) {
                        fourHigh = uOdds.four.nuts
                    }
                   PlayeroDDs.full = [];
                    PlayeroDDs.flush = [];
                    PlayeroDDs.isstraight = [];
                      PlayeroDDs.set = []
                       PlayeroDDs.two = []
                        PlayeroDDs.per = []
                    PlayeroDDs.three = []

                     
                }
                if (uOdds.full.nuts) {

                    if (fullHigh < uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet) {
                        fullHigh = uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet
                    }
                    //console.log("fullHigh",fullHigh)
                    PlayeroDDs.flush = [];
                    PlayeroDDs.isstraight = [];
                    PlayeroDDs.per.notRaise = true
                    if (uOdds.full.highSet > PlayeroDDs.set.nuts || (uOdds.full.highSet == PlayeroDDs.set.nuts && uOdds.full.highPer > getHigh(obj.convertedCards)) || obj.flopCards.length == 5) {
                        PlayeroDDs.set = []
                         PlayeroDDs.two = []
                        PlayeroDDs.per = []
                    }

                    if (uOdds.full.highSet > PlayeroDDs.three.high || (uOdds.full.highSet == PlayeroDDs.three.high && uOdds.full.highPer > getHigh(obj.convertedCards)) || obj.flopCards.length >= 4) {
                        PlayeroDDs.three = []
                         PlayeroDDs.two = []
                        PlayeroDDs.per = []
                    }else{
                   // console.log(uOdds.full.highSet , PlayeroDDs.three.high)
                    if (uOdds.full.highSet <= PlayeroDDs.three.high) {
                    //console.log(PlayeroDDs.three)
                        PlayeroDDs.three.notRaise = true
                    }
                    }
                     
                }

                if (uOdds.set.nuts) {
                    if (setHigh < uOdds.set.nuts) {
                        setHigh = uOdds.set.nuts
                    }
                    PlayeroDDs.two = []
                        PlayeroDDs.per = []
						try{
							if(obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3){
						 PlayeroDDs.flush = [];
					}
						}catch(err){}
                    
                }
                if (uOdds.three.nuts) {
                    if (setHigh < uOdds.three.nuts) {
                        setHigh = uOdds.three.nuts
                    }
                     PlayeroDDs.two = []
                    PlayeroDDs.per = []
                     try{
							if(obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3){
						 PlayeroDDs.flush = [];
					}
						}catch(err){}
                }
                if (uOdds.two.nuts) {
                    if (twoHigh < uOdds.two.nuts) {
                        twoHigh = uOdds.two.nuts
                    }
                    PlayeroDDs.per = []
                }
                  if (uOdds.per.nuts) {
                    if (perHigh < uOdds.per.nuts) {
                        perHigh = uOdds.per.nuts
                    }
                }
                if (uOdds.isstraight.high) {
                    if (str8High < uOdds.isstraight.high) {
                        str8High = uOdds.isstraight.high
                    }
                    PlayeroDDs.set.notRaise = true
					 PlayeroDDs.three.notRaise = true
					 try{
							 PlayeroDDs.two.notRaise = true
                 PlayeroDDs.per = []
						}catch(err){}
                    if (str8High > PlayeroDDs.straight.high || obj.flopCards.length == 5) {
                        PlayeroDDs.straight = []
                        PlayeroDDs.set = []
                         PlayeroDDs.two = []
                    PlayeroDDs.per = []

                    }
                }
                if (obj.pls[prop].Helper.indexOf("a Royal Flush") > -1 || obj.pls[prop].Helper.indexOf("a Straight Flush") > -1) {

                    PlayeroDDs.full = []
                    PlayeroDDs.flush = []
                    PlayeroDDs.set = []
                    PlayeroDDs.straight = []
                    PlayeroDDs.isstraight = []
                    PlayeroDDs.three = []
                      PlayeroDDs.two = []
                    PlayeroDDs.per = []
                }
                oDDs.push(uOdds)
            }

        }
    }
	}
    if (PlayeroDDs.four.nuts) {
        if (fourHigh > PlayeroDDs.four.nuts) {
            PlayeroDDs.four = [];
             PlayeroDDs.full = [];
            PlayeroDDs.flush = []
            PlayeroDDs.set = []
            PlayeroDDs.straight = []
            PlayeroDDs.isstraight = []
            PlayeroDDs.three = []
              PlayeroDDs.two = []
            PlayeroDDs.per = []
        }

    }
     if (PlayeroDDs.full.nuts) {
        if (fullHigh > PlayeroDDs.full.nuts + PlayeroDDs.full.highPer + PlayeroDDs.full.highSet) {
            PlayeroDDs.full = [];
            PlayeroDDs.flush = []
            PlayeroDDs.set = []
            PlayeroDDs.straight = []
            PlayeroDDs.isstraight = []
            PlayeroDDs.three = []
              PlayeroDDs.two = []
            PlayeroDDs.per = []
        }

    }

    if (PlayeroDDs.flush.length > 0) {
        for (var j = 0; j < PlayeroDDs.flush.length; j++) {
            if (PlayeroDDs.flush[j].Flop.length >= 3) {
                PlayeroDDs.isstraight = [];
                PlayeroDDs.straight = []
                if (obj.flopCards.length == 5) {
                    PlayeroDDs.set = []
                    PlayeroDDs.three = []
                      PlayeroDDs.two = []
                    PlayeroDDs.per = []
                }

            } else {
                if (obj.flopCards.length == 5) {
                    PlayeroDDs.set = []
                    PlayeroDDs.three = []
                    PlayeroDDs.isstraight = [];
                    PlayeroDDs.straight = []
                      PlayeroDDs.two = []
                    PlayeroDDs.per = []
                }
            }
if (flushHigh > PlayeroDDs.flush[j].nuts) {
            PlayeroDDs.flush = []
        }
        }

    }
    if (PlayeroDDs.set.nuts) {
        if (setHigh > PlayeroDDs.set.nuts) {
            PlayeroDDs.set = [];
              PlayeroDDs.two = []
            PlayeroDDs.per = []
        }

    }
    if (PlayeroDDs.three.nuts) {
        if (setHigh > PlayeroDDs.three.nuts) {
            PlayeroDDs.three = [];
              PlayeroDDs.two = []
            PlayeroDDs.per = []
        }

    }
     if (PlayeroDDs.two.nuts) {
        if (twoHigh > PlayeroDDs.two.nuts) {
            PlayeroDDs.two = [];
             PlayeroDDs.per = [];
        }

    }
    if (PlayeroDDs.per.nuts) {
        if (perHigh > PlayeroDDs.per.nuts) {
            PlayeroDDs.per = [];
        }

    }

    if (PlayeroDDs.isstraight.high) {
        if (str8High > PlayeroDDs.isstraight.high) {
            PlayeroDDs.isstraight = [];
PlayeroDDs.straight.notRaise = true
        }
        if (obj.flopCards.length == 5) {
            PlayeroDDs.set = []
            PlayeroDDs.three = []
              PlayeroDDs.two = []
            PlayeroDDs.per = []
        }

    }
    var odds = 0;
    var oddsName = "";
    var oddsStr = [];
    var oddsCount = 0;
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop)) {



            if (PlayeroDDs[prop].nuts) {

                if (odds < PlayeroDDs[prop].nuts || (odds <= PlayeroDDs[prop].nuts && !PlayeroDDs[prop].notRaise)) {
                    odds = PlayeroDDs[prop].nuts
                    oddsStr = PlayeroDDs[prop]
                    oddsName = prop
                }
                // odds = odds + PlayeroDDs[prop].nuts
                //oddsCount = oddsCount + 1

            }

        }
    }

    if (PlayeroDDs["flush"].length > 0) {

        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {

            if (PlayeroDDs["flush"][i].nuts) {

                if (odds < PlayeroDDs["flush"][i].nuts  || (odds <= PlayeroDDs["flush"][i].nuts && !PlayeroDDs["flush"][i].notRaise)) {
                    odds = PlayeroDDs["flush"][i].nuts
                    oddsStr = PlayeroDDs["flush"][i]
oddsName = "flush"
                }
                //odds = odds + PlayeroDDs[prop][i].nuts
                // oddsCount = oddsCount + 1
            }
        }

    }

    var finalcount = oddsCount > 0 ? oddsCount : 1
    var finalOds = odds * 100 / 14 / finalcount;
    var isFlush = true;
    if (oddsStr.notRaise) { isFlush = false }
	if (oddsName == "") { isFlush = false }
	if(oddsName=="four" && showAll){finalOds=100}
    //console.log("PlayeroDDs", oddsStr)
    return [finalOds, isFlush, showAll,oddsName]

};

decide.CleanOddsFlsuh = function (obj) {
    var TotalHigh = 0;
    var SHigh = 0;
    var CHigh = 0;
    var HHigh = 0;
    var DHigh = 0;
    var PlayeroDDs = getFlushOdds(obj,obj.convertedCards);

    var PlayeroDDsNew = [];
    for (var prop in obj.pls) {

        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {

                var uOdds = getFlushOdds(obj,obj.pls[prop].Cards);
               // console.log(uOdds)
                for (var j = 0; j < uOdds.length; j++) {
                    if (uOdds[j].cartName == "c") {
                        if (CHigh < uOdds[j].high) {
                            CHigh = uOdds[j].high
                        }
                    }
                    if (uOdds[j].cartName == "d") {
                        if (DHigh < uOdds[j].high) {
                            DHigh = uOdds[j].high
                        }
                    }
                    if (uOdds[j].cartName == "s") {
                        if (SHigh < uOdds[j].high) {
                            SHigh = uOdds[j].high
                        }
                    }
                    if (uOdds[j].cartName == "h") {
                        if (HHigh < uOdds[j].high) {
                            HHigh = uOdds[j].high
                        }
                    }

                }

            }

        }
    }

    for (var j = 0; j < PlayeroDDs.length; j++) {

        if (PlayeroDDs[j].cartName == "c") {
            if (CHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "d") {
            if (DHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "s") {
            if (SHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "h") {
            if (HHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }

    }

    for (var j = 0; j < PlayeroDDsNew.length; j++) {
        TotalHigh = TotalHigh + PlayeroDDsNew[j].high;

    }
    //console.log("DHigh",DHigh,TotalHigh)
    //console.log("uOdds",PlayeroDDsNew,PlayeroDDs.length)

    return PlayeroDDsNew

};
decide.CleanOddsPerPlayer = function (obj,Player,Hand) {
    var TotalHigh = 0;
     var noOut = 0;
    var DHigh = 0;
     var handPer = groupBy(Hand, v => v[0]);
        var perCount = 0;

      
            for (var prop in handPer) {
                if (handPer.hasOwnProperty(prop)) {
                    if (handPer[prop].length == 2) {
                        perCount=getHigh(prop)
                    }
    
                }
            }
   if(perCount){
    for (var prop in obj.pls) {

        if (obj.pls.hasOwnProperty(prop)) {
      
				  if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != Player  && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {

                var uOdds = groupBy(obj.pls[prop].Cards, v => v[0]);
                
                 for (var propplayer in uOdds) {
              
                if (uOdds.hasOwnProperty(propplayer)) {
          var propHigh = getHigh(propplayer);
    if(propHigh==perCount){noOut=noOut+uOdds[propplayer].length
                
            }
            if(propHigh>perCount && uOdds[propplayer].length==1){
              //console.log(propplayer)
            TotalHigh=TotalHigh+uOdds[propplayer].length
                
            }
           

                }

            }

        }
    }
    }
}

    return [perCount,noOut,TotalHigh]

};
decide.CleanOddsPer = function (obj) {
    
    
    var DHigh = 0;
    var PPer = decide.CleanOddsPerPlayer(obj,obj.Player,obj.convertedCards)
    //console.log("PPer",PPer,checkPlayerNumber(obj))
    
   var perCount = PPer[0]
    var noOut = PPer[1];
    var TotalHigh = PPer[2];
   if(perCount){
    for (var prop in obj.pls) {

        if (obj.pls.hasOwnProperty(prop)) {
      
				  if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Bot == false && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {
 var uOdds = decide.CleanOddsPerPlayer(obj,obj.pls[prop].Player,obj.pls[prop].Cards)
 if(uOdds[0]){
               if (DHigh < getHigh(uOdds[0]) && uOdds[1]<=noOut) {
                        DHigh=getHigh(uOdds[0])
                    }
                 //console.log(uOdds)
                 

                }
                }

            }

        }
    }
    perCount=perCount<DHigh?0:perCount
    noOut=perCount>0?noOut:0
    //console.log("DHigh",DHigh,perCount)
    //console.log("uOdds",PlayeroDDsNew,PlayeroDDs.length)

    return [perCount,noOut,TotalHigh]

};
decide.CleanOddsHigh = function (obj) {
    var TotalHigh = 0;
     var noOut = 0;
    var DHigh = 0;
     var handPer = getHigh(obj.convertedCards[0]);
     var handPer2 = getHigh(obj.convertedCards[1]);
     var  perCount = (handPer + handPer2)/2
   
    for (var prop in obj.pls) {

        if (obj.pls.hasOwnProperty(prop)) {
      
				  if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player  && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {

                var uOdds = groupBy(obj.pls[prop].Cards, v => v[0]);
                
                 for (var propplayer in uOdds) {
              
                if (uOdds.hasOwnProperty(propplayer)) {
          var propHigh = getHigh(propplayer);
    if(propHigh==handPer){noOut=noOut+uOdds[propplayer].length
                
            }
            if(propHigh==handPer2){noOut=noOut+uOdds[propplayer].length
                
            }
            if(propHigh>handPer && uOdds[propplayer].length==1){
              //console.log(propplayer)
            TotalHigh=TotalHigh+uOdds[propplayer].length
                
            }
             if(propHigh>handPer2 && uOdds[propplayer].length==1){
              //console.log(propplayer)
            TotalHigh=TotalHigh+uOdds[propplayer].length
                
            }
           

                }

            }

        }
    }
    }


    return [perCount,noOut,TotalHigh]

};

decide.call = function (callback, precentage) {
	var tt = randomIntFromInterval(2, 4)
   console.log({
        Button: "Call",
        Amount: 0,
        Sec: tt
    });
    callback({
        Button: "Call",
        Amount: 0,
        Sec: tt
    });

};
decide.fold = function (callback, precentage) {
var tt = randomIntFromInterval(1, 4)
 console.log({
        Button: "Fold",
        Amount: 0,
        Sec: tt
    });
    callback({
        Button: "Fold",
        Amount: 0,
        Sec: tt
    });

};
decide.raise = function (amount, callback, precentage) {
    var tt = randomIntFromInterval(3, 5)
     console.log({
        Button: "Bet",
        Amount: parseInt(amount),
        Sec: tt
    });
     callback({
        Button: "Bet",
        Amount: parseInt(amount),
        Sec: tt
    });

};
decide.check = function (callback, precentage) {
    var tt = randomIntFromInterval(1, 3)
     console.log({
        Button: "Check",
        Amount: 0,
        Sec: tt
    });
    callback({
        Button: "Check",
        Amount: 0,
        Sec: tt
    });

};
decide.callfunctionNuts = function (obj, callback, precentage, precentageRase) {

    console.log("callfunctionNuts", precentage, precentageRase)
    if (obj.place > 0) {
        decide.fold(callback, precentage);
        return false
    }
    if (obj.Pot == 0) {
        decide.call(callback, precentage);
        return false
    }
    if (obj.amounts.Rest - obj.Call < obj.Call) {

        decide.raise(obj.amounts.Rest, callback, precentage);
        return false
    }
    decide.raise(obj.inPot * precentage, callback, precentage);

    return false

};
decide.callfunction = function (obj, callback, myprecentage) {

    var precentage = myprecentage[0];
var canRaise = myprecentage[1];
    var rest = obj.Chips;



    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;
    var Uipot = checkInpot(obj)
if (!Uipot) {
        canRaise = false
    }
    if (obj.place == 0 && obj.Pot != 0 && canRaise && myprecentage[2] && rest > callAm * 2) {
       // decide.raise(total, callback, precentage);
       // return false

    }
    if (obj.place == 0 && myprecentage[2] && rest <= obj.amounts.BB * 10) {
       // decide.call(callback, precentage);
       // return false

    }


    if (100 == precentage && canRaise) {

        if (obj.Pot == 0) {
            decide.call(callback, precentage);
            return false
        }
        if (callAm < total && callAm >= obj.amounts.BB) { total = callAm * 2 }

        decide.raise(total, callback, precentage);
        return false
    }
    if (50 <= precentage && canRaise && myprecentage[2]) {
        if (obj.Pot == 0) {
            decide.call(callback, precentage);
            return false
        }
        
            decide.raise(total/2, callback, precentage);
            return false
        
      
    }
    if (85 <= precentage) {
        if (obj.Pot == 0) {
            decide.call(callback, precentage);
            return false
        }
        if (rest - (callAm) <= obj.amounts.BB * 5) {
            decide.raise(rest, callback, precentage);
            return false
        }
        decide.call(callback, precentage);
        return false
    }
    //console.log(myprecentage,callAm * 100 / inPot)
  
    if (callAm * 100 / inPot <= precentage && myprecentage[2]) {
        
        decide.call(callback, precentage);
        return false
    }
    if (precentage>0&&canRaise && myprecentage[2]) {
        
        if (obj.Pot == 0) {
            decide.call(callback, precentage);
            return false
        }
        
            decide.raise(total/2, callback, precentage);
            return false
    }

if (callAm * 100 / total <= precentage || callAm <= inPot  ) {
if (obj.state < 3 || callAm * 100 / total <= precentage) {
            decide.call(callback, precentage);
            return false
        }
        
    }
if (rest <= (rest + inPot) / 4) {
        decide.call(callback, precentage);
        return false
    }

    decide.fold(callback, myprecentage[0]);
    return false;


};

decide.checkfunction = function (obj, callback, myprecentage) {

    var precentage = myprecentage[0];

    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;

	 var pNum = checkPlayerNumber(obj)
   //pNum = 2
    var inPotPercent = (inPot) * (pNum / 2) / (total) * 100 * pNum;
    if (inPotPercent > 100) { inPotPercent = 100 }
   // console.log(inPotPercent,myprecentage)
if((myprecentage[3]=="full" || myprecentage[3]=="set" || myprecentage[3]=="three" || myprecentage[3]=="four" || myprecentage[3]=="isstraight" || myprecentage[3]=="two" || myprecentage[3]=="per"||myprecentage[3]=="flush") && myprecentage[1]&& myprecentage[2] && obj.state>=2){
     decide.raise(total, callback, precentage);
            return false
    }
    if((myprecentage[3]=="set" || myprecentage[3]=="three" || myprecentage[3]=="per" || myprecentage[3]=="isstraight" || myprecentage[3]=="two"||myprecentage[3]=="flush") && myprecentage[1]&& myprecentage[2]){
     decide.raise(total, callback, precentage);
            return false
    }
    if (100 == precentage && myprecentage[1]) {


            decide.raise(total, callback, precentage);
            return false
        }
    if (inPotPercent <= precentage && myprecentage[1]) {
        
        if (86 < precentage) {


            decide.raise(total / 2, callback, precentage);
            return false
        }

    }
    
    if (precentage > 0) {
        if (rest <= (rest + inPot) / 10) {
            decide.raise(rest, callback, precentage);
            return false
        }

    }

    decide.check(callback, myprecentage[0]);
    return false

};

decide.handTen = function (obj, callback) {

    switch (obj.state) {
        case 1:
            decide.check(callback, 50);
            return false
            break;
        case 2:
            if (obj.Button2 == "Check") {

                decide.raise(obj.inPot, callback, 50);
                return false

            } else if (obj.Button2 == "Call") {

                decide.callfunctionNuts(obj, callback, 100, 100);
                return false
            }

            break;
        case 3:
            if (obj.Button2 == "Check") {

                decide.raise(obj.inPot, callback, 60);
                return false

            } else if (obj.Button2 == "Call") {

                decide.callfunctionNuts(obj, callback, 100, 100);
                return false
            }
            break;
    }

};
decide.handNine = function (obj, callback) {
    console.log("handNine", obj.state, obj.Player, obj.Button2, obj.place, obj.Helper, obj.Call)
    if (obj.place > 0 && obj.state < 3) {
        if (obj.Button2 == "Call") {
            decide.fold(callback, 50);
            return false
        }
        decide.check(callback, 50);
        return false
    }
    switch (obj.state) {
        case 1:
            if (obj.Button2 == "Check") {

                decide.raise(obj.MaxRaise, callback, 40);
                return false

            } else if (obj.Button2 == "Call") {
                if (obj.Pot == 0) {
                    decide.call(callback, 40);
                    return false
                }
                if (obj.Call < obj.inPot) {

                    decide.raise(obj.Call * 2, callback, 40);
                    return false

                }
                decide.call(callback, 50);

                return false
            }

            break;
        case 2:
            if (obj.Button2 == "Check") {

                decide.raise(obj.MaxRaise, callback, 40);
                return false

            } else if (obj.Button2 == "Call") {

                decide.call(callback, 40);

                return false
            }

            break;
        case 3:
            if (obj.Button2 == "Check") {

                decide.raise(obj.MaxRaise, callback, 20);
                return false

            } else if (obj.Button2 == "Call") {
                if (obj.Pot == 0) {
                    decide.call(callback, 50);
                    return false
                }

                decide.raise(obj.Call * 2, callback, 40);
                return false

                decide.call(callback, 40);

                return false

            }
            break;
    }

};
function getRaiseAmount(obj, callback,RaiseAmount,precentage){
if (obj.Pot == 0 ) {
                decide.call(callback, precentage);
                return false
            }
         
                decide.raise(RaiseAmount, callback, precentage);
                return false
            
}
function getCallAmount(obj, callback,precentage,callAm,inPot,rest){
if (obj.Pot == 0 ) {
                decide.call(callback, precentage);
                return false
            }
 if (rest - callAm <= obj.amounts.BB * 5 && rest > callAm) {
                 decide.raise(rest, callback, precentage);
                return false
            }
         decide.call(callback, precentage);
                return false
               
   }
decide.preFlop = function (obj, callback) {
    var rest = obj.Chips;
    var winner = rest > obj.amounts.BB*80?true:false;
    var looser = rest < obj.amounts.BB*11?true:false;
        var flushOdds = decide.CleanOddsFlsuh(obj);
        var perOdds = decide.CleanOddsPer(obj);
       
           var gethighOdds = decide.CleanOddsHigh(obj);
           var highOdds = gethighOdds[0]/6;
         console.info(flushOdds,perOdds,gethighOdds,highOdds)

        var canCall = false;
        var inPot = obj.inPot > 0 ? obj.inPot : 0;
        if(flushOdds.length >= 1 && flushOdds[0].out<4){canCall=true}
        if(perOdds[0]>0 && perOdds[1]<2){canCall=true}
        if(looser && highOdds>6 && gethighOdds[1]<3){canCall=true}
       if(highOdds>10&& gethighOdds[1]<3){canCall=true}
       var RaiseAmount = perOdds[0]*obj.amounts.BB;
       if (RaiseAmount==0) {
       RaiseAmount=(highOdds- gethighOdds[1]- gethighOdds[2])*obj.amounts.BB/4
       if (RaiseAmount<0) {RaiseAmount=0}
       }
       if (flushOdds.length >= 1&& flushOdds[0].out<4) {
       if (RaiseAmount==0) {RaiseAmount=(flushOdds[0].high-flushOdds[0].out)*obj.amounts.BB/10;}else{
       RaiseAmount=RaiseAmount*2;
       }
    
       }
	   if (RaiseAmount<0) {RaiseAmount=0}
       if (winner) {
       RaiseAmount=RaiseAmount/2
       }
        if (looser) {
       RaiseAmount=RaiseAmount*2
       }
       RaiseAmount=parseInt(((RaiseAmount/obj.amounts.BB))*obj.amounts.BB)+obj.amounts.BB;
        var precentage = 50
        var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
	console.info(obj.convertedCards,flushOdds,perOdds,gethighOdds,canCall,RaiseAmount,callAm,inPot)
        if (obj.Button2 == "Call") {
    if (canCall) {
    if (callAm < RaiseAmount+inPot && callAm < RaiseAmount/2 && inPot < RaiseAmount) {
    getRaiseAmount(obj, callback,callAm*2>RaiseAmount?callAm*2:RaiseAmount,precentage)
    return false
    }
  
                    if (RaiseAmount+inPot >= callAm/2 || (perOdds[0]>0 && perOdds[1]==0 && perOdds[2]<2) || (gethighOdds[0]>0 && gethighOdds[1]==0 && gethighOdds[2]<2)|| (flushOdds.length >= 1&& flushOdds[0].out<4)) {
			 getCallAmount(obj,callback, precentage,callAm,inPot,rest);
                    return false
                    }
                    
                     
    
    }
       if ((callAm<=obj.amounts.BB  && inPot>0)) {
			 decide.call(callback, precentage);
                    return false
                    }
    
           
	
            
    
    
    
    
            decide.fold(callback, precentage);
            return false;
        } else if (obj.Button2 == "Check") {
    if(perOdds[1]>0){canCall=false}
            if (canCall ) {
                decide.raise(RaiseAmount,callback, precentage);
                return false
            }
         
    
            decide.check(callback, precentage);
            return false
    
        }
    };

decide.flop = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {

        decide.checkfunction(obj, callback, precentage, precentage);
        return false
    } else if (obj.Button2 == "Call") {

        decide.callfunction(obj, callback, precentage, precentage);

        return false
    }
};
decide.turn = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {

        decide.checkfunction(obj, callback, precentage, precentage);
        return false
    } else if (obj.Button2 == "Call") {

        decide.callfunction(obj, callback, precentage, precentage);

        return false
    }
};
decide.river = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {

        decide.checkfunction(obj, callback, precentage, precentage);
        return false
    } else if (obj.Button2 == "Call") {

        decide.callfunction(obj, callback, precentage, 0);

        return false
    }

};
function getFlushOdds(obj,cards) {

    var flushOdds = groupBy(cards, v => v[1]);
    var flush = [];
    var cartFlush = [];

    for (var prop in flushOdds) {

        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 2) {
                cartFlush.push({
                    cartName: prop,
                    Card: flushOdds[prop],
                    high: getHigh(flushOdds[prop]),
                    out: getFlushOddsOut(obj,prop),

                })

            }

        }
    }
    //console.log("cartFlush",cartFlush)
    if (cartFlush.length == 0) {
        return []
    }
    return cartFlush

}
function getFlushOddsOut(obj,name) {
var noOut = 0;
for (var prop in obj.pls) {

        if (obj.pls.hasOwnProperty(prop)) {
      
				  if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player  && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips>0) {

                var uOdds = groupBy(obj.pls[prop].Cards, v => v[1]);
                
                 for (var propplayer in uOdds) {
              
                if (uOdds.hasOwnProperty(propplayer)) {
          var propHigh = getHigh(propplayer);
    if(propplayer==name){noOut=noOut+uOdds[propplayer].length
    //console.log(uOdds[propplayer])
                
            }
            
           

                }

            }

        }
    }
    }
    return noOut
    }

function getThreeple(data) {

    var cards = data;
    var flushOdds = groupBy(cards, v => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 3) {
                finalOdds = getHigh(flushOdds[prop]);

            }

        }
    }
    return finalOdds

}

function getDouble(data, sum) {
    var cards = data;
    var flushOdds = groupBy(cards, v => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length == 2) {
                if (sum) {
                    finalOdds += getHigh(flushOdds[prop]);
                } else {
                    finalOdds = getHigh(flushOdds[prop]);
                }

            }

        }
    }
    return finalOdds

}

function checkHaveFlushOdds(flop) {

    var flopOdds = groupBy(flop, v => v[1]);
    var isNuts = false;


    //console.log("flopOdds",flopOdds)
    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= 3) {
                isNuts = true;

            }

        }
    }



    return isNuts

}
function checkHaveStrOdds(flop) {
    var isNuts = false;
    var topNum = 0;

    var arrayLength = flop.length;

    var cardsHighFlop = SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1)
    }
    //console.log(cardsHighFlop)
    for (var i = 0; i < cardsHighFlop.length - 2; i++) {
        if (cardsHighFlop[i] - 4 <= cardsHighFlop[i + 2]) {


            isNuts = true;


        }

    }

    return isNuts

}

function checkShow(ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = 0;
    if (obj.state > 0) {
        iPoto = obj.state - 1
    }
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            //console.log(obj.pls[prop])
            if (obj.pls[prop].Bot == false) {
var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1]
                        for (var i = 2; i < 4; i++) {
                            if (obj.state >= i) {
                                allInPot = allInPot + obj.pls[prop].inPot[i]
                                    //Do something
                            }

                        }
                }
             
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1 && allInPot >= obj.inPot) {

                    showAll = false;
                }

            }
        }

    }
    //console.log(showAll)
    // return false
    return showAll
}
function checkAllBots(ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = 0;

    if (obj.state > 0) {
        iPoto = obj.state - 1

    }
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            //console.log(obj.pls[prop])
            if (obj.pls[prop].Bot == false) {
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1]
                        for (var i = 2; i < 4; i++) {
                            if (obj.state >= i) {
                                allInPot = allInPot + obj.pls[prop].inPot[i]
                                    //Do something
                            }

                        }
                }
                if (allInPot >= obj.inPot) {

                    showAll = false;
                }

            }
        }

    }
    //console.log(showAll)
    // return false
    return showAll
}
function checkInpot(ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = obj.state
    
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
			if (obj.pls[prop].Player == obj.Player && obj.pls[prop].inPot[iPoto]>0) {
                       showAll = false;
                    }
            //console.log(obj.pls[prop])
           
        }

    }
    //console.log(showAll)
    // return false
    return showAll
}
function checkStatus(ob) {
    var obj = ob
	//console.log(JSON.stringify(obj))
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
			if (obj.pls[prop].Bot == false) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") > -1 ) {
                console.log(obj.pls[prop])
                console.log(JSON.stringify(obj))
            }
			if (obj.pls[prop].Cards.length == 0 && obj.pls[prop].Player != obj.Player   && obj.pls[prop].Status == "playing" ) {
                console.log(obj.pls[prop])
                console.log(JSON.stringify(obj))
            }
			}
        }
	}

}
function checkPlayerNumber(obj) {
    var ob = 0
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player) {
                ob = ob + 1
            }
        }

    }
    return ob
}
module.exports = decide;
