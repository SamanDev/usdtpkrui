const mongoose = require("mongoose");
const Wheel = mongoose.model(
  "GalaxyBot",
  new mongoose.Schema({
    player: { type: String, default: "Pending" },
    number: { type: String, default: "" },
    state: { type: Number, default: 0 },
    data: { type: String, default: "" },
    date: { type: Date, default: Date.now },
  })
);
mongoose.Promise = global.Promise;

const db = {};

db.mongoose = mongoose;

db.GalaxyBot = Wheel;

module.exports = db;

