let dec = require("../configs/mydecide");


dec.getDecide(


{"Call":1,"Balance":{"Available":962127347,"Available2":0,"InPlay":0,"InPlay2":0,"Total":962127347,"Total2":0},"Pot":5,"inPot":1,"MinRaise":4,"MaxRaise":40000,"Button2":"Call","seat":10,"place":-1,"Player":"Aliasgharfgh","Chips":40000,"Cards":[28,41,0,0,0],"Helper":"High Card Queen","total":5,"state":0,"tablename":"061 Holdem #1k-2K","gametype":"holdem","handnumber":"#217180-1","flopCards":[],"convertedCards":["8s","Qc"],"amounts":{"Pot":5,"Call":1,"BB":2,"Rest":40000},"pls":{"4":{"Player":"alibache","Chips":40000,"Helper":"High Card King","Status":"playing","Cards":["6h","Kd"],"Bot":true,"Dealer":false,"inPot":[2,0,0,0]},"6":{"Player":"aliemami","Chips":40002,"Helper":"High Card Nine","Status":"playing","Cards":["9d","7h"],"Bot":true,"Dealer":true,"inPot":[2,0,0,0]},"10":{"Player":"Aliasgharfgh","Chips":40000,"Helper":"High CardQueen","Status":"playing","Cards":["8s","Qc"],"Bot":true,"Dealer":false,"inPot":[1,0,0,0]}},"allCards":["8s","Qc","9d","7h","6h","Kd"]},(res)=>{
	
	
console.log(res);
	
});