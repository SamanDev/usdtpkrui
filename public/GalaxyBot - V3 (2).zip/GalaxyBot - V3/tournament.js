let Tournament = function(data,callback) {
	var t = this;
	t.ID = data.name;
	t.StartTime = data.StartTime;
	t.runTime = data.runTime;
	t.tourStatus = data.status;
	t.status = "pending";	
}




Tournament.prototype.startTour = (callback)=>{
	let t = this;
	let list = [];
	
		//make tables 
		maven.mvapi({"Command":"TournamentsGet","Name":tourName},(tourData)=>{
			let n = tourData.Tables;
	
			let tbcount = tourData.MaxEntrants / tourData.Seats;
			for (let  i = 1; i <= tbcount; i++) 
			{
				let tourTBname = tourName + " - Table " + i;					
				var tbs = bcore.getTable(tourTBname);
				if (tbs == false) {
					bcore.Tables[tourTBname] = new mkTable({
							"ID": tourTBname,
							"Game": tourData.Game,
							"Seats": tourData.Seats,
							"Playing": 0,
							"Waiting": 0,
							"bots": {},
							"state": 0,
							"flop": [0, 0, 0, 0, 0],
							"total": 0,
							"SB":1,
							"BB": 2,
							"BuyinMin": 0,
							"BuyinMax": 0,
							"hands": {
							"rrrr": "eeee"
							},
							"handnumber": false,
							"showapi":bcore.showapi
						});
					} 
			}
			
		maven.mvapi({"Command":"TournamentsWaiting","Name":tourName},(res)=>{
			for(let pl of res.Wait)
				
			{
				let ex = pl.split("|");
				let plnameex = ex[0].split("=");
				list.push(plnameex[0]);
			}
			bcore.startTourLoop(tourName,list,0,()=>{
			callback();
				
				
			});
			
			
			
		});
		});
	
	
}





module.exports = Tournament;