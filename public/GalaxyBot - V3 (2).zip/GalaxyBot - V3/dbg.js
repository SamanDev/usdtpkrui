
var colors = require('colors');
	colors.enable()
/*
sethand
botlogin
botseat
system
decide*/
var DBG = function(log,params)
{
	t = this;
	//console.log(params,log);
	let store = DBG.store;
	var connectTime = DBG.getTimer();
	
	let systemloglist = ["system"];
	if(DBG.checkTime > 0 )
	{
		if(typeof DBG.systemLogs[DBG.checkTime] == "undefined")
		{
			
			DBG.systemLogs[DBG.checkTime] = {"logs":{},"bots":{}};
		}
		if(systemloglist.indexOf(params.type) > -1)
		{
			if(typeof DBG.systemLogs[DBG.checkTime].logs[params.type] == "undefined")
			{
				DBG.systemLogs[DBG.checkTime].logs[params.type] = [];
				
			}
			DBG.systemLogs[DBG.checkTime].logs[params.type].push({"log":log,"params":params,"time":connectTime});
		}
		
	}
	
	if(typeof params.player != "undefined")
	{
	params.player = params.player.toLowerCase();
		
		if(typeof store[params.player] == "undefined")
		{
			store[params.player] = [];
		}
		if(params.type == "botseat" || params.type == "botstatus")
		{
			
			if(typeof DBG.systemLogs[DBG.checkTime].bots[params.player] != "undefined")
			{
				DBG.systemLogs[DBG.checkTime].bots[params.player].logs.push({"log":log,"params":params,"time":connectTime});
			}
		}
		if(typeof store[params.player][params.type] == "undefined")
		{
			
			store[params.player][params.type] = [];
		}
		store[params.player][params.type].push({"log":log,"params":params,"time":connectTime});
	}
	
	var color = "gray";
	switch(params.type)
	{
		case "sethand":
		color = "blue";
		break;
		case "buttons":
		color = "green";
		break;
		case "buttons":
		color = "green";
		break;
		case "botseat":
		color = "cyan";
		
		break;
		case "system":
		color = "red";
		break;
		case "update":
		color = "white";
		break;
		case "decide":
		color = "yellow";
		break;
		default: 
		color = "gray";
		break;
		
		
	}
	if(typeof params.Color != "undefined" )
	{
		color = params.Color;
	}
	if(params.details == true)
	{
		if(config.debug.details == false)
		{
			return true;
		
		}
	}
	//console.log(config.debug[params.type],params.type,config.debug);
	//console.log("+++++",typeof config.debug[params.type], config.debug[params.type]  , inputConfig.dev);
	if(typeof config.debug[params.type] == "undefined" || config.debug[params.type] == false || !inputConfig.dev)
	{
		return true;
	}
	//console.log(params.type,config.debug[params.type]);
	//var rv = true;
	var em = params.Date;
	
	
	var t= this;
	var ir = 65;
	var rem = ir - log.length;
	
	if(rem % 2)
	{
		var le = (rem - 1) / 2 
		var ri = le +1;
		
	}else{
		
		le = rem / 2 ;
		ri = rem / 2 ;
	}
	le = le < 0 ? 0 : le;
	ri = ri < 0 ? 0 : ri;
	//console.log(le);
	var spa = " " ;
	
	cnstr = typeof em != "undefined" && em == true ? connectTime: spa.repeat(connectTime.length);
	
	var cls =["red","yellow","cyan","blue","gray","green","white"];
	
	//var cls =["red5","yellow5","cyan5","blue5","gray5","green5"];
	var ind = cls.indexOf(color);
	if(ind > -1 )
	{
		
		var clss =["red","yellow","cyan","blue","gray","green","white"];
		color  = clss[ind];
		let rv   = 1;
		if(typeof rv == "undefined")
		{
			
			console.log(colors[color](cnstr + spa.repeat(le) + log + spa.repeat(ri)));
			
			
		}else{
			
			var finalmsg = cnstr + spa.repeat(le) + log + spa.repeat(ri);
			if(config.getDbLoger)
			{
				/*var playername = typeof log.Player != "undefined" ? log.Player : false;
				 playername = playername != false && typeof log.player != "undefined" ? log.player : false;
				*/
				var sql = "INSERT INTO `errorlogs` ( `created`, `log`) VALUES( '" + cnstr + "', '" +  log + "');";
				/*cn.query(sql, function(error, results, fields) {
					
					
				});
				*/
			}
			
		
			
			if(config.debug.file != false)
				
			{
				
				fs.appendFile(config.debug.file, "\n" + finalmsg, function (err) {
						  if (err) throw err;
						 if(config.debug.console)
						 {
					console.info(colors[color].inverse(finalmsg));
						 }
						}); 
						
			}else{
				if(config.debug.console && inputConfig.dev)
				{
					console.info(colors[color].inverse(finalmsg));
				}
			}
			
		}
			

	}


}
DBG.addZero = function(i){
	 
	if (i < 10) {
		i = "0" + i
	}
	return i;

	
}
DBG.store = {};
DBG.systemLogs = {};
DBG.errorLogs = [];
DBG.checkTime =0;
DBG.table = function(log,keys)
{
	if(config.debug.file != false)
	{
			
		
		var out = [];
		
		
		if(typeof keys != "undefined")
		{
			for(e=0;e<log.length;e++)
			{
				var uo = {};
				for(ee=0;ee<keys.length;ee++)
				{
					uo[keys[ee]] = log[e][keys[ee]];
				}
				
				out.push(uo);
			
			}
			
		}else{
			var out = log;
		}
		//console.log(out);
		1
		
		fs.appendFile(config.debug.file, "\n" + JSON.stringify(out), function (err) {
					  if (err) throw err;
					  if(config.debug.console)
						 {
					 console.table(log,keys);
						 }
					}); 
	}else{
		if(config.debug.console && inputConfig.dev)
						 {
		 console.table(log,keys);
						 }
	}
			
	
	
}

DBG.getTimer = function()
{
	
		const d = new Date();
	let day = d.getDate();
	
	var connectTime =  DBG.addZero(d.getHours()) + ":" +  DBG.addZero(d.getMinutes()) + ":" +  DBG.addZero(d.getSeconds()) ; 
	return connectTime;
	
}


DBG.error = function(params)
{
	
	var connectTime = DBG.getTimer();
	params.time = connectTime;
	DBG.errorLogs.push(params);
	
}
module.exports = DBG;