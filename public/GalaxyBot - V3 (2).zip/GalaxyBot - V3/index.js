fs = require('fs');



mysql = require('mysql');


inputConfig = {};
for(let v of process.argv)
{
	
	if(v[0] == "-")
	{
		
		let configname = v.substring(1);
		
		if(configname.indexOf(":") > -1)
		{
			let ex = configname.split(":");
			let val = ex[1] == "true" ? true : ex[1] == "false" ? false  : ex[1];
			inputConfig[ex[0]] = val;
			
		}else{
			inputConfig[configname] = true;
		}
	}
	
}

if(!inputConfig.dev)
{
	
	
}

//console.log = function(){};
//console.info = function(){};
//var configname = typeof process.argv[2] != "undefined" ? process.argv[2] : "";
let configfile = !inputConfig.configName ?  "./config.js"  : "../configs/" + inputConfig.configName + "config.js"  ;
let botfile = !inputConfig.configName ?  "./bots.json"  : "../configs/" + inputConfig.configName + "bots.json"  ;
let decidefile = !inputConfig.decide ?  "./decide"  : "../configs/" + inputConfig.decide + "decide.js"  ;
console.log(configfile);
config = require(configfile);
botData = require(botfile);
 console.log(decidefile);

WebSocket = require('ws');
AnalClass = require("./analclass");
decoders = require("./decoder");
maven = require('./mavenapi');
mkTable = require('./mktable');
botClass = require('./bot');
tourClass = require('./tournament');

bcoreClass = require("./core6.js");
DBG = require("./dbg");

DBG.checkTime = Date.now();
		
adminclients = {};
bcore = new bcoreClass(config);
decideClass = require(decidefile);
console.info("OK");
if(inputConfig.reset)
{
	bcore.reset = true;
	bcore.Preload(function(){
		DBG("Loaded",{"type": "system","Date":true});
				
		bcore.startTransfer(()=>{
			
			
		});
		
		
				
	


	});
}else
{
	
maven.mvapi({"Command":"ConnectionsList","Fields":"IP,SessionID,PC,Status"},(res)=>{
		
	if(res != null && res.Result == "Ok")
		{
			if(res.IP.length)
			{
				for(let k in res.IP)
				{
					
					if(res.IP[k] == "127.0.0.1" && res.PC[k].substring(0,2) == "BT" && res.Status[k] =="Ok" )
					{
						console.log("The bots are running from another way");
							 process.exit(1);
							 return true;
					}
					
				}
				
			}
			
		}



		if(config.getDbLoger)
		{
				cn = mysql.createConnection({
							host: config.dbhost,
							user:config.dbuser,
							password: config.dbpassword,
							database: config.dbname
						});
						cn.connect(function(err) {
							if (err) throw err;
						});
		}
		bcore.Preload(function(){
		DBG("Loaded",{"type": "system","Date":true});
		setTimeout(()=>{
			
			
			bcore.checkTimerNew(function(){});
			
			
		},1000);
			//bcore.checkTimer(botData,function(){});
		if(config.monitor)
		{
			
				
			bcore.monitorOn("config");




		}








		});

		
});
}












process
  .on('unhandledRejection', (reason, p) => {
    console.info(reason, '-============ Unhandled Rejection at Promise', p);
  })
  .on('uncaughtException', (err,source) => {
	
	console.info(err, ' -----------Uncaught Exception thrown');
	DBG.error({error:"uncaughtException",location:"index:850",err:err.stack,source:source});
	
	
	
	//console.log(DBG.getTimer());
	 if(config.getCrash)
	 { 
		console.table(DBG.errorLogs,["time","error","location"]);
		
		 process.exit(1);
	 }
	
	/*
	const d = new Date();
	let day = d.getDate();
	let year = d.getFullYear();
	let month = d.getMonth();
	var dir = config.logsDir;
	var fname = dir + "ErrorLogs " + year + "-" + month + "-" + day + ".txt";
	insertedlog = JSON.stringify(err);
	if (!fs.existsSync(  fname )) {
  
			  var stream = fs.createWriteStream(fname);
			stream.once('open', function(fd) {
			  stream.write("Open file " + t.ID);
			  stream.write(insertedlog);
			  stream.end();
			
			});
		}else{
			fs.appendFile(fname, insertedlog, function (ervr) {
				  if (ervr) throw ervr;
				
				}); 

			
		}
		
		
		*/
  
  });
 


Number.prototype.formatMoney = function(c, d, t){
var n = this, 
    c = isNaN(c = Math.abs(c)) ? 2 : c, 
    d = d == undefined ? "." : d, 
    t = t == undefined ? "," : t, 
    s = n < 0 ? "-" : "", 
    i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", 
    j = (j = i.length) > 3 ? j % 3 : 0;
   return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
 };
