let cnt = function(n)
{
	let d = new Date(n);
	return  d.getDate() + " "  + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
	
	
}
let splitTime = function(n, time) {
	
	let bet = parseInt(time) / parseInt(n);
	let fl = parseInt(bet);
	let ie = parseInt(fl / 2);
	
	var out = [];
	for (i = 0; i < n; i++) {
		var precentage = Math.floor((Math.random() * ((fl + ie) - ie)) + ie);
		out.push(precentage);
	}
	
	return out;
}

let cn =function(n){
	
	
	let ex = n.split(" ");
	let dayex = ex[0].split("-");
	let timeex = ex[1].split(":");
	console.log(dayex,timeex);
	
	
	
}
let cf2 = function()	{
			let res = {before:40,bots:80,min:10,max:11,tourname:"tourname"};
		//	let tourObj = bcore.Tournaments[res.tourname];
			let tourObj ={StartTime:"2024-07-16 11:10"};
			let converted = cn(tourObj.StartTime);
			let limitSec = 30;
			//let tourObj ={StartTime:"0000-00-00 00:00"};
			let result = {"Result":"Error"};
			if(typeof tourObj != "undefined")
			{
				if(tourObj.StartTime == "0000-00-00 00:00")
				{
					//	bcore.currendAdmin = res.username;
								
					//	bcore.sendMonitor({"Command":"tourstarttime","Type":"Terminated"});
						
					result.Result = "Error";
					result.Error = "Start time not set";
						
						
				}else{
					let before = (parseInt(res.before) * 60);
					let st = Date.parse(tourObj.StartTime) ;
					console.log(tourObj,(new Date(st)).getHours(),(new Date(st)).getMinutes());
					
					
					let rt = (st - (before * 1000));
					let tourData = {"MinRebuy":res.min,"MaxRebuy":res.max,"Bots":res.bots,"Before":res.before,"runTime":rt};
					let d = new Date(rt);
					let now = Date.now() - 3600000;
					result.st = cnt(st); //+ (4.5 * 3600000));
					result.before = before;
					result.now = cnt(now);
					result.rt = cnt(rt);
					if(st > now)
					{
						if(rt > now)
						{
							/*
							let remained =parseInt((st - now ) / 1000);
							result.Error = "bozorg";
							
							result.remained = remained;
							let limitTime = (res.bots * limitSec);
							result.limitTime = limitTime;
							if(remained >= limitTime)
							{
								let times = splitTime(res.bots,remained);
								console.log(times);
								
							}else{
								result.Result = "Error";
								
								result.Error = "just remain " + remained ;
							}
							*/
							result.Result = "Ok";
								result.Messae = "OK";
								
						}else{
							
							result.Result = "Error";
							result.Error = "Expire run time";
						
							
						}
					}else{
						
							result.Result = "Error";
							result.Error = "Expire start time";
						
					}
					//console.log(tourData,d,now);
					//	botData.Tournaments[res.tourname] = tourData;
					////////bcore.Tournaments[res.tourname].runTime = rt;
				/*	bcore.jsonWrite((!inputConfig.configName ?  "./bots.json"  : "../configs/" + inputConfig.configName + "bots.json"),botData,()=>{
						////console.log("loaad hour ",res.hour);
								bcore.loadTours();
						});*/
				}
			}else{
				
				result.Result = "Error";
				result.Error = "Tour " + res.tourname+ " not found ";
				
			}
			console.log(result);
		}
			let res = {before:40,bots:80,min:10,max:11,tourname:"tourname"};
		
let cf = function(params)	{
			let tourObj ={StartTime:"2024-07-16 13:10"};
			let limitSec = 30;
			let result = {"Result":"Error"};
			if(typeof tourObj != "undefined")
			{
				if(tourObj.StartTime == "0000-00-00 00:00")
				{
					result.Result = "Error";
					result.Error = "Start time not set";
				}else{
					let before = (parseInt(params.before) * 60);
					let st = Date.parse(tourObj.StartTime) ;
					let rt = (st - (before * 1000));
					let now = Date.now() - 3600000;
					if(st > now)
					{
						if(rt > now)
						{
							result.Result = "Ok";
						}else{
							result.Result = "Error";
							result.Error = "Expire run time";
						}
					}else{
						result.Result = "Error";
						result.Error = "Expire start time";
					}
				}
			}else{
				
				result.Result = "Error";
				result.Error = "Tour " + res.tourname+ " not found ";
				
			}
			console.log(result);
		}
		
		
		
		
let g = function()
{

	let now = 220;
	let next = now + 40;
	let start = 300;
	let rt = 230;
	let msg = "notyet";
	let remained = 0;
	console.log("\n now : " + now,"\n next : " + next,"\n start : " + start,"\n rt : " + rt);
	if(start > now)
	{
		if(next > rt || next > start)
		{
			
			
			msg ="Ok";
			remained = start - now;
			
		}else{
			
			msg ="still time";
			remained = rt - next;
		}
		
		
		
	}else{
		
		msg ="expire";
		remained = now - start;
	}
	console.log(msg,remained);

}	

	g();
	