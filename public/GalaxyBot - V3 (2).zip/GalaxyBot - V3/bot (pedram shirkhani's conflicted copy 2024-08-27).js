let tbl = function(data){
	
	var tj = {};
	if(typeof data.Replace != "undefined")
	{
		tj.actTime =  data.actTime;
		tj.chips =  data.chips;
		tj.sitingOut =  data.sitingOut;
		tj.sitingForce =  data.sitingForce;
		tj.timestart =  data.timestart;
		tj.Status =  data.Status;
		tj.StatusTime =  data.StatusTime;
		tj.Seat =  data.Seat;
		tj.played =  data.played;
		tj.profile  = data.Profile;
		tj.inPot = data.inPot;
		tj.addInPot = data.addInPot;
		tj.state = data.state;
	}else{
		if(typeof data.GameID == "undefined")
		{
			DBG.error({error:"undefined tbname",location:"bot:9",data:data});
		}
		tj.Status =  false;
		tj.StatusTime =  false;
		tj.Seat =  data.Seat;
		tj.played =  0;
		tj.chips =  data.BuyIn;
		tj.timestart =  Date.now();
		tj.sitingOut =  false;
		tj.sitingForce =  false;
		tj.inPot = [0,0,0,0];
		tj.addInPot = true;
		tj.state = -1;
		tj.acting =  false;
		tj.leaveTimer = false;
		tj.alone = false;
		tj.waitToSitout  = 0;
		tj.profile  = data.Profile;
		//tj.profile.runItTwice = Math.floor((Math.random() * (100 - 1)) + 1) <= tj.profile.runItTwice;
		//tj.ws = data.ws;
		tj.showCard = false;
		tj.PNum = data.PNum;
		//tj.sendMSG = data.sendMSG;
		
	}
	tj.actionTimeout = false;
	tj.actions = {
						"default":
									{
										
										"openTable":6,
										"emptySeat":7,
										"reserveSeat":0,
										//"checkSited":10
									},
						"changeSeat":
									{
										
										"openTable":0,
										"emptySeat":0,
										"reserveSeat":0,
										//"checkSited":10
									},
						"sitout":
									{
										"sitOutButton":0,
										"sitOut":3,
										//"getOut":30,
										//"deleteTable":1
									},
						"sitout1": // First sitout button then close table
									{
										"sitOutButton":0,
										"sitOut":10,
										//"getOut":30,
										//"deleteTable":1
									},
						"sitout2": // First sitout button then close browswr ( Left table)
									{
										"sitOutButton":0,
										//"sitOut":3,
										//"getOut":30,
										//"deleteTable":1
									},
						"sitout3": // Just leave table 
									{
										//"sitOutButton":0,
										"sitOut":10,
										//"getOut":30,
		
										//"deleteTable":1
									},
						"sitout4": // Close browser and 
									{
										//"sitOutButton":0,
										//"sitOut":3,
										//"getOut":30,
										//"deleteTable":1
									}
					};
	tj.actionType = "default";
	tj.actionNum = 0;
	tj.actTime =  Date.now();
	tj.actionCallback =  false ;
	tj.GameID = data.GameID;
	tj.Player = data.Player;
	//tj.PlayerID = data.PlayerID;
	tj.Hands =  data.Hands;
	tj.Times =  data.Times;
	tj.Rebuys =  data.Rebuys;
	tj.Rebought =  0;
	tj.rebuyAmount =  "Last";
	tj.nextAct = data.nextAct;
	tj._changeSeat =  false;
	tj.x2 = (callack)=>{
		callback()
	};
	tj.changeSeat = (callack)=>{
		callback()
	};
	tj.setRebuyAmount = (amount)=>{
			let ti= this;
			ti.rebuyAmount = amount;
	}
	tj.sitOutButton = function(callback) {
		let ti= this;
		
		if(typeof bcore.Clients[ti.Player.toLowerCase()] != "undefined")
		{
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({"Response":"SitOut","Table":ti.GameID,"Type":"R","Box":"SitHand","Checked":"Yes"});
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({"Response":"SitOut","Table":ti.GameID,"Type":"R","Box":"SitBlind","Checked":"Yes"});
		callback();
		
		}else{
			
		callback();
			
		}
								
	}
	tj.reserveSeat = function(callback) {
		
		var ti = this;
		
		if(typeof bcore.Clients[ti.Player.toLowerCase()] != "undefined" && typeof bcore.Clients[ti.Player.toLowerCase()].sendMSG == "function")
		{
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({
											"Response": "RequestSeat",
											"Table": ti.GameID,
											"Type": "R",
											"Seat": ti.Seat
										},function()
										{
											
											
											callback();
											
										});
		}else{
			DBG.error({error:"reserveSeat",location:"bot:89",player:ti.Player,table:ti.GameID});
		
		}
	}
	tj.sitOutAct = function(reason,callback){
		let ti= this;
		
		if(ti.sitingOut == false || ti.sitingForce == true )
		{
			ti.sitingOut = true;
			let precentage = Math.floor((Math.random() * (100 - 1)) + 1);
			//("sitOutAct",tj.Player,reason);
			let sitoutType = 0;
			switch(reason)
			{
				case "getAlone":
				sitoutType = 3;
				break;
				
				case "Limit Hands":
				if(precentage < 60)
				{
					sitoutType = 1;
				}else{
					if(precentage < 80)
					{
						sitoutType = 3;
					}else{
						if(precentage < 95)
						{
							sitoutType = 2;
						}else{
							
							sitoutType = 4;
						}
						
					}
					
				}
				
				break;
				

				case "AddchipButton-noRebuy":
				case "ReadyButton-noRebuy":
				if(precentage < 20)
				{
					sitoutType = 4;
				}else{
					sitoutType = 3;
				}
				
				
				break;

				case "ReadyButton-sitingOut":

					sitoutType = 3;

				break;
				case "ButtonAction-sitingOut":
					sitoutType = 1;
				
				break;
				
				case "CommanderChat-sitingOut":
				if(precentage < 20)
				{
					sitoutType = 3;
				}else{
					sitoutType = 1;
					
					
				}
				
				
				
				
				break;
				
			}
			
			if(sitoutType == 1 || sitoutType == 2)
			{
				tj.sitOutButton(()=>{});
			}else{
				if(sitoutType ==3 )
				{
					ti.sitOut(()=>{
						
						/*bcore.Clients[tj.Player.toLowerCase()].getOut(()=>{
								
								
							})*/
						
					});
				}else{
					if(sitoutType == 4)
					{
						if(Object.keys(bcore.Clients[tj.Player.toLowerCase()].Tables).length == 1)
						{
							bcore.Clients[tj.Player.toLowerCase()].ws.close();
				
						}else{
							if(Object.keys(bcore.Clients[tj.Player.toLowerCase()].Tables).length > 1)
							{
								var waitToSitout = Math.floor((Math.random() * (botData.Settings.waitToSitout[1] - botData.Settings.waitToSitout[0])) + botData.Settings.waitToSitout[0]);
								setTimeout(()=>{
									
									
								ti.sitOut(()=>{
							
										bcore.Clients[tj.Player.toLowerCase()].getOut(()=>{});
										
									});
								},(waitToSitout * 1000));
								
								}
						}
					
					}
					
				}
				
			}
			/*
			actionNum = typeof actionNum  != "undefined" ? actionNum : 0;
			
			ti.actionType = "sitout" + sitoutType;
			ti.actionNum = actionNum;
			ti.nexActTBL();
			*/
		
		}
		
		
	}
	tj.sitOut = function(callback){
		let ti = this;
		ti.setStatus("waittositout");
	
		
		
		DBG("Get sitout immidiate | P : " + ti.Player  ,{"Color":"green","type":"botseat","player":ti.Player,"Date":true,"details":false});
		DBG(" P : " + ti.Player + " | T : " + ti.GameID  ,{"Color":"green","type":"botseat","player":ti.Player,"Date":false,"details":false});
		if(typeof bcore.Clients[ti.Player.toLowerCase()] != "undefined" && typeof bcore.Clients[ti.Player.toLowerCase()].sendMSG == "function")
		{
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({
			"Response": "LeaveSeat",
			"Table": ti.GameID,
			"Type": "R"
		},function(){
			ti.setStatus("sitout");
				
			bcore.Clients[ti.Player.toLowerCase()].sendMSG({
				"Response": "CloseTable",
				"Table": ti.GameID,
				"Type": "R"
			},function(){
				ti.setStatus("waittologout2");
				if(config.debug.botseat)
				{
				//	DBG.table(t.Tables,["Hands","Times","Rebuys","Seat","played"]);
				}
				if(typeof callback == "function")
				{
					 callback();
				
				}
			});
		});
		
		}
		
		
	}
	tj.nexActTBL = function(data){
		let ti = this;
		let preStatus = {"reserveSeat":"requestseat","emptySeat":"waittofindseat","sitOutButton":"sitOutButton","waittositout":"waittositout"};
		let actions = ti.actions[ti.actionType];
		if(typeof actions == "undefined")
		{
			
			//(ti);
		}
		let kes = Object.keys(actions);
		let act = kes[ti.actionNum];
		let timing = actions[kes[ti.actionNum]];
		////("nexActTBL",data,);
		DBG("next TBL Act ACT:"  + act  + " | time : | " + timing  ,{"type":"botseat","player":ti.Player,"Color":"white","details":false,"Date":true}); 
		if(typeof preStatus[act] != "undefined")
		{
			ti.setStatus(preStatus[act]);
		}
		
		ti.actTime =  Date.now();
		ti.actionNum++;
		if(ti.acting)
		{
			ti.acting = false;
			ti.actionTimeout = setTimeout(()=>{
			ti.acting = true;
			switch(act)
			{
				case "openTable":
				
				ti.open(()=>{
					ctt5();
					//ti.actionTimer = 4;
					ti.nexActTBL();
					});
				break;
				
				case "sitOut":
				ti.sitOut(()=>{
				if(typeof ti.actionCallback == "function")
				{
					ti.actionCallback();
					//ti.nexActTBL();
				}
				//("Sitout done");
				//	ti.nextAct(data);
				});
				break;
				
				case "checkSited":
				ti.checkSited(()=>{
					
				});
				break;
				
				case "sitOutButton":
				
				ti.sitOutButton(()=>{
					////("ok sitOutButton");
				});
				break;
				
				case "deleteTable":
				ti.deleteTable(()=>{});
				break;
				
				case "getOut":
				//(ti);
				if(typeof ti.getOut == "function")
				{
				ti.getOut(()=>{});
				}else{
					////(ti);
					DBG.error({error:"getOut",location:"bot:200",player:ti.Player,table:ti.GameID});
					
				}
				break;
				
				case "emptySeat":
				let tbs = bcore.getTable(ti.GameID);
				
				
				ti.setStatus("waittofindseat");
				if(typeof tbs == "undefined")
				{
					
					//(ti);
				}
				tbs.getEmptySeat(ti.Player,(Seat)=>
				{
					ti.Seat = Seat;
					if(Seat > 0)
					{
				
					ti.setStatus("waittosit");
			
					//ti.Reserved[tbs.ID] = Seat;
					ti.nexActTBL({"Seat":Seat});
				
					}else{
						//("no find seat",{Seat:Seat,PL:ti.Player,TB:ti.GameID});
						
						bcore.Clients[ti.Player.toLowerCase()].deleteTable(ti.GameID,()=>{});
						
					}
					
						
				},bcore.Clients[ti.Player.toLowerCase()]._changeSeat);
				break;

				
				
				case "reserveSeat":
				ti.reserveSeat(()=>
				{
				ti.setStatus("reserved");
				ti.nextAct({"Table":ti.ID});
					
						
				});
				break;
				
				case "logout":
				ti.LogoutRequest(()=>{});
				break;
				
				case "completeLogout":
				ti.completeLogout(()=>{});
				break;
				
				case "login":
			
				ti.Login(()=>{
					
					ti.nextAct(data);
					
				});
				
				break;
				
			}
			
			
			},(timing * 1000));
		}
	}
		/*

	tj.sendMSG = function(data,callback) {
		////////(data,callback) 
		ti = this;
		ti.PNum.INC();
		data.Pnum = ti.PNum.NUM;
		data.ID = ti.PlayerID;
		if (config.debug.response) {
			data.Player = ti.Player;
			DBG(JSON.stringify(data), {
				"type": "response",
				"Date": true,
				"player":ti.Player,
			});
		}
		//(data);
		ti.ws.send(JSON.stringify(data));
		if(typeof callback != "undefined")
		{
			callback();
		}
	}

	*/
	tj.open = function(callback) {
		var ti = this;
		ti.setStatus("opentable");
		DBG("OPEN TABLE i--------- P : " + ti.Player + " | T : " + ti.GameID ,{"type":"botseat","player":ti.Player,"Date":true,"Color":"yellow"});
		if(typeof DBG.systemLogs[DBG.checkTime].bots[ti.Player.toLowerCase()] != "undefined")
		{
		}
			
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({
			"Response": "OpenTable",
			"Table": ti.GameID,
			"Type": "R",
			"Seat": 0
		},callback);
	//	ti._opentable.push(ID.Table);
		
	}
	tj.checkSited = function() {
		
		let ti= this;
		ti.actionType = "sitout";
		ti.actionNum = 1;
		ti.nextAct({"Table":ti.GameID});
	}
	tj.setStatus = function(status,callback){
		var ti = this;
		DBG("SET STATUS  P : " + ti.Player + " | S : " + status ,{"type":"botstatus","player":ti.Player,"table":ti.GameID,"Date":true,"Color":"blue"});

		let color = "yellow";
		let fontcolor = "black";
		switch(status)
		{
			case "sitoutdone":
			case "logout":
			color = "green";
			fontcolor = "white";
			break;
			
			
		}
	
		ti.Status =  status;
		ti.StatusTime = DBG.getTimer();
		let act = ( ti.actionNum >= Object.keys(ti.actions[ti.actionType]).length ? "Done" : Object.keys(ti.actions[ti.actionType])[ti.actionNum]);
		let rem = (  ( ti.actionNum >= Object.keys(ti.actions[ti.actionType]).length ? 0 : ti.actions[ti.actionType][Object.keys(ti.actions[ti.actionType])[ti.actionNum]]) - parseInt((Date.now() - ti.actTime)  / 1000) );
		if(typeof act == "undefined")
		{
			////(ti);
			////(ti.actions[ti.actionType],Object.keys(ti.actions[ti.actionType]),(ti.actionNum - 1));
		
			
		}
		//t.Status = ID.status;
		bcore.sendMonitor({"Command":"setStatus","Type":"tableStatus","Player":ti.Player.toLowerCase(),"Table":ti.GameID ,"Status":status,"tr":'<tr data-player="' + ti.Player.toLowerCase() + '"  data-table="' + ti.GameID + '" ><td>'+ ti.Player +'</td><td><span title="' + ti.StatusTime + '">'+ ti.Status  +'</span></td><td>'+ ti.GameID + '</td><td>' + ( ti.Seat > 0 ?  ti.Seat : "?" ) + '</td><!--<td  class="acting">'+ act  + (act != "Done" && rem > 0 ? ' ( ' + rem + ' ) ' : '') +'</td>--><td>' + (ti.played > ti.Hands ? 'Over': ( ti.played  +' / ' +  ti.Hands ) )+ '</td><td><a class="btn playerlogs">Logs</a></td><td><a class="btn sitoutBot">Sitout</a></td></tr>'}
		
		);
	}
	tj.RSVP = function(dt,callback){
		//		aatA();	
	//	let Seat = ti.Reserved[dt.Table];
	let ti= this;
		
		//profile.runItTwice = Math.floor((Math.random() * (100 - 1)) + 1) <= profile.runItTwice ;
			
		let tbs = bcore.getTable(ti.GameID);
		
		bcore.Clients[ti.Player.toLowerCase()].sendMSG({
				"Response": "RSVP",
				"Table": ti.GameID,
				"Type": "R",
				"BuyIn": dt.MinBuyIn,
				"AutoRebuy": "No"
			},function(){
																
				ti.setStatus("rsvp");	
																
																
				tbs.seatBot({"Player":ti.Player,"Chips":dt.MinBuyIn,"Seat":ti.Seat},function(seated)
				{
													
					ti.setStatus("sited");

													
													callback();
																													
																
												});
											});


		
		
	}
	return tj;
}
var bot = function(data,callback) {
	var t = this;
	
	t.Player = data.Player;
	t.Balance = {"Available":0,"Available2":0,"InPlay":0,"InPlay2":0,"Total":0,"Total2":0};
	
	t.ws = false;
	t.Status = false;
	t.StatusTime = "";
	t.loginStatus = false;
	t.ID = "";
	t.SessionKey = "";
	t.PNum = function(){};
	t.PNum.NUM = 0;
	t.PNum.INC = ()=>{t.PNum.NUM++};
	t.LoginProcess = false;
	t.shouldOpen = {};
	t.shouldOpen.list = [];
	t.shouldOpen.push = (val)=>{t.shouldOpen.list.push(val)}
	
	//t.shoulOpen.prototype.checkExists = function(){daarat();}
	t.Tables = {};
	t.Reserved = {};
	t.Salt = {};
	t.Hands = 0;
	t.Times = 0;
	t.Rebuys = 0;
	t.played = 0;
	t.timestart = 0;
	t.noLogout = false;
	t.tourRegisterCheck = false;
	t.tournaments = {};
	t._opentable = [];
	t._changeSeat = -1;
	t.actionTimer = typeof data.actionTimer != "undefined" ? data.actionTimer : 3;
	t.actionTimeout = false;
	t.actingBot =  true;
	t.actions = {
					"tour":
								{
									
									"login":t.actionTimer,
									"checkRegister":3
									
								},
					"recreate":
								{
									
									"login":t.actionTimer,
									
								},
					"default":
								{
									"login":t.actionTimer,
									"openTable":3,
									"emptySeat":0,
									"reserveSeat":0,
									"checkSited":0
								},
					"sitout":
								{
									"sitOutButton":0,
									"sitOut":3,
									"getOut":30,
									"deleteTable":1
								},
					"logout":
								{
									"logout":3
								}
				};
	t.actionType = "default";
	t.actionNum = 0;
	t.actionCallback = typeof data.actionCallback != "undefined" ? data.actionCallback : ()=>{ };
	t.actTime =  Date.now();
	/*if(typeof data.actionTimer != "undefined"  && data.actionTimer > 0 )
	{
		t.actionTimeout = setTimeout(()=>{
			
			
			t.actionCallback(t);
			
		},(data.actionTimer * 1000));
		
	}*/
	
	t.setStatus({"status":"Created"});
	callback(t,data);
}

bot.fileVersion= 1;

bot.prototype.settings = {
	"maxHands": 10,
	"minHands": 3,
	"maxTimes": 10,
	"minTimes": 4,
	"minRebuys": 1
};
bot.prototype.getStatus = function(ID) {
	var t = this;
	return t.Status;
}
bot.prototype.setStatus = function(ID) {
	var t = this;
	
	DBG("SET STATUS  P : " + t.Player + " | S : " + ID.status ,{"type":"botstatus","player":t.Player,"table":ID.table,"Date":true,"Color":"blue"});
	if(typeof DBG.systemLogs[DBG.checkTime].bots[t.Player.toLowerCase()] != "undefined")
	{
		
		DBG.systemLogs[DBG.checkTime].bots[t.Player.toLowerCase()].status = ID.status;
	}
	let color = "yellow";
	let fontcolor = "black";
	switch(ID.status)
	{
		case "sitoutdone":
		case "logout":
		color = "green";
		fontcolor = "white";
		break;
		
		
	}
	if(typeof ID.table != "undefined" && typeof t.Tables[ID.table] != "undefined"  )
	{
		
		t.Tables[ID.table].setStatus(ID.status);
	}else{
		
		t.Status = ID.status;
		
	}
	
	let act = ( t.actionNum >= Object.keys(t.actions[t.actionType]).length ? "Done" : Object.keys(t.actions[t.actionType])[(t.actionNum )]);
			
	let rem  = (  ( t.actionNum >= Object.keys(t.actions[t.actionType]).length ? 0 : t.actions[t.actionType][Object.keys(t.actions[t.actionType])[(t.actionNum )]]) - parseInt((Date.now() - t.actTime)  / 1000) );
							
							
	let trr = '<tr data-player="'+ t.Player.toLowerCase() + '" ><td>'+t.Player + '</td><td '  + ( t.Status == "Terminating" ? ' style="color:red;font-weight:bold;" ' : '' ) + ' >'+t.Status + '</td><!--<td class="acting">' + act + (rem > 0 ? ' ( <span class="counter" >' + rem + '</span> ) ' : '' ) + '</td>--><td><a class="btn playerlogs">Logs</a></td><td>'  + ( t.Status != "Terminating" ? "<a class='btn terminateBot'>Logout</a>" : "&nbsp;") + '</td></tr>';
	bcore.sendMonitor({"Command":"setStatus","Type":"clientStatus","Player":t.Player.toLowerCase(),"Status":t.Status,"Time":t.StatusTime,"Color":color,"FontColor":fontcolor,"tr":trr});
	
	
}
bot.prototype.LogoutRequest = function(callback) {
	var t = this;
	t.loginStatus = "logoutrequest";
	DBG("Send Logout Request :" + t.Player, {
		"type":"botseat","player":t.Player,
		"Date": true
	});
	t.sendMSG({
		"Response": "LogoutRequest"
	},function(){
			t.setStatus({"status":"logout"});
			//callback();
		
	});
}
bot.prototype.hashPC = function() {
	
	let alph = [0,1,2,3,4,5,6,7,8,9,"A","B","C","D","E","F"];
	let ret = "";
	for(i=0;i<6;i++)
	{
       ret += alph[Math.floor((Math.random() * (alph.length - 0)) + 0)];	
		
		
	}
	return ret;
}
bot.prototype.Login = function(callback) {
	
	var t = this;

	t.loginStatus = "start";
	var cl = new WebSocket('ws://' + config.mavensUrl + ':' + config.packetPort + '/', {
		origin: 'http://' + config.mavensUrl + ':' + config.packetPort + ''
	});
	cl.on('open', function open() {
		t.ws = cl;
		t.loginStatus = "sending";
		t.sendMSG({
			"Response": "Session",
			"PC": "BT" + t.hashPC(),
			"Version": config.Version,
			"SitePassword": "",
			"Language": "En"
		});
	});
	cl.on('close', function incoming(data) {
		DBG(" ---------------- ", {
			"type": "botlogin",
			"Date": true,
			"player":t.Player,
			"Color": "green"
		});
		DBG("Close Socket : " + t.Player, {
			"type": "botlogin",
			"player":t.Player,
			"Date": false,
			"Color": "green"
		});
		if(t.Status == "transfering")
		{
			DBG.table(bcore.transferList);
			DBG("Make Transfer : " + t.Player  + " |  Index" + bcore.transferList.indexOf(t.Player.toLowerCase()) + "List " + JSON.stringify(bcore.transferList), {
			"type": "botlogin",
			"player":t.Player,
			"Date": false,
			
			
			"Color": "red"
			});
			t.setStatus({"status":"logout"});
			bcore.transferList.splice(bcore.transferList.indexOf(t.Player.toLowerCase()),1);
			DBG.table(bcore.transferList);
			setTimeout(()=>{
				
				bcore.makeTransfer(()=>{});
				
			},2000);
			
		}
		//(" close -======= ",t.Player,t.Status);
		delete bcore.Clients[t.Player.toLowerCase()];
	DBG("type close : " + t.Player + " | " +  typeof bcore.Clients[t.Player.toLowerCase()], {
			"type": "botlogin",
			"player":t.Player,
			"Date": false,
			"Color": "green"
		});
	});
	cl.on('message', function incoming(data) {
		dt = JSON.parse(data);
		if(config.debug.commands 
		&& dt.Command != "Table"
		&& dt.Command != "RingGameLobby"
		&& dt.Command != "Language"
		&& dt.Command != "Logins"
		&& dt.Command != "Session"
		&& dt.Command != "TournamentLobby"
		)
		{
			
			DBG(data + ",Player:"+t.Player, {
			"type": "commands",
			"Date": false,
			"player":t.Player,
			"Color": "green"
		});
	
			
		}
		
		var funcname = "Commander" + dt.Command;
					
		if (typeof t[funcname] == "function") {
			t[funcname](dt, function(msg) {
				if (dt.Command == "Session") {
					t.ID = dt.ID;
					if(msg.Result == "Error")
					{
				//	////("msg",dt.Command,msg);
						callback(msg);
						return;
						
					}
					t.ID = dt.ID;
				}
				if (typeof msg != "undefined") {
					t.sendMSG(msg);
				}
				if (dt.Command == "Login") {
					
					t.setStatus({"status":"Login"});
					callback({"Result":"Ok"});
				}
			});
			try {} catch (g) {}
		} else {}
	});
}
bot.prototype.Logout = function(callback) {
	var t = this;
	//var waitTgoLogout = Math.floor((Math.random() * (botData.Settings.waitThhoLogout[1] - botData.Settings.waitToLoguout[0])) + botData.Settings.waitTuoLogout[0]);
	
	DBG("Wait to logout",{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
	DBG("P : " + t.Player + " | Time : " + waitToLuogout  ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":false,"details":false});
	
	let st = setTimeout(()=>{

	DBG("Get logout after " + wauitToLogout + " Seconds "  ,{"Color":"green","type":"botseat","player":t.Player,"Date":true,"details":false});
	DBG(" P : " + t.Player  ,{"Color":"green","type":"botseat","player":t.Player,"Date":false,"details":false});
	
	
	DBG("Send Logout Done :" + t.Player, {
		"type":"botseat","player":t.Player,
		"Date": true
	});
	t.loginStatus = "logoutdone";
	var pl = t.Player.toLowerCase();
	if (typeof bcore.WaitingLogout[pl] != "undefined") {
		delete bcore.WaitingLogout[pl];
	}
	if (typeof bcore.WaitingLogout[pl] != "undefined") {
		DBG("\n\n\n\n ERROR LOGOUT " + t.Player, {
			"type":"botseat","player":t.Player,
			"Date": true,
			"player":t.Player,
			"Color": true
		});
		DBG.table(bcore.WaitingLogout);
		DBG.error({error:"Logout",location:"bot:677",player:t.Player});
				
	}
	t.sendMSG({
		"Response":  "Logout"
	});
	callback();
	
	},(waitToLhogout * 1000));
}
bot.prototype.completeLogout = function( callback) {
	var t = this;	
	DBG("completeLogout" ,{"type":"botseat","player":t.Player,"Color":"white","details":false,"Date":true}); 
		
	t.sendMSG({
		"Response":  "Logout"
	});
	
	//callback();
	
}
bot.prototype.sitOut_OLD = function(table, callback) {
	var t = this;	

	t.setStatus({"status":"waittositout","table":table});
	
	//var sitoutPercent = Math.floor((Math.random() * (100 - 1)) + 1);
	
	//var waitToSitout = Math.floor((Math.random() * (botData.Settings.waitToSitout[1] - botData.Settings.waitToSitout[0])) + botData.Settings.waitToSitout[0]);
	
//	waitToSitout = t.Tables[table].waitToSitout  > 0 ? t.Tables[table].waitToSitout : waitToSitout;
	
	
	//waitToSitout = sitoutPercent <= botData.Settings.sitoutPercent ? waitToSitout : 0 ; 
			//DBG("Wait to sitout",{"Color":"cyan","type":"botseat","player":t.Player,"Date":true,"details":false});

		//	DBG("P : " + t.Player + " | T : " + table   + " | Time : " + waitToSitout  ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":false,"details":false});
	//let st = setTimeout(()=>{
			
	DBG("Get sitout immidiate | P : " + t.Player  ,{"Color":"green","type":"botseat","player":t.Player,"Date":true,"details":false});
	DBG(" P : " + t.Player + " | T : " + table  ,{"Color":"green","type":"botseat","player":t.Player,"Date":false,"details":false});
		t.sendMSG({
			"Response": "LeaveSeat",
			"Table": table,
			"Type": "R"
		},function(){
			t.setStatus({"status":"sitout","table":table});
				
			t.sendMSG({
				"Response": "CloseTable",
				"Table": table,
				"Type": "R"
			},function(){
				t.setStatus({"status":"waittologout2","table":table});
				if(config.debug.botseat)
				{
					DBG.table(t.Tables,["Hands","Times","Rebuys","Seat","played"]);
				}
				if(typeof callback == "function")
				{
					 callback();
				
				}
			});
		});
	//},(waitToSitout * 1000));
}
bot.prototype.checkRegister = function(tourName, callback) {
		let t= this;
	t.sendMSG({
			"Response": "GameSelected",
			"Table": tourName,
			"Type": "T",
			"SnG":"No"
	});
}
bot.prototype.sitOut = function(table, callback) {
	let t= this;
	if(typeof t.Tables[table] != "undefined")
	{
		t.Tables[table].sitOut(callback);
		
		
	}
}
bot.prototype.sitOut2 = function(table, callback) {
	var t = this;				
	
	t.setStatus({"status":"waittositout","table":table});
	
	var sitoutPercent = Math.floor((Math.random() * (100 - 1)) + 1);
	
	var waitToSitout = Math.floor((Math.random() * (botData.Settings.waitToSitout[1] - botData.Settings.waitToSitout[0])) + botData.Settings.waitToSitout[0]);
	
	waitToSitout = t.Tables[table].waitToSitout  > 0 ? t.Tables[table].waitToSitout : waitToSitout;
	
	
	waitToSitout = sitoutPercent <= botData.Settings.sitoutPercent ? waitToSitout : 0 ; 
			DBG("Wait to sitout",{"Color":"cyan","type":"botseat","player":t.Player,"Date":true,"details":false});

			DBG("P : " + t.Player + " | T : " + table   + " | Time : " + waitToSitout  ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":false,"details":false});
	let st = setTimeout(()=>{
			
	DBG("Get sitout after " + waitToSitout + " Seconds "  ,{"Color":"green","type":"botseat","player":t.Player,"Date":true,"details":false});
	DBG(" P : " + t.Player + " | T : " + table  ,{"Color":"green","type":"botseat","player":t.Player,"Date":false,"details":false});
		t.sendMSG({
			"Response": "LeaveSeat",
			"Table": table,
			"Type": "R"
		},function(){
			t.setStatus({"status":"sitout","table":table});
				
			t.sendMSG({
				"Response": "CloseTable",
				"Table": table,
				"Type": "R"
			},function(){
				t.setStatus({"status":"waituutologout2","table":table});
				if(config.debug.botseat)
				{
					DBG.table(t.Tables,["Hands","Times","Rebuys","Seat","played"]);
				}
				if(typeof callback == "function")
				{
					 callback();
				
				}
			});
		});
	},(waitToSitout * 1000));
}
bot.prototype.sitOutOld = function(table, callback) {
	var t = this;
						
	t.sendMSG({
		"Response": "LeaveSeat",
		"Table": table,
		"Type": "R"
	},function(){
		//////("leaveseat",table);
		t.setStatus({"status":"sitout","table":table});
			
		t.sendMSG({
			"Response": "CloseTable",
			"Table": table,
			"Type": "R"
		},function(){
		//////("CloseTable",table);
			t.setStatus({"status":"waittolougout2","table":table});
			
			if(config.debug.botseat)
			{
				DBG.table(t.Tables,["Hands","Times","Rebuys","Seat","played"]);
			}
			
		});
	});
}


bot.prototype.changeSeat = function(tbName ,callback) {
	let t = this;
	t._changeSeat = "changing";
	t.Tables[tbName].sitOut(()=>{});
}
bot.prototype.sitOnTable = function(ID ,callback) {


}

bot.prototype.recreateTable = function(bottables,i,callback) {
	let t = this;
	

	if(i<bottables.length)
	{
		let data = bottables[i];
		if(typeof t.Tables[data.GameID] == "undefined")
		{
			
			bcore.Tables[data.GameID].reCreate(data.obj,()=>{
				
					
					
				data.Replace = true;
				data.nextAct = t.nextAct;
				t.Tables[data.GameID] = new tbl(data);
				i++;
				t.recreateTable(bottables,i,callback);
				
			});
			
		}
		
	}else{
		callback();
		
	}
	

	
}
bot.prototype.OpenTable = function(tbName ,callback,tbType) {
	var t = this;
	tbType = typeof tbType != "undefined" ? tbType : "default";
if(typeof tbName == "undefined")
			{
				//("OpenTable 819",t.Player,t.shouldOpen,Object.keys(t.Tables));
			}
DBG("OpenTable: T : | " + tbName + " | " +  t.Player + " | " + t.Status ,{"type":"botseat","player":t.Player,"Color":"red","details":false,"Date":true}); 
	
	
	let Handprecentage = Math.floor((Math.random() * (botData.Settings.maxHands - botData.Settings.minHands)) + botData.Settings.minHands);
	let Timeprecentage = Math.floor((Math.random() * (botData.Settings.maxTimes - botData.Settings.minTimes)) + botData.Settings.minTimes);
	let runItTwiceprecentage = Math.floor((Math.random() * (100 - 1)) + 1);
	let Rebuys = botData.Settings.minRebuys;
	
			
	let profile = {
		"runItTwice":runItTwiceprecentage < 100 ? true : false, 
		"preRebuy":botData.Settings.preRebuy,
		"aloneEnd":1,
		"aloneStart":300,
		"callSpeed":3,
		"raiseSpeed":3,
		"checkSpeed":3,
		"showHand":30
	};
	//console.log("here =======PROGILE=====",profile);
	if(typeof tbName == "undefined")
	{
		////(t);
		//console.trace();
	}
	if(typeof t.Tables[tbName] == "undefined")
	{
		t.Tables[tbName] = new tbl({
													"Hands": Handprecentage,
													"Times": Timeprecentage,
													"Rebuys":Rebuys ,
													"Profile":profile ,
													"GameID":tbName,
													"Player":t.Player,
													"PNum" : t.PNum,
													"nextAct":t.nextAct,
													//"PlayerID":t.ID,
													//"sendMSG":t.sendMSG
													//"BuyIn": dt.MinBuyIn,
													//"Seat": Seat,
													//"ws":t.ws,
													
												});
		t.Tables[tbName].setStatus("waittopen");
		//("waittopen");
		t.Tables[tbName].open(()=>{
			
			t.noLogout = false;
			t.Tables[tbName].acting = true;
			t.Tables[tbName].actionNum = 1;
			
			t.Tables[tbName].actionType = tbType;
			t.Tables[tbName].nexActTBL();
		});
	}else{
		if(t.Tables[tbName].Status != "sited" && t.Tables[tbName].Seat > 0)
		{
			t.Tables[tbName].Status = "sited";
			
		}
		
		
	}	
	/*t.sendMSG({
		"Response": "OpenTable",
		"Table": ID.Table,
		"Type": "R",
		"Seat": 0
	});*/
	
	
	//t._opentable.push(ID.Table);
	//callback();
}
bot.prototype.nextAct = function(data){
	let t = this;
	let actions = t.actions[t.actionType];
	let kes = Object.keys(actions);
	let act = kes[t.actionNum];
	let timing = actions[kes[t.actionNum]];
	//console.trace();
	t.actTime =  Date.now();
	DBG("nextAct ACT okkkkkkk:"  + act  + " | time : | " + timing + " | " +  t.Player ,{"type":"botseat","player":t.Player,"Color":"white","details":false,"Date":true}); 
	t.actionNum++;
	if(act == "login")
	{
		t.LoginProcess = "pending";
	}
	if(act == "openTable")
	{
		
		t.noLogout = true;
	}
	
	if(t.actingBot == true)
	{
		
		t.actingBot =  false;
		
		t.actionTimeout = setTimeout(()=>{
		
			t.actingBot =  true;
			switch(act)
			{
				
				case "openTable":
				
			
				if(t.LoginProcess == false)
				{
					t.actionNum = 0;
					t.nextAct(data);
					
				}else{
					if(t.LoginProcess == "pending")
					{
						setTimeout(()=>{
							
							t.actionNum = 1;
							t.nextAct();
							
							
						},2000);
						
					}else{
						if(t.shouldOpen.list.length)
						{
							let tbName = t.shouldOpen.list.splice(0,1);
							if(typeof tbName == "undefined")
							{
								//(t.Player,t.shouldOpen,t.Tables);
							}
								t.OpenTable(tbName[0],()=>{
									
									
									
									});
								
								
						}else{
							
							DBG.error({error:"nextAct",location:"bot:960",player:t.Player});
								
						}
					}
				}
				break;
				
				case "sitOut":
				////("pl",t.Player);
				
				t.sitOut(data.Table,()=>{
					t.nextAct(data);
				});
				break;
				
				case "checkRegister":
				console.log(t.tourRegisterCheck);
				t.checkRegister(t.tourRegisterCheck,()=>{
				
				});
				break;
				
				case "checkSited":
				t.checkSjited(data.Table,()=>{
					
				});
				break;
				
				case "sitOutButton":
				t.sitOutButton(data.Table,()=>{
					////("ok sitOutButton");
				});
				break;
				
				case "deleteTable":
				t.deleteTable(()=>{});
				break;
				
				case "getOut":
				t.getOut(()=>{});
				break;
				
				case "emptySeat":
				let tbs = bcore.getTable(data.Table);
				
				tbs.getEmptySeat(t.Player,(Seat)=>
				{
					if(Seat > 0)
					{
				

			
					t.Reserved[tbs.ID] = Seat;
					t.nextAct({"Table":data.Table,"Seat":Seat});
				
					}else{

				t.actionType = "logout";
						t.actionNum = 0;
					t.nextAct();
							
					
					}
					
						
				},t._changeSeat);
				break;
				
				
				case "reserveSeat":
			
				if( typeof t.Tables[table] != "undefined")
				{
				t.Tables[table].reserveSeat(()=>
				{
				t.nextAct(data);
						
				});
				
				}
				break;
				
				case "logout":
				t.LogoutRequest(()=>{});
				break;
				
				case "completeLogout":
				t.completeLogout(()=>{});
				break;
				
				case "login":
			
				t.Login(()=>{
					t.LoginProcess = true;
					t.nextAct(data);
					
				});
				
				break;
				
			}
			
			
			
		},(timing * 1000));
	}
		
	
}
bot.prototype.deleteTable = function(tbName,callback){
	let t = this;
	t.setStatus({"status":"sitoutdone","table":tbName});
	let _changeSeat = t._changeSeat;
	delete t.Tables[tbName];
	DBG("Table deleted  CMD T : " + tbName + "(must be undefined : "+ typeof  t.Tables[tbName] + ") | Player : " +t.Player + " | _changeSeat : " + _changeSeat ,{"type":"botseat","player":t.Player,"Color":"white","details":false,"Date":true}); 
	if(  _changeSeat == false)
	{
	var waitToLogout = Math.floor((Math.random() * (botData.Settings.waitToLogout[1] - botData.Settings.waitToLogout[0])) + botData.Settings.waitToLogout[0]);
	t.noLogout = false;
	setTimeout(()=>{
		t.getOut(callback);
	},(waitToLogout * 1000));
	
	
	}else{
		
		callback();
	}
	
	
	
}
bot.prototype.sitOutOLD = function(ID,callback){
	
	// response ha ersal mishe 
	// cp.sitout
	// t.tables delete
	// getlogout agar khast mire 
	// t.getLogout
	
	
}


bot.prototype.checkSjited = function(table) {
	
	let t= this;
	
			//("Check sited",t.Player);
	if( typeof t.Tables[table] == "undefined")
	{
		
			t.actionhType = "sitout";
				t.actionNum = 1;
			t.nextAct({"Table":table});
	
	
		//t.Tables[table].checkSited();
	}
	
	
}

bot.prototype.getAlone = function(table,timer) {
	let t= this;
	DBG("get Alone : Player : " +t.Player ,{"type":"botseat","player":t.Player,"Color":"white","details":false,"Date":true}); 
										
	if(typeof t.Tables[table] != "undefined")
	{
		let timing = 0;
		if(timer == "sittingOut" || t.Tables[table].sitingOut)
		{
			 timing = Math.floor((Math.random() * (botData.Settings.waitToSitout[1] - botData.Settings.waitToSitout[0])) + botData.Settings.waitToSitout[0]);
			
		}else{
			 timing = t.Tables[table].profile["alone" + timer]; 
		
		}
		DBG("get Alone : Player : " +t.Player  + " | Time : " + timing + " | Timer :" + timer,{"type":"botseat","player":t.Player,"Color":"yellow","details":false,"Date":true}); 
		t.Tables[table].alone = true;
		t.leaveTimer = setTimeout(()=>
		{
				
			DBG("get Alone : Player : " +t.Player  + " | After " + timing + " Sec ",{"type":"botseat","player":t.Player,"Color":"yellow","details":false,"Date":true}); 
			if(typeof t.Tables[table] != "undefined")
			{
					
				DBG("table pass  : Player : " +t.Player  + " | Table : " + table + " | Alone : " + t.Tables[table].alone ,{"type":"botseat","player":t.Player,"Color":"yellow","details":false,"Date":true}); 
				if(t.Tables[table].alone)
				{
					
					t.Tables[table].sitOutAct("getAlone");
					/*
					t.Tables[table].actionType = "sitout";
						t.Tables[table].actionNum = 0;
						t.Tables[table].nexActTBL();
						*/
				}
			}
		},(timing * 1000));
	}
	
}
bot.prototype.CheckLogin = function(callback) {
	var t = this;
	if(t.loginStatus != "Ok")
	{	
		t.setStatus({"status":"waittologin"});
					
		t.Login(function(msg){
			
			callback(msg);
		});
		
	}else{
		callback({"Result":"Ok"});
	}
}
bot.prototype.Seat_V1 = function(table, settings,callback) {
	var t = this;
	DBG("Check Login P : " + t.Player + " | T : " + table,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
	t.CheckLogin(function(){
		DBG("After Check Login P : " + t.Player + " | T : " + table,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
	
		var Handprecentage = Math.floor((Math.random() * (settings.maxHands - settings.minHands)) + settings.minHands);
		var Timeprecentage = Math.floor((Math.random() * (settings.maxTimes - settings.minTimes)) + settings.minTimes);
		var Rebuys = settings.minRebuys;
	
			
	
		var tbs = bcore.getTable(table);
		DBG("Check Table P : " + t.Player + " | T : " + table  + " | U : " + typeof t.Tables[dt.Table] ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
	
		
		if (typeof t.Tables[dt.Table] == "undefined") 
		{
			t.setstatus2({"status":"waittofindseat","table":tbs.ID});
			DBG("Passed Table P : " + t.Player + " | T : " + table  + " | U : " + typeof t.Tables[dt.Table] ,{"Color":"green","type":"botseat","player":t.Player,"Date":true,"details":false});
			
			
				
			tbs.getjEmptySeat(function(Seat)
			{
				
				t.setstatus2({"status":"waittopen","table":tbs.ID});	1
				if(Seat > 0) 
				{
					
						t.setstatus2({"status":"waittoreserve","table":tbs.ID});
						var buyinAmount = tbs.BuyinMin;
						tbs.Players[Seat].Reserve(function()
						{
							t.setstatus2({"status":"reserved","table":tbs.ID});	
							t.OpenTable({"Table":tbs.ID},function(){
								
											t.setstatus2({"status":"opentable","table":tbs.ID});	
										var waitToSeat = Math.floor((Math.random() * (botData.Settings.waitToSeat[1] - botData.Settings.waitToSeat[0])) + botData.Settings.waitToSeat[0]);
										DBG(waitToSeat + " seconds to sit",{"Color":"white","type":"botseat","player":t.Player,"Date":true,"details":false});
										
											t.setstatus2({"status":"waittorequest","table":tbs.ID});	
										sethTimeout(function(){
										
											t.setstatus2({"status":"requestseat","table":tbs.ID});	
											t.sendMSG({
													"Response": "RequestSeat",
													"Table": tbs.ID,
													"Type": "R",
													"Seat": Seat
												},function(){
													
												t.setstatus2({"status":"waittosit","table":tbs.ID});	
														setTihmeout(function(){
															t.sendMSG({
															"Response": "RSVP",
															"Table": tbs.ID,
															"Type": "R",
															"BuyIn": buyinAmount,
															"AutoRebuy": "No"
															},function(){
																
																t.setstatus2({"status":"rsvp","table":tbs.ID});	
																
																
																tbs.seatBot({"Player":t.Player,"Chips":buyinAmount,"Seat":Seat},function(seated)
																{
																
																	t.setstatus2({"status":"sited","table":tbs.ID});	
															
																	callback();
																													
																
																});
												});
											
													},1000);
													
													
											});
											
										},waitToSeat);
								
								
								
								
							});
							
					
						});
					
				}else{
					bcore.WaitingLogout[t.Player.toLowerCase()] = "emptyseat";
					t.LogoutRequest(callback);
					
							
				}	
			
			
			
			
			
				
		
			});
		
			
		
		}else{
			DBG("Sited ALREADY  : " + t.Player + " - "  + table,{"Color":"white","type":"botseat","player":t.Player,"Date":true,"details":false});
			
			callback();
		}
		
	
	});
	
}
bot.prototype.Seat = function(table,callback) {
	var t = this;
		DBG("Check Table P : " + t.Player + " | T : " + table  + " | U : " + typeof t.Tables[table] ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
		if (typeof t.Tables[table] == "undefined") 
		{
			
			var tbs = bcore.getTable(table);
			t.setStatus({"status":"waittofindseat","table":tbs.ID});
			DBG("Passed Table P : " + t.Player + " | T : " + tbs.ID  + " | U : " + typeof t.Tables[tbs.ID] ,{"Color":"green","type":"botseat","player":t.Player,"Date":true,"details":false});
			tbs.getEmptySeat(t.Player,function(Seat)
			{
				if(Seat > 0) 
				{
					t.Reserved[tbs.ID] = Seat;
					t.setStatus({"status":"waittoreserve","table":tbs.ID});
					tbs.Players[Seat].Reserve(function()
					{
						
						DBG("Check Login P : " + t.Player + " | T : " + tbs.ID + " | S " + t.loginStatus,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
						t.CheckLogin(function(loginResult){
						if(loginResult.Result == "Ok")
						{
							DBG("After Check Login P : " + t.Player + " | T : " + tbs.ID + " | S " + t.loginStatus ,{"Color":"yellow","type":"botseat","player":t.Player,"Date":true,"details":false});
					
							var buyinAmount = tbs.BuyinMin;
						
							//t.setStatus({"status":"reserved","table":tbs.ID});	
							t.setStatus({"status":"waittopen","table":tbs.ID});	
							t.OpenTable({"Table":tbs.ID},function()
							{
								t.setStatus({"status":"opentable","table":tbs.ID});	
								var waitToSeat = Math.floor((Math.random() * (botData.Settings.waitToSeat[1] - botData.Settings.waitToSeat[0])) + botData.Settings.waitToSeat[0]);
								DBG(waitToSeat + " seconds to sit",{"Color":"white","type":"botseat","player":t.Player,"Date":true,"details":false});
								t.setStatus({"status":"waittorequest","table":tbs.ID});	
								setTimeout(function()
								{
									t.setStatus({"status":"requestseat","table":tbs.ID});	
									t.sendMSG({
										"Response": "RequestSeat",
										"Table": tbs.ID,
										"Type": "R",
										"Seat": Seat
									},function()
									{
										t.setStatus({"status":"waittosit","table":tbs.ID});	
										
										
											
										
									});
								},waitToSeat);
								callback({"Result":"Ok"});
							});
						}else{
							callback(loginResult);
							
							
						}
					
					});
				});
			}	
			
		
		
		
				
				
		
			});
		
			
		
		}else{
			DBG("Sited ALREADY  : " + t.Player + " - "  + table,{"Color":"white","type":"botseat","player":t.Player,"Date":true,"details":false});
			
			callback({"Result":"Ok"});
		}
		
	
	
	
	
}
bot.prototype.setCard = function(table, cards) {
	var t = this;
	t.Tables[table]["cards"] = cards;
}
bot.prototype.sendMSG = function(data,callback) {
	////////(data,callback) 
	let t = this;
	t.PNum.INC();
	data.Pnum = this.PNum.NUM;
	
	data.ID = this.ID;
	if (config.debug.response) {
		data.Player = this.Player;
		DBG(JSON.stringify(data), {
			"type": "response",
			"Date": true,
			"player":this.Player,
		});
	}
	if(typeof t.ws != "undefined" && typeof t.ws.send == "function")
	{
		t.ws.send(JSON.stringify(data));
		if(typeof callback != "undefined")
		{
			callback();
		}
	}else{
		////("t.ws.send",t,data);
		DBG.error({error:"sendMSG",location:"bot:1393","player":t.Player,data:data});
		
	}
}
bot.prototype.getOut = function(callback) {
	var t= this;
	//("getout",Object.keys(t.Tables).length,t.noLogout);

	if(t.noLogout || Object.keys(t.Tables).length > 0)
	{
		return true;
	}
			t.loginStatus = "getlogout";
			
						if(t.loginStatus == "getlogout" )
						{
							t.setStatus({"status":"getlogout"});
							DBG("GET LOGOUT  P : " + t.Player,{"type":"botseat","player":t.Player,"Date":true});
							t.LogoutRequest();
						
						}else{
							
							DBG("NO LOGOUT ",{"type":"botseat","player":t.Player,"Date":true,"Color":"red"});
							
						}
						
				
}


bot.prototype.CommanderTablesSitting = function(dt, callback) {
	var t= this;
	// loop in t.tables , if not exists in sittting list get delete
	////////(dt,t.Tables,t.Player);
	let _changeSeat = false;
	DBG("Table sitting P : " + t.Player + " | " + JSON.stringify(dt.Tables),{"type":"botlogin","player":t.Player,"Date":true});
	for(var tb in t.Tables)
	{
		
		if(dt.Tables.indexOf("R" + tb) < 0)
		{
				
				var tbs = bcore.getTable(tb);
				if(typeof tbs == "undefined")
				{
					//("tbsudef",tb,t.Player,tbs);
					errroring5();
				}
				if((t.Tables[tb].Status != "waittofindseat" || t.Tables[tb].sitingForce))
				{
						var seat = t.Tables[tb].Seat;
						if(seat == -1)
						{
						//( t.Tables[tb]);	
							
						}
						
						DBG("Table sitout done T : " + tbs.ID + " S : " + seat + " P : " + t.Player ,{"type":"botseat","player":t.Player,"Date":true});
						if(typeof tbs.Players[seat] != "undefined")
						{
							
							tbs.Players[seat].sitOut(()=>{
									
							_changeSeat = true;
							//console.info("before _changeSeat",t.Player,t._changeSeat,_changeSeat);
							t._changeSeat = t._changeSeat  == "changing" ? t.Tables[tb].Seat : false   ;
							//console.info("after _changeSeat",t.Player,t._changeSeat);
							t.deleteTable(tb,()=>{
									
								if(t._changeSeat > 0)
								{
									
									
									setTimeout(()=>{
										
										
										t.OpenTable(tb,()=>{},"changeSeat");
									},1000);
								}
							});
								
								
							
						});
					}
				}
				
					
		
			
		}
		
	}
	
}

bot.prototype.CommanderRegisterRequest = function(dt, callback) {
		let t= this;
	var precentage = Math.floor((Math.random() * (60 - 5)) + 5);
	setTimeout(()=>{
		console.log("get register",t.tourRegisterCheck);
		t.sendMSG({"Response":"Register","Table":t.tourRegisterCheck,"Type":"T"});
		
		
		
	},(precentage * 1000));
}
bot.prototype.CommanderWaiting = function(dt, callback) {
	
		let t= this;
		
		
	if(dt.Wait.indexOf(t.Player.toLowerCase()) == -1){
		
		t.sendMSG({"Response":"RegisterRequest","Table":dt.Table,"Type":"T"});
		
	}
	
}
bot.prototype.CommanderDealer = function(dt, callback) {
	var tbs = bcore.getTable(dt.Table);
	if(Date.now() > (tbs.Dealer.set + 2000))
	{
		tbs.Dealer.set = Date.now();
		tbs.Dealer.dealer = dt.Dealer;
		
		
	}
	
}
bot.prototype.CommanderChat = function(dt, callback) {
	let t = this;
	var ex = dt.Text.split(" ");
	if (ex[0] == "Starting" && ex[1] == "Hand") {
	var tbs = bcore.getTable(dt.Table);
	if(typeof t.Tables[dt.Table] != "undefined")
	{
		t.Tables[dt.Table].inPot = [0,0,0,0]; 
		t.Tables[dt.Table].state = 0;
		t.Tables[dt.Table].alone = false;
		t.Tables[dt.Table].addInPot = true;
		////////("reseted",t.Seat,t.Tables[dt.Table].inPot,t.Tables[dt.Table].state);
		
			if (tbs.handnumber != ex[2]) {
				tbs.dealed = false;
				tbs._allcards = [];
				tbs._dealed = [];
				tbs._cardDealed = [];
				tbs._players = {};
				tbs._loger = {
					1: false,
					2: false,
					3: false
				};
				tbs.showDone = false;
		tbs.flop = [0, 0, 0, 0, 0];
			tbs.state = 0;
			tbs.total = 0;
			
				tbs.setVal("handnumber", ex[2]);
				tbs.resetHands(function() {
					if(t.Tables[dt.Table].sitingOut)
					{
						t.Tables[dt.Table].sitOutAct("CommanderChat-sitingOut");
						//t.sendMSG({"Response":"SitOut","Table":dt.Table,"Type":"R","Box":"SitHand","Checked":"Yes"});
						//t.sendMSG({"Response":"SitOut","Table":dt.Table,"Type":"R","Box":"SitBlind","Checked":"Yes"});
					}
					tbs.allBots = true;
				});
			}
		}
	}
}
bot.prototype.CommanderHotSeat = function(dt, callback) {
	var tbs = bcore.getTable(dt.Table);
	bcore.sendMonitor({
		"Command": "tablelog",
		"Type": "hotseat",
		"Seat": dt.Seat,
		"Table": dt.Table
	});
}
bot.prototype.CommanderTurn = function(dt, callback) {
	let t = this;
		if(typeof t.Tables[dt.Table] !="undefined")
		{
			t.Tables[dt.Table].state ++;
		}
	var tbs = bcore.getTable(dt.Table);
	if (tbs._loger[2] == false) {
		tbs._loger[2] = true;
		tbs.setFlop(3, dt.Board4);
		tbs.setVal("state", 2);
		bcore.sendMonitor({
			"Command": "tablelog",
			"Type": "flop",
			"Table": dt.Table,
			"Cards": "<div class='cards'>" + (tbs.flop[0] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[0] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[1] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[1] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[2] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[2] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[3] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[3] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[4] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[4] - 1) * 23) + "px 0'></div>" : "") + "</div>"
		});
		tbs.CheckHands(function() {});
	}
}
bot.prototype.CommanderRiver = function(dt, callback) {
	let t = this;
	if(typeof t.Tables[dt.Table] !="undefined")
		{
			t.Tables[dt.Table].state ++;
		}

		var tbs = bcore.getTable(dt.Table);
		if (tbs._loger[3] == false) {
			tbs._loger[3] = true;
			tbs.setFlop(4, dt.Board5);
			tbs.setVal("state", 3);
			bcore.sendMonitor({
				"Command": "tablelog",
				"Type": "flop",
				"Table": dt.Table,
				"Cards": "<div class='cards'>" + (tbs.flop[0] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[0] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[1] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[1] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[2] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[2] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[3] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[3] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[4] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[4] - 1) * 23) + "px 0'></div>" : "") + "</div>"
			});
			tbs.CheckHands(function() {});
		}
	
}
bot.prototype.CommanderTotal = function(dt, callback) {
	var tbs = bcore.getTable(dt.Table);
	tbs.total = dt.Total;
	bcore.sendMonitor({
		"Command": "tablelog",
		"Type": "total",
		"Total": tbs.total.formatMoney(0),
		"Table": dt.Table
	});
}
bot.prototype.CommanderInvite = function(dt, callback) {
	let t = this;
	if(typeof t.Tables[dt.Table] != "undefined")
	{
		
		t.Tables[dt.Table].RSVP(dt,()=>{
			if(t.shouldOpen.list.length)
			{
				t.actionNum = 1;
				t.nextAct();
			
				
			}
			
			//bcore.nextBot(()=>{});
		});
	}

}
bot.prototype.CommanderFlop = function(dt, callback) {
	let t = this;
	
	var tbs = bcore.getTable(dt.Table);
	if(typeof t.Tables[dt.Table] !="undefined")
		{
			t.Tables[dt.Table].state ++;
		}
	if (tbs._loger[1] == false) {
		
		tbs._loger[1] = true;
		tbs.setFlop(0, [dt.Board1, dt.Board2, dt.Board3, 0, 0]);
		tbs.setVal("state", 1);
		bcore.sendMonitor({
			"Command": "tablelog",
			"Type": "flop",
			"Table": dt.Table,
			"Cards": "<div class='cards'>" + (tbs.flop[0] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[0] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[1] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[1] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[2] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[2] - 1) * 23) + "px 0'></div>" : "") + "</div>"
		});
		tbs.CheckHands(function() {});
	}
	
}
bot.prototype.CommanderPing = function(dt, callback) {
	var t = this;
	if (dt.Pong == "Yes") {
		t.sendMSG({
			"Response": "Pong"
		});
	}
}
bot.prototype.CommanderLogoutRequest = function(dt, callback) {
	
	var t = this;
	
	if (dt.Message == "Ok") {
	
		t.completeLogout(callback);
		delete bcore.Clients[t.Player.toLowerCase()];
		if(typeof DBG.store[t.Player.toLowerCase()] != "undefined")
			{
				delete DBG.store[t.Player.toLowerCase()];
			}
				
	}else{
		////(t.Player);
		////(dt);
		
	}
}
bot.prototype.CommanderLogoutRequestOLD = function(dt, callback) {
	var t = this;
	if (dt.Message == "Ok") {
		
		t.Logout(function() {
			DBG("Get Logout :" + t.Player, {
				"type":"botseat","player":t.Player,
				"Date": true
			});
			bcore.sendMonitor({"Command":"deleteBot","Type":"Terminated","Player":t.Player.toLowerCase()});
			delete bcore.Clients[t.Player.toLowerCase()];
			if(typeof DBG.store[t.Player.toLowerCase()] != "undefined")
			{
				delete DBG.store[t.Player.toLowerCase()];
			}
					
					
				
			
			DBG("Logout Done:" + t.Player, {
				"type":"botseat","player":t.Player,
				"Date": true
			});
			if (config.debug.tables || config.debug.botseat) {
				DBG.table(bcore.Clients, ["Player", "ID", "SessionKey"]);
			}
		});
	} else {
		t.loginStatus = "Ok";
		//////("not logout", t.Player, dt.Message);
	}
}
bot.prototype.CommanderHandHelper = function(dt, callback) {
	var t = this;
	var tbs = bcore.getTable(dt.Table);
	if (typeof t.Tables[dt.Table] != "undefined") {
		dt.eSeed = t.SessionKey;
		var seat = t.Tables[dt.Table].Seat;
		var hlp = decoders.HandHelper(dt);
		var Games = {
			"Limit Hold'em": "holdem",
			"NL Hold'em": "holdem",
			"PL Omaha-5": "omaha5",
			"Limit Omaha-5": "omaha5",
			"PL Omaha": "omaha"
		};
		bcore.sendMonitor({
			"Command": "tablelog",
			"Type": "Helper",
			"Table": dt.Table,
			"Helper": hlp,
			"Seat": seat
		});
	}
}
bot.prototype.CommanderOpenTable = function(dt, callback) {
	let t= this;
	
	
	
	if(dt.Type == "T")
	{
		
			
	
			
	let profile = {
		"runItTwice":10, 
		"preRebuy":botData.Settings.preRebuy,
		"aloneEnd":1,
		"aloneStart":300,
		"callSpeed":3,
		"raiseSpeed":3,
		"checkSpeed":3,
		"showHand":30
	};
		let tbs = bcore.getTable(dt.Table);
		t.Tables[dt.Table] = new tbl({
													"Rebuys":botData.Settings.minRebuys ,
													"Profile":profile ,
													"GameID":dt.Table,
													"Player":t.Player,
													"PNum" : t.PNum,
													"nextAct":t.nextAct,
													"Seat": false,
													//"PlayerID":t.ID,
													//"sendMSG":t.sendMSG
													//"BuyIn": dt.MinBuyIn,
													//"ws":t.ws,
													
												});
		
	}
	
}
bot.prototype.CommanderTable = function(dt, callback) {
	var t = this;
	
	var tbs = bcore.getTable(dt.Table);
	
	DBG("Loading Table :" + dt.Table, {
		"type": "updatetable",
		"Date": true,
		"Color":"yellow",
		"player":"table",
	});

	var opentable = false;
	var ind = t._opentable.indexOf(dt.Table);
	if( ind > -1)
	{
		delete t._opentable[ind];
		
		opentable = true;	
	}
	
	tbs.update(dt,{"opentable":opentable},()=>{
	
		
		if(dt.Type == "T")
		{
		
			if(typeof t.Tables[dt.Table] != "undefined" && t.Tables[dt.Table].Seat == false)
			{
				for(let stt in dt.Player)
				{
					
					if(dt.Player[stt].toLowerCase() == t.Player.toLowerCase())
					{
							t.Tables[dt.Table].Seat = parseInt(stt) + 1;
							break;
						
					}
				}
				
				
			}
			
			
			
		}
		
		tbs.checkAlone();
		
		
	});
}
bot.prototype.CommanderPotRake = function(dt, callback) {
	var t = this;
	bcore.sendMonitor({
		"Command": "tablelog",
		"Type": "pot",
		"Table": dt.Table,
		"pot": dt.Total.formatMoney(0)
	});
}
bot.prototype.CommanderBet = function(dt, callback) {
	let t= this;
	let ss = t.Tables[dt.Table];
	var tbs = bcore.getTable(dt.Table);
	//console.log("Set bet ",{tbsState:tbs.state,localTableState: ss.state,addInPot:ss.addInPot,Bet:dt.Bet,localSeat:ss.Seat,Seat:dt.Seat,Player:t.Player,clt:t.CLType});
	if(ss)
	{
	if(ss.addInPot )
	{

		if(dt.Bet > 0 )
		{
			
			if( typeof tbs._players[dt.Seat] == "undefined")
			{
				tbs._players[dt.Seat] = {"Player":tbs.Players[dt.Seat].Player,"Seat":dt.Seat,"Status":tbs.Players[dt.Seat].Status,"Chips":tbs.Players[dt.Seat].Chips,"Bot":bcore.isBot(tbs.Players[dt.Seat].Player),"Cards":[],"_Cards":[],"Helper":"","inPot":[0,0,0,0]};
				//console.log("obj created CommanderBet",tbs._players[dt.Seat] );
			}
		
			tbs._players[dt.Seat].inPot[tbs.state] = dt.Bet;
			if(ss.Seat == dt.Seat)
			{
				ss.inPot[ tbs.state ] = dt.Bet ;
				//console.log("=========== seted inpot ",t.Player,ss.inPot[ tbs.state ],tbs.state);
			}
			
		}
		setTimeout(function(){
			
			
			ss.addInPot = true;
					 
				
		},800);
		
	}else{
		
		////////("no");
	}
	}
	//t.Tables[dt.Table].involved = ret.involved;
}
bot.prototype.CommanderPotAward = function(dt, callback) {
	var t = this;
	var tbs = bcore.getTable(dt.Table);
	tbs._seted = false;
}
bot.prototype.CommanderMessage = function(dt, callback) {
	var t = this;
	var tbs = bcore.getTable(dt.Table);
	//////(dt, t.Player + " : " + t.ID);
	
	DBG("Message : " + t.Player + " : " + t.ID + " : " + tbs.BuyinMin + " : " + tbs.BuyinMax, {
		"type":"botseat","player":t.Player,
		"Date": true,
		"Color": "white"
	});
	DBG(JSON.stringify(dt), {
		"type":"botseat","player":t.Player,
		"Date": true,
		"Color": "white"
	});
	
	if(dt.Text == "Connection terminated by Administrator"  && dt.Disconnect == "Yes")
	{
		////("terminated");
		//Commander:turnOnMonitor
		delete bcore.Clients[t.Player.toLowerCase()];
//console.table(bcore.Clients,["Player","Status"]);
		
	}
	let msg = dt.Text.replace("Message from Administrator:<br><br>","");//.trim().toString();
	let comander = msg.substring(0,7);
	let res  = {"Command":"default"};
	if(comander == "Command")
	{
		let parts = msg.split(",");
		for(let prt of parts)
		{
			let pr = prt.split(":");
			res[pr[0]] = pr[1];
			
			
		}
		
		
	}
	//{"Command":"turnOnMonitor"}
		//let res  = {"Command":""};
		if(typeof res.Command != "default")
		{
			switch(res.Command)
			{
				
				case "terminateAll":
				//////("terminateAll...");
				
				bcore.terminateAll(res);
				
				break;
				case "turnOnMonitor":
				//////("terminateAll...");
				
				bcore.turnOnMonitor("on",res.Username);
				
				break;
				case "turnOffMonitor":
				//////("terminateAll...");
				
				bcore.turnOnMonitor("off");
				
				break;
				default:
				//////(res);
				break;
				
				
				
			}
		}else{
			
	//("msg","____" + msg  + "_____");
		}
}
bot.prototype.CommanderLogin = function(dt, callback) {
	var t = this;
	if (dt.Status == "Ok") {
		
		var MSG = {
				"Response": "Balance"
			};
			t.sendMSG(MSG);
		
		t.loginStatus = "Ok";
		callback();
	}
}


function randomIntFromInterval(min, max) {
	return Math.floor(Math.random() * (max - min + 1) + min)
}
bot.prototype.CommanderButtons = function(dt, callback) {
	var t = this;
	if(dt.Type == "T" && dt.Button2 == "Rebuy")
	{
		var act = "Tour";
		
	}else{
	
	var btns = ["Call", "Check", "Ready", "Add Chips", "Start","Twice","Show"];
	
	var tbs = bcore.getTable(dt.Table);
	var act = "";
	
	if (btns.indexOf(dt.Button2)  >  -1) {
		if (dt.Button2 == "Call" || dt.Button2 == "Check") {
		////////({Button2:dt.Button2,Pot:dt.Pot});
			act = "Action";
		} else {
			act = dt.Button2;
		}
	} else {
		if (btns.indexOf(dt.Button3) >  -1) {
			act = dt.Button3.replace(" ", "")
		}
	}
	
	}
	if(act != "")
	{
		
	var fname = "Button" + act;
	
	if (typeof t[fname] == "function") {
		t[fname](dt, tbs,callback);
	}
	}
}
bot.prototype.CommanderDeal = function(dt, callback) {
	
	let t = this;
	var tbs = bcore.getTable(dt.Table);
	console.log(dt,tbs.dealed);
	if(!tbs.dealed)
	{
		
		
		
		
		
		
	tbs.dealed = dt.Seats;
	for(let i =0;i<dt.Seats.length;i++)
	{
		let st = dt.Seats[i];
		st = st == 0 ? 10 : st;
		let pl = tbs.Players[st];
		let isBot = bcore.isBot(pl.Player);
		console.log("injaaaaaaaaaaaa",isBot,pl.Player);
		if(isBot){tbs._dealed.push(parseInt(st));}else {tbs.allBots = false;}
	
		if( typeof tbs._players[st] == "undefined")
		{
			tbs._players[st] = {"Player":pl.Player,"Seat":pl.Seat,"Status":pl.Status,"Bot":isBot,"Cards":[],"_Cards":[],"Chips":pl.Chips,"Helper":"","inPot":[0,0,0,0]};
		}else{

		console.log("seted already",tbs._players[st]);
		}			
	}

	 if(tbs._cardDealed.length)
				{
					for(let st of tbs._cardDealed)
					{
						tbs._dealed.splice(tbs._dealed.indexOf(st),1);
						
					}
					tbs._cardDealed = [];
				}
	 
			console.log(tbs._cardDealed,tbs._dealed);	
				if(tbs._dealed.length == 0)
				{
					tbs.SetHands((allhands)=>{
						tbs.calculateAllhand((allhands)=>{
							tbs.CheckHands(()=>{});
						});
					});
				}else{
					//console.table(tbs._players,["Player","Seat","Cards"]);
					//console.log(tbs._dealed,tbs._dealed.length,tbs._cardDealed,tbs.ID);
					//remainindealer();
					
					
				}
				
	 
	}

}
bot.prototype.CommanderECards = function(dt, callback) {
	var t = this;
	var botTable = t.Tables[dt.Table];
	console.log("CommanderECards",typeof botTable ,dt,t.Player);
	if(typeof botTable != "undefined") 
	{
		var seat = botTable.Seat;
		var tbs = bcore.getTable(dt.Table);
		dt.eSeed = t.SessionKey;
		var dec = decoders.ECards(dt);
		
		var dex = bcore.clearplayercards([dec[0], dec[1], dec[2], dec[3], dec[4]]);
		tbs._allcards = [...dex,...tbs._allcards];
		
	
		
		if(typeof  tbs.Players[seat] != "undefined")
		{
			if(tbs.dealed != false)
			{
			console.log("ina rafte",tbs._cardDealed,tbs._dealed,tbs._dealed.indexOf(seat),seat);
				tbs._dealed.splice(tbs._dealed.indexOf(seat),1);
				if(tbs._cardDealed.length)
				{
					for(let st of tbs._cardDealed)
					{
						tbs._dealed.splice(tbs._dealed.indexOf(st),1);
						
					}
					tbs._cardDealed = [];
				}
				
				if(tbs._dealed.length == 0)
				{
					tbs.SetHands((allhands)=>{
						tbs.calculateAllhand((allhands)=>{
							tbs.CheckHands(()=>{});
						});
					});
				}else{
					
					console.log("CommanderECards",tbs._dealed);
				}
				
				
			}else{
				console.log("not set yet",seat);
				tbs._cardDealed.push(seat);
				
				
			}
			
			console.log("set done",tbs._dealed,tbs._dealed.length,tbs._cardDealed,tbs._cardDealed.length);
			tbs.Players[seat]["Cards"] = dex;
			tbs.Players[seat]["_Cards"] = dex;
			
				tbs.Players[seat]._played++;
			botTable.played++;
			if(typeof tbs._players[seat] == "undefined")
			{
				if(bcore.isBot(tbs.Players[seat].Player))  
				{
					tbs._players[seat] = {"Player":tbs.Players[seat].Player,"Seat":tbs.Players[seat].Seat,"Status":tbs.Players[seat].Status,"Chips":tbs.Players[seat].Chips,"Bot":bcore.isBot(tbs.Players[seat].Player),"Cards":dex,"_Cards":dec,"Helper":"","inPot":[0,0,0,0]};
		
			//console.log("create player ecards",tbs._players[seat]);
					
				}else{
					
					//console.log("no create player ecards",tbs._players[seat]);
				}
			}else{
				//console.log("not undef",dex,seat);
					tbs._players[seat]["Cards"] = dex;
					tbs._players[seat]["_Cards"] = dec;
					
					
			}
				//console.log("=\n\n\n\n\n======TWICE ====",botTable.played,(botTable.Hands * 0.05),botTable.profile);
				
				
			if(tbs.Type == "R")
			{				
				
				if (botTable.played > (botTable.Hands * 0.05) &&  botTable.profile.runItTwice === true ) {
				
					t.runItTwice(dt.Table);
					
				}
				if (botTable.chips < (tbs.BB * 5)) {
					
					let precentage = Math.floor((Math.random() * (100 - 1)) + 1);
					if(precentage <= botTable.profile.preRebuy)
					{
						
						
					t.sendMSG({
						"Response": "AddChips",
						"Table": dt.Table,
						"Type":"R",
						"Amount":"Min",
						"AutoRebuy":"No"
						});
					}
					
				}
				if (botTable.played > botTable.Hands) {
					
					t.Tables[dt.Table].sitOutAct("Limit Hands");
					
					/*	botTable.actionType = "sitout";
						botTable.actionNum = 0;
						botTable.nexActTBL();
							
				*/
					
				}
			}
			
			
			tbs.flop = [0, 0, 0, 0, 0];
			tbs.state = 0;
			tbs.total = 0;
			
				
				
				//console.log(tbs.Players[seat],"----",tbs._players[seat],"----",dex,bcore.clearplayercards(tbs.flop),tbs.Games[tbs.Game]);
				//aaaTA();
			AnalClass.getfinalhand(dec, bcore.clearplayercards(tbs.flop), tbs.Games[tbs.Game], function(handanal) {
				//ID.Helper = handanal.helper;
				tbs._players[seat]["Helper"] = handanal.helper;
				//console.log("Seted ecard for bot",dex,tbs._players[seat]["Helper"]);
			});
			
		}
		
		
	}
}
bot.prototype.CommanderECardsOLD = function(dt, callback) {
	var t = this;
	DBG("CommanderECards " + dt.Table + " type:" + (typeof t.Tables[dt.Table]), {
			"type":"sethand","player":t.Player,
			"Date": true
		});
	if (typeof t.Tables[dt.Table] != "undefined") {
		var tbs = bcore.getTable(dt.Table);
		
		var Games = {
			"NL Hold'em": "holdem",
			"Limit Hold'em": "holdem",
			"PL Omaha-5": "omaha5",
			"Limit Omaha-5": "omaha5",
			"PL Omaha": "omaha5"
		};
		gametype = Games[tbs.Game];
		dt.eSeed = t.SessionKey;
		var dec = decoders.ECards(dt);
		var dex = [dec[0], dec[1], dec[2], dec[3], dec[4]];
		var CCards = (dex[0] > 0 ? "<div class='card c1' style='background-position:-" + ((dex[0] - 1) * 23) + "px 0'></div>" : "") + (dex[1] > 0 ? "<div class='card c1' style='background-position:-" + ((dex[1] - 1) * 23) + "px 0'></div>" : "") + (dex[2] > 0 ? "<div class='card c1' style='background-position:-" + ((dex[2] - 1) * 23) + "px 0'></div>" : "") + (dex[3] > 0 ? "<div class='card c1' style='background-position:-" + ((dex[3] - 1) * 23) + "px 0'></div>" : "") + (dex[4] > 0 ? "<div class='card c1' style='background-position:-" + ((dex[4] - 1) * 23) + "px 0'></div>" : "");
		bcore.sendMonitor({
			"Command": "tablelog",
			"Type": "ECards",
			"Table": dt.Table,
			"Cards": CCards,
			"Seat": seat
		});
		var botTable = t.Tables[dt.Table];
		if(typeof botTable != "undefined")
		{
			var seat = botTable.Seat;
			if(typeof  tbs.Players[seat] != "undefined")
			{
				
				
			tbs.Players[seat]["Cards"] = dex;
			tbs._players[seat]["Cards"] = dex;
			
			tbs.Players[seat]._played++;
			botTable.played++;
			DBG("Hand Limit Check : " + t.Player + " - Played: " + botTable.played + "(" + botTable.Hands + ") - " +  (botTable.profile.runItTwice != false ? botTable.profile.runItTwice : "" ) + " - " + (botTable.Hands * 0.05), {
				"type":"botseat","player":t.Player,
				"Date": true
				
			});
			DBG("Cards seted : " + JSON.stringify(bcore.clearplayercards(tbs.Players[seat]["Cards"])) + " Player : " + t.Player, {
				"type": "sethand",
				"player":t.Player,
				"Date": false
			});
			
			if (botTable.played > (botTable.Hands * 0.05) &&  botTable.profile.runItTwice === true ) {
			
				t.runItTwice(dt.Table);
				
			}
			if (botTable.chips < (tbs.BB * 5)) {
				
				let precentage = Math.floor((Math.random() * (100 - 1)) + 1);
				if(precentage <= botTable.profile.preRebuy)
				{
					
					
				t.sendMSG({
					"Response": "AddChips",
					"Table": dt.Table,
					"Type":"R",
					"Amount":"Min",
					"AutoRebuy":"No"
					});
				}
				
			}
			if (botTable.played > botTable.Hands) {
				
				t.Tables[dt.Table].sitOutAct("Limit Hands");
				
				/*	botTable.actionType = "sitout";
					botTable.actionNum = 0;
					botTable.nexActTBL();
						
			*/
				
			}
			
			tbs.flop = [0, 0, 0, 0, 0];
			tbs.state = 0;
			tbs.total = 0;
			
			
			tbs.SetHasnds(function(allhands) {
				tbs.calculateAllhand(function(allhands) {
					tbs.CheckHands(function() {});
				});
			});
			
			
			}else{
				
			DBG.error({error:"CommanderECards botTable not defined",location:"bot:2053",Seat:seat,player:t.Player,data:dt});
			}
		}else{
			DBG.error({error:"CommanderECards botTable not defined",location:"bot:2053",Seat:seat,player:t.Player,data:dt});
		
			
			
		}
	}
}
bot.prototype.runItTwice = function(tbName, callback) {
	
	var t = this;
	t.Tables[tbName].profile.runItTwice = true;
	t.sendMSG({
					"Response": "RunItTwice",
					"Table": tbName,
					"Type":"R",
					"Checked":"Yes"
					});
					if(typeof callback == "function")
					{
						callback();
						
						
					}
}
bot.prototype.CommanderActionChips = function(dt, callback) {
	var t = this;
	var tbs = bcore.getTable(dt.Table);
	tbs.Players[dt.Seat].Chips = dt.Chips;
	if(typeof t.Tables[dt.Table] != "undefined")
	{
		t.Tables[dt.Table].chips =  dt.Chips;
	}
	if(dt.Action1 == "Sitting Out" && dt.Action2 == "Sitting Out")
	{
		tbs.Players[dt.Seat].Action = 15;
		tbs.Players[dt.Seat].Status = "sittinout";
		tbs.checkAlone();
	}
	if (dt.Action1 == "Fold") {
		tbs.Players[dt.Seat].Action = 14;
		tbs.Players[dt.Seat].reset();
		delete tbs._players[dt.Seat];
	}
	
}
bot.prototype.CommanderBalance = function(dt, callback) {
	var t = this;
	t.Balance.Available = dt.Available;
	t.Balance.Available2 = dt.Available2;
	t.Balance.InPlay = dt.InPlay;
	t.Balance.InPlay2 = dt.InPlay2;
	t.Balance.Total = dt.Total;
	t.Balance.Total2 = dt.Total2;
}
bot.prototype.CommanderSession = function(dt, callback) {
	var t = this;
	
	maven.mvapi({
		"Command": "AccountsSessionKey",
		"Player": t.Player  
	}, function(resu) {
			
		if(resu.Result == "Ok")
		{
			t.ID = dt.ID;
			t.SessionKey = resu.SessionKey;
			var MSG = {
				"Response": "Login",
				"Player": resu.Player,
				"SessionKey": resu.SessionKey
			};
			t.sendMSG(MSG);
		}else{
			callback(resu);
			
		}
	});
}
bot.prototype.ButtonTour = function(dt, tbs, callback) {
	let t= this;
	if(dt.Button1 == "Leave" && dt.Button2 == "Rebuy" )
	{
		if(typeof t.Tables[dt.Table] != "undefined")
		{
			let btn = false;
			let tourName = dt.Table.split("-")[0].trim();
			
			console.log("--- rebuys ",tourName,t.tournaments[tourName].Rebuys,t.Player);
			if (t.tournaments[tourName].Rebuys > 0) 
			{
				//bt.tournaments[row.tourName] 
				var precentage =  Math.floor((Math.random() * (100 - 1)) + 1);
				let dbl = precentage < 30 ? true : false;
						
					t.tournaments[tourName].Rebuys--;
					t.tournaments[tourName].Rebought++;
					 btn = "Rebuy";
					if(dbl)
					{
						t.tournaments[tourName].Rebuys--;
						t.tournaments[tourName].Rebought++;
						btn = "Double Rebuy";
					}
				
			}else{
				 btn = Math.floor((Math.random() * (100 - 1)) + 1) < 30 ? false : "Leave";
				
			}
				setTimeout(function() {
				
					DBG("Rebuy tour - rebuys = " + t.tournaments[tourName].Rebuys, {
						"type": "buttons",
						"player":t.Player,
						"Date": true
					});
				
							 t.sendMSG({
							"Response": "Button",
							"Table": dt.Table,
							"Type": dt.Type,
							"Amount": 0,
							"Button": btn
						});
					
					
				}, (Math.floor((Math.random() * (5 - 1)) + 1)) * 1000);
			
			
		}
	
		
	}
}
bot.prototype.ButtonStart = function(dt, tbs, callback) {
	var t = this;
	var precentage = Math.floor((Math.random() * (100 - 1)) + 1);
	//(t._changeSeat ,"in shart", (typeof t.Tables[dt.Table] != "undefined" && t._changeSeat != false));
	if (precentage <= botData.Settings.startButton ||  (typeof t.Tables[dt.Table] != "undefined" && t._changeSeat != false)) {
		setTimeout(function() {
			callback({
				"Response": "Button",
				"Table": dt.Table,
				"Type": "R",
				"Amount": 0,
				"Button": "Start"
			});
		},(  (typeof t.Tables[dt.Table] != "undefined" && t._changeSeat != false) ? 0: 2000));
	}
}

bot.prototype.requestTime = function(tbName, callback) {
	
	var t = this;
	
	t.sendMSG({
					"Response": "Button",
					"Table": tbName,
					"Type":"R",
					"Button":"Time",
					"Amount":0
					});
					if(typeof callback == "function")
					{
						callback();
						
						
					}
}



bot.prototype.addChips = function(tbName, callback) {
		var t = this;
	
					
					t.sendMSG({
						"Response": "AddChips",
						"Table": tbName,
						"Type": "R",
						"Amount":t.Tables[tbName].rebuyAmount,
						"AutoRebuy": "No"
					},function()
					{
						
						t.sendMSG({
							"Response": "Button",
							"Table": tbName,
							"Type": "R",
							"Amount": 0,
							"Button": "Add Chips"
						});
						
					}); 
					
					callback();
}
bot.prototype.ButtonShow = function(dt, tbs, callback) {
		var t = this;
	if(typeof t.Tables[dt.Table] != "undefined"  && t.Tables[dt.Table].showCard  )
	{		

let cardslength = (tbs.Games[tbs.Game] == "holdem" ? 2 : (tbs.Games[tbs.Game] == "omaha" ? 4 : (tbs.Games[tbs.Game] == "omaha5" ? 5 : 6)));
let am = "";
for(let cg =0;cg<cardslength;cg++)
{
	am += "u";
	
}
setTimeout(()=>{
		 t.sendMSG({
							"Response": "Button",
							"Table": dt.Table,
							"Type": "R",
							"Amount": am,
							"Button": "Show"
						});
						
						t.Tables[dt.Table].showCard = false;
						},(1 * 1000));
	}

	
}
bot.prototype.ButtonAddChips = function(dt, tbs, callback) {
	var t = this;
	var precentage = 0;// Math.floor((Math.random() * (100 - 1)) + 1);
	DBG("button3 addchip rebuys = " + t.Tables[dt.Table].Rebuys, {
		"type": "buttons",
		"player":t.Player,
		"Date": true
	});
	DBG(JSON.stringify(dt), {
		"type": "buttons",
		"player":t.Player,
		"Date": true
	});
	
	//if (precentage <= botData.Settings.rebuyDecide) {
		if (typeof t.Tables[dt.Table] != "undefined") {
			if (t.Tables[dt.Table].Rebuys > 0) {
				t.Tables[dt.Table].Rebuys--;
				t.Tables[dt.Table].Rebought++;
				setTimeout(function() {
					DBG("button3 addchip rebuys = " + t.Tables[dt.Table].Rebuys, {
						"type": "buttons",
						"player":t.Player,
						"Date": true
					});
				
						t.addChips(dt.Table,callback);
					
				}, 2000);
			} else
			{
				bcore.WaitingLogout[t.Player.toLowerCase()] = "AddChipsButton";
				
				if (typeof t.Tables[dt.Table] != "undefined") 
				{
					t.Tables[dt.Table].sitOutAct("AddchipButton-noRebuy");
					
					}
			}
		}
	//}
	
}
bot.prototype.ButtonTwice = function(dt, tbs, callback) {
	
	var t = this;
	if(typeof t.Tables[dt.Table] != "undefined" && t.Tables[dt.Table].profile.runItTwice != false )
	{		
setTimeout(()=>{
		 t.sendMSG({
							"Response": "Button",
							"Table": dt.Table,
							"Type": "R",
							"Amount": 0,
							"Button": "Twice"
						});
						},(Math.floor((Math.random() * (4 - 1)) + 1)  * 1000));
	}

}
bot.prototype.ButtonReady = function(dt, tbs, callback) {
	
		var t = this;
		DBG(" Ready  typeof " + dt.Table  + " - " +  typeof t.Tables[dt.Table] , {
			"type": "botseat",
			"player":t.Player,
			"Date": true
		});
	
	if(dt.Type == "T" )
	{
setTimeout(()=>{
		t.sendMSG({
						"Response": "Button",
						"Table": dt.Table,
						"Type": dt.Type,
						"Button": "Ready",
						"Amount": 0
					});
					},(Math.floor((Math.random() * (120 - 20)) + 20)  * 1000));
		return true;
	}
		//(" Ready  typeof " + dt.Table  + " - " +  typeof t.Tables[dt.Table] , {"type": "botseat","player":t.Player,"Date": true});
		
	if(typeof t.Tables[dt.Table] != "undefined" && t.Tables[dt.Table].sitingOut)
	{			
		
		let precentage = Math.floor((Math.random() * (100 - 1)) + 1);
		if(precentage < 95)
		{
			var waitToSitout = Math.floor((Math.random() * (botData.Settings.waitToSitout[1] - botData.Settings.waitToSitout[0])) + botData.Settings.waitToSitout[0]);
				setTimeout(()=>{				
					if(typeof t.Tables[dt.Table] != "undefined" )
					{
						t.Tables[dt.Table].sitOut(()=>{});
					}
				},(waitToSitout * 1000));
		}else{
			bcore.Clients[t.Player.toLowerCase()].ws.close();
		}
		//t.Tables[dt.Table].sitOutAct("ReadyButton-sitingOut");
		/*
				t.Tables[dt.Table].actionType = "sitout";
				t.Tables[dt.Table].actionNum = 1;
						
				t.Tables[dt.Table].nexActTBL();
					
*/
		 // return true;
	}else{
		DBG(" Ready " + JSON.stringify(dt), {
			"type": "buttons",
			"player":t.Player,
			"Date": true
		});
		var rand1 = Math.floor((Math.random() * (botData.Settings.rebuyTime[1] - botData.Settings.rebuyTime[0])) + botData.Settings.rebuyTime[0]);
		var rand2 = Math.floor((Math.random() * (botData.Settings.rebuyTime[1] - botData.Settings.rebuyTime[0])) + botData.Settings.rebuyTime[0]);
		if (typeof t.Tables[dt.Table] != "undefined") {
			var seat = t.Tables[dt.Table].Seat;
			if (t.Tables[dt.Table].Rebuys > 0) {
				t.Tables[dt.Table].Rebuys--;
				setTimeout(function() {
					t.sendMSG({
						"Response": "AddChips",
						"Table": dt.Table,
						"Type": "R",
						"Amount": "Min",
						"AutoRebuy": "No"
					});
					setTimeout(function() {
						t.sendMSG({
							"Response": "Button",
							"Table": dt.Table,
							"Type": "R",
							"Amount": 0,
							"Button": "Ready"
						});
					}, rand1);
				}, rand2);
			} else {
				bcore.WaitingLogout[t.Player.toLowerCase()] = "ReadyButton";
				if (typeof t.Tables[dt.Table] != "undefined") {
				t.Tables[dt.Table].sitOutAct("ReadyButton-noRebuy");
				
				}
			}
		}
	}

}
function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}
function getActionTime(obj){
	
var s = 1;
var e = 3;
if(obj.inPot>= 5 * obj.amounts.BB){
s = 2;
 e = 5;
}
if(obj.inPot>= 10 * obj.amounts.BB){
s = 3;
 e = 8;
}
var tt = randomIntFromInterval(s, e)
return tt
}
bot.prototype.ButtonAction = function(dt, tbs, callback) {
	var t = this;
	if (typeof t.Tables[dt.Table] != "undefined") {
		var seat = t.Tables[dt.Table].Seat; 
			DBG("ButtonAction S : "  + seat + " | P : " + t.Player + " ( "+ (typeof tbs.Players[seat] != "undefined"  ? tbs.Players[seat].Player : "undefined" ) + " ) | T : " + tbs.ID,{"type":"decide","Date":true,"player":t.Player});
			if(seat < 0 )
			{
				
				
				DBG.error({error:"undefined tbname",location:"bot:2509","Seat":seat,"dt":JSON.stringify(dt)});
					
			}else{
					
				if (tbs.Players[seat].Player.toLowerCase() == t.Player.toLowerCase()) 
				{
					var vt = {
						"Call": dt.Call,
						"Balance": t.Balance,
						"Pot": dt.Pot,
						"inPot": t.Tables[dt.Table].inPot.reduce(function(a, b){return a + b}),
						"MinRaise": dt.MinRaise,
						"MaxRaise": dt.MaxRaise,
						"Button2": dt.Button2,
						"seat": seat,
						"place": tbs.Players[seat].place,
						"Player": tbs.Players[seat].Player,
						"Chips": ( typeof tbs._players[seat] != "undefined" ?  tbs._players[seat].Chips : tbs.Players[seat].Chips) ,
						"Cards": ( typeof tbs._players[seat] != "undefined" ?  tbs._players[seat].Cards : tbs.Players[seat].Cards),
						"Helper": ( typeof tbs._players[seat] != "undefined" ?  tbs._players[seat].Helper : tbs.Players[seat].Helper),
						"total":tbs.total,
						"state": tbs.state
					};
					////////("vt",vt)
					DBG("PRE Decide " + t.Player + "(" + seat + ") ", {
					"type": "decide",
					"Date": true,
					"player":t.Player,
					"Color": "yellow"
					});
					/*DBG(JSON.stringify({"Cards": tbs.Players[seat].Cards,"Helper": tbs._players[seat].Helper,"state": tbs.state,"Table":dt.Table}), {
						"type":"decide",
						"player":t.Player,
						"Color": "yellow"
					});
					*/
					
					var  acttieming;
						
						clearTimeout(acttieming)
					if(tbs.showDone)
					{
						
						var  tieming;
						clearTimeout(tieming)
						  tieming = setTimeout(function() 
						{
							DBG("VT  "  + JSON.stringify(vt),{"type":"decide","player":t.Player,"Date":true});
							tbs.getDecide(vt, function(ret) {
								DBG("ret  "  + JSON.stringify(ret),{"type":"decide","player":t.Player,"Date":true});
								var tt = getActionTime(vt);
									 setTimeout(function() {
										 if(ret.Button == "Fold")
										 {
											if(typeof t.Tables[dt.Table] != "undefined" && t.Tables[dt.Table].sitingOut)
											{
												
												t.Tables[dt.Table].sitOutAct("ButtonAction-sitingOut");
												/*
												t.sendMSG({"Response":"SitOut","Table":dt.Table,"Type":"R","Box":"SitHand","Checked":"Yes"});
												t.sendMSG({"Response":"SitOut","Table":dt.Table,"Type":"R","Box":"SitBlind","Checked":"Yes"});
												
				*/
											}
											 
										 }
										t.sendMSG({
											"Response": "Button",
											"Response": "Button",
											"Table": dt.Table,
											"Type":  dt.Type,
											"Amount": ret.Amount,
											"Button": ( (tbs.state == 0 && ret.Button == "Bet" )? "Raise" : ret.Button)
										});
									}, (tt * 400)+300 );
								});
						}, 1000);
							
					}else{
						
						acttieming = setTimeout(()=>{
						
							t.ButtonAction(dt,tbs,callback);
						
						
						},1000);
						
					}
					
			
			
				} else {
					//////("-----------------------", tbs.Players[seat].Player, seat, t.Player, t.ID);
					
					DBG("erroring : " + tbs.Players[seat].Player + " " + seat + " " + t.Player + " " + t.ID, {
						"type": "decide",
						"Date": true,
						"player":t.Player,
						"Color": "red"
					});
					//erroring();
				}
			
				
			}
			
			
		} else {
		DBG("NO Decide - Sitting Out " + t.Player + "(" + seat + ") ", {
			"type": "decide",
			"Date": true,
			"player":t.Player,
			"Color": "red"
		});
	}
	
	
}

module.exports = bot;