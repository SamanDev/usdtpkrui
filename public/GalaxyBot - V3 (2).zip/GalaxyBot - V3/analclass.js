var handpoint = require("./handpoint");

function AnalClass() {}
AnalClass.analhand = function(cards) {
	types = {
		"c": 0,
		"d": 0,
		"s": 0,
		"h": 0
	};
	nums = [];
	hasAce = false;
	highjack = false;
	out = {};
	colwin = 1;
	for (var cc in cards) {
		var card = cards[cc];
		cnum = card.substring(0, 1);
		realnum = cnum;
		switch (cnum) {
			case "T":
				realnum = 10;
				break;
			case "J":
				realnum = 11;
				break;
			case "Q":
				realnum = 12;
				break;
			case "K":
				realnum = 13;
				break;
			case "A":
				realnum = 14;
				hasAce = true;
				break;
			default:
				realnum = parseInt(cnum);
				break;
		}
		ctype = card.substring(1);
		types[ctype]++;
		realnum = parseInt(realnum);
		nums.push(realnum);
		if (typeof out[realnum] == "undefined") {
			out[realnum] = 1;
		} else {
			out[realnum]++;
		}
	}
	handTitle = "high_card";
	checkstraight = true;
	outnum = [];
	for (var bb in out) {
		var ba = out[bb];
		outnum.push(ba);
	}
	outnum.sort();
	outstr = outnum.join("-");
	switch (outstr) {
		case "1-1-1-2":
			handTitle = "one_pair";
			mvtitle = AnalClass.pairtitle(out);
			colwin = 2;
			checkstraight = false;
			break;
		case "1-2-2":
			handTitle = "two_pair";
			mvtitle = AnalClass.twopairtitle(out);
			checkstraight = false;
			colwin = 3;
			break;
		case "1-1-3":
			handTitle = "three_of_a_kind";
			mvtitle = AnalClass.threekindtitle(out);
			checkstraight = false;
			colwin = 4;
			break;
		case "1-4":
			handTitle = "four_of_a_kind";
			checkstraight = false;
			mvtitle = AnalClass.fourtitle(out);
			colwin = 8;
			break;
		case "2-3":
			handTitle = "full_house";
			mvtitle = AnalClass.fulltitle(out);
			checkstraight = false;
			colwin = 7;
			break;
	}
	isflush = false;
	if (types['c'] == 5 || types['d'] == 5 || types['h'] == 5 || types['s'] == 5) {
		isflush = true;
		handTitle = "FLUSH";
		nums.sort(function(a, b) {
			return a - b
		});
		mvtitle = "a Flush, " + AnalClass.getname(nums[4]) + " high +" + AnalClass.getname(nums[3], "short") + AnalClass.getname(nums[2], "short") + AnalClass.getname(nums[1], "short") + AnalClass.getname(nums[0], "short");
		colwin = 6;
	}
	if (checkstraight) {
		isstraight = false;
		nums.sort(function(a, b) {
			return a - b
		});
		if ((nums[0] + 4) == nums[4]) {
			if (isflush) {
				handTitle = "STRAIGHT_FLUSH";
				mvtitle = AnalClass.str8title(nums, true);
				colwin = 9;
				if (nums[4] == 14) {
					handTitle = "ROYAL_FLUSH";
					colwin = 10;
					mvtitle = "a Royal Flush";
				}
			} else {
				handTitle = "STRAIGHT";
				colwin = 5;
				mvtitle = AnalClass.str8title(nums);
			}
			isstraight = true;
		} else {
			if (hasAce) {
				if (nums[3] == 5) {
					isstraight = true;
					if (isflush) {
						handTitle = "STRAIGHT_FLUSH";
						colwin = 9;
						mvtitle = AnalClass.str8title(nums, true);
					} else {
						handTitle = "STRAIGHT";
						colwin = 5;
						mvtitle = AnalClass.str8title(nums);
					}
				}
			}
		}
	}
	if (handTitle == "high_card") {
		nums.sort(function(a, b) {
			return a - b
		});
		mvtitle = "High Card " + AnalClass.getname(nums[4]) + " +" + AnalClass.getname(nums[3], "short") + AnalClass.getname(nums[2], "short") + AnalClass.getname(nums[1], "short") + AnalClass.getname(nums[0], "short");
	}
	return {
		'handTitle': handTitle,
		'colwin': colwin,
		'mvtitle': mvtitle
	};
}
AnalClass.getname = function(inte, type) {
	if (typeof type == "undefined") {
		type = "cardnames";
	}
	out = {
		"cardnames": {
			14: "Ace",
			13: "King",
			12: "Queen",
			11: "Jack",
			10: "Ten",
			9: "Nine",
			8: "Eight",
			7: "Seven",
			6: "Six",
			5: "Five",
			4: "Four",
			3: "Three",
			2: "Deuce"
		},
		"cardnameses": {
			14: "Aces",
			13: "Kings",
			12: "Queens",
			11: "Jacks",
			10: "Tens",
			9: "Nines",
			8: "Eights",
			7: "Sevens",
			6: "Sixes",
			5: "Fives",
			4: "Fours",
			3: "Threes",
			2: "Deuces"
		},
		"short": {
			14: "A",
			13: "K",
			12: "Q",
			11: "J",
			10: "T",
			9: "9",
			8: "8",
			7: "7",
			6: "6",
			5: "5",
			4: "4",
			3: "3",
			2: "2"
		}
	};
	return out[type][inte];
}
AnalClass.compareNumbers = function(a, b) {
	return a - b;
}
AnalClass.pairtitle = function(out) {
	end = [];
	finall = out;
	paired = false;
	mvtitle = "";
	for (k in out) {
		var v = out[k];
		if (v == 2) {
			delete finall[k];
			paired = AnalClass.getname(k, "cardnameses");
			keyss = Object.keys(finall);
			keyss.sort(AnalClass.compareNumbers);
			keyss.reverse();
			mvtitle = "a Pair of " + paired + " +" + AnalClass.getname(keyss[0], "short") + AnalClass.getname(keyss[1], "short") + AnalClass.getname(keyss[2], "short");
		}
	}
	return mvtitle;
}
AnalClass.twopairtitle = function($out) {
	end = {};
	finall = out;
	paired = [];
	for (var k in out) {
		var v = out[k];
		if (v == 2) {
			delete finall[k];
			paired.push(k);
		}
	}
	paired.sort(function(a, b) {
		return a - b
	});
	paired.reverse();
	finaled = Object.keys(finall);
	mvtitle = "Two Pair, " + AnalClass.getname(paired[0], "cardnameses") + " and " + AnalClass.getname(paired[1], "cardnameses") + " +" + AnalClass.getname(finaled[0], "short");
	return mvtitle;
}
AnalClass.threekindtitle = function(out) {
	end = {};
	finall = out;
	paired = false;
	mvtitle = "";
	for (var k in out) {
		k = parseInt(k);
		var v = out[k];
		if (v == 3) {
			delete finall[k];
			paired = AnalClass.getname(k, "cardnameses");
			keys = Object.keys(finall);
			keys.sort(function(a, b) {
				return a - b
			});
			keys.reverse();
			mvtitle = "Three of a Kind, " + paired + " +" + AnalClass.getname(keys[0], "short") + AnalClass.getname(keys[1], "short");
		}
	}
	return mvtitle;
}
AnalClass.str8title = function(nums, flush) {
	if (typeof flush == "undefined") {
		flush = false;
	}
	if (nums[0] == 2) {
		if (nums[4] == 6) {
			mvtitle = "a Straight" + (flush ? " Flush" : "") + ", " + AnalClass.getname(nums[0]) + " to " + AnalClass.getname(nums[4]);
		} else {
			if (nums[4] == 14) {
				mvtitle = "a Straight, Ace to Five";
			}
		}
	} else {
		mvtitle = "a Straight" + (flush ? " Flush" : "") + ", " + AnalClass.getname(nums[0]) + " to " + AnalClass.getname(nums[4]);
	}
	return mvtitle;
}
AnalClass.fulltitle = function(out) {
	end = [];
	finall = out;
	paired = false;
	fulled = "";
	house = "";
	mvtitle = "a Full House, ";
	for (var k in out) {
		v = out[k];
		if (v == 3) {
			delete finall[k];
			house = AnalClass.getname(k, "cardnameses");
		} else {
			if (v == 2) {
				fulled = AnalClass.getname(k, "cardnameses");
			}
		}
	}
	mvtitle += house + " full of " + fulled;
	return mvtitle;
}
AnalClass.fourtitle = function(out) {
	end = [];
	finall = out;
	paired = {};
	mvtitle = "";
	for (var k in out) {
		var v = out[k];
		if (v == 4) {
			delete finall[k];
			keys = Object.keys(finall);
			mvtitle = "Four of a Kind, " + AnalClass.getname(k, "cardnameses") + " +" + AnalClass.getname(keys[0], "short");
		}
	}
	return mvtitle;
}
AnalClass.getpreflop = function(usercards, gametype) {
	
	switch (gametype) {
		case "holdem":
			var reti = AnalClass.getpreflopanal(usercards);
		
			break;
		case "omaha":
		case "omaha5":
			var reti = AnalClass.getpreflopOmaha(usercards, gametype);
			break;
	}
	var point = handpoint.preflopPoint(reti.cards);
	
////console.log("retiiiiiii",reti,point);
	var retu = {
		"hand": usercards,
		"helper": reti.helper,
		"handtype": "preflop",
		"point": point.point,
		"handpoint": point.handpoint,
		"mask": "00"
	};
	
	return retu;
}
AnalClass.getpreflopOmaha = function(usercards, gametype) {
	var out = {};
	var types = {
		"omaha": [
			[0, 1],
			[0, 2],
			[0, 3],
			[1, 2],
			[1, 3],
			[2, 3]
		],
		"omaha5": [
			[0, 1],
			[0, 2],
			[0, 3],
			[0, 4],
			[1, 2],
			[1, 3],
			[1, 4],
			[2, 3],
			[2, 4],
			[3, 4]
		]
	};
	var typ = types[gametype];
	for (i = 0; i < typ.length; i++) {
		var thand = [usercards[typ[i][0]], usercards[typ[i][1]]];
		var reti = AnalClass.getpreflopanal(thand);
		
		out[reti.point] = reti;
	}
	var kees = Object.keys(out);
	var ke = kees[0];
	kees.sort(function(a, b) {
		return a - b;
	});
	var ret = out[parseInt(ke)];
	return ret;
}
AnalClass.getpreflopanal = function(usercards) {
	suited = "";
	var pt = 52;
	if (usercards[0][0] == usercards[1][0]) {
		tit = "a Pair of ";
		var sh = AnalClass.getnum(usercards[0][0]);
		tit += AnalClass.getname(sh, "cardnameses");
		pt = 14 - sh;
	} else {
		tit = "High Card ";
		if (AnalClass.getnum(usercards[0][0]) > AnalClass.getnum(usercards[1][0])) {
			var sh = AnalClass.getnum(usercards[0][0])
		} else {
			var sh = AnalClass.getnum(usercards[1][0]);
		}
		tit += AnalClass.getname(sh);
		pt = 13 + (14 - sh);
	}
	var ret =  {
		"point": pt,
		"helper": tit,
		"cards" : usercards
	};

	return ret;
}
AnalClass.getnum = function(inn) {
	card = inn;
	switch (inn) {
		case "T":
			card = 10;
			break;
		case "J":
			card = 11;
			break;
		case "Q":
			card = 12;
			break;
		case "K":
			card = 13;
			break;
		case "A":
			card = 14;
			break;
	}
	return parseInt(card);
}

AnalClass.cardtonum = function(cn) {
	var an = AnalClass.getnum(cn[0]);
	switch(cn[1])
	{
			
		case "c":
			kh = 0;
			break;
		case "d":
			kh = 1;
			break;
		case "h":
			kh = 2;
			break;
		case "s":
			kh = 3;
			break;
	}
	
	an -= 2;
	
	
	var ni  = (an * 4) + kh ;
	return (ni + 1);
}
AnalClass.numtocard = function(cn) {
	cn -= 1;
	var bet = cn % 4;
	var rem = cn - bet;
	var n = (rem / 4) + 2;
	var inte = n;
	var kh = "";
	switch (bet) {
		case 0:
			kh = "c";
			break;
		case 1:
			kh = "d";
			break;
		case 2:
			kh = "h";
			break;
		case 3:
			kh = "s";
			break;
	}
	switch (n) {
		case 10:
			inte = "T";
			break;
		case 11:
			inte = "J";
			break;
		case 12:
			inte = "Q";
			break;
		case 13:
			inte = "K";
			break;
		case 14:
			inte = "A";
			break;
	}
	var et = inte + kh;
	return et;
}
AnalClass.mixHoldemOLD = function(usercards, flop) {
	var odds = {
		7: ["12345", "12346", "12347", "12356", "12357", "12367", "12456", "12457", "12467", "12567", "13456", "13457", "13467", "13567", "14567", "23456", "23457", "23467", "23567", "24567", "34567"],
		6: ["12345", "12346", "12356", "12456", "13456", "23456"],
		5: ["12345"],
		2: ["12"]
	};
	merged = usercards.concat(flop);
	var arr = odds[merged.length];
	//console.log(merged,arr);
	if (typeof arr == "undefined") {}
	var out = [];
	for (i = 0; i < arr.length; i++) {
		var r = arr[i];
		out.push([
			[merged[(parseInt(r[0]) - 1)], merged[(parseInt(r[1]) - 1)]],
			[merged[(parseInt(r[2]) - 1)], merged[(parseInt(r[3]) - 1)], merged[(parseInt(r[4]) - 1)]]
		]);
	}
	return out;
}
AnalClass.mixHoldem = function(usercards, flop) {
	usercards = [usercards[0],usercards[1]];
	var odds = {
		7: ["12345", "12346", "12347", "12356", "12357", "12367", "12456", "12457", "12467", "12567", "13456", "13457", "13467", "13567", "14567", "23456", "23457", "23467", "23567", "24567", "34567"],
		6: ["12345", "12346", "12356", "12456", "13456", "23456"],
		5: ["12345"],
		2: ["12"]
	};
	var masks = {
		7: ["1110011", "1101011", "1100111", "1011011", "1010111", "1001111", "0111011", "0110111", "0101111", "0011111", "1111010", "1110110", "1101110", "1011110", "0111110", "1111001", "1110101", "1101101", "1011101", "0111101", "1111100"],
		6: ["1110011", "1101011", "1011011", "0111011", "1110110", "1111001"],
		5: ["1110011"],
		2: ["0000011"]
	};
	////console.log("merged",usercards,flop);
	merged = usercards.concat(flop);
	////console.log("n",merged);
	var arr = odds[merged.length];
	////console.log(arr);
	if (typeof arr == "undefined") {}
	var out = [];
	for (i = 0; i < arr.length; i++) {
		var r = arr[i];
		var thand = [
			[merged[(parseInt(r[0]) - 1)], merged[(parseInt(r[1]) - 1)]],
			[merged[(parseInt(r[2]) - 1)], merged[(parseInt(r[3]) - 1)], merged[(parseInt(r[4]) - 1)]]
		];
		////console.log(thand);
		out.push({
			"hand": thand,
			"mask": masks[merged.length][i],
			"r": r
		});
	}
	////console.log(out);
	return out;
}
AnalClass.mixOmaha = function(usercards, flop) {
	hands = [];
	game = {
		2: [
			[0, 1]
		],
		4: [
			[0, 1],
			[0, 2],
			[0, 3],
			[1, 2],
			[1, 3],
			[2, 3]
		],
		5: [
			[0, 1],
			[0, 2],
			[0, 3],
			[0, 4],
			[1, 2],
			[1, 3],
			[1, 4],
			[2, 3],
			[2, 4],
			[3, 4]
		]
	};
	masks = {
		2: [
			[0, 1]
		],
		4: ["1100", "1010", "1001", "0110", "0101", "0011"],
		5: ["11000", "10100", "10010", "10001", "01100", "01010", "01001", "00110", "00101", "00011"]
	};
	co = usercards.length;
	selected = game[co];
	for (var vs in selected) {
		var selc = selected[vs];
		var usd = [usercards[selc[0]], usercards[selc[1]]];
		var maskk = masks[co][vs];
		var r = co + " - " + vs;
		switch (flop.length) {
			case 3:
				hands.push({
					"hand": [usd, flop],
					"mask": "11100" + maskk,
					"r": r
				});
				break;
			case 4:
				hands.push({
					"hand": [usd, [flop[0], flop[1], flop[2]]],
					"mask": "11100" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[1], flop[3]]],
					"mask": "11010" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[2], flop[3]]],
					"mask": "11100" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[1], flop[2], flop[3]]],
					"mask": "11100" + maskk,
					"r": r
				});
				break;
			case 5:
				hands.push({
					"hand": [usd, [flop[0], flop[1], flop[2]]],
					"mask": "11100" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[1], flop[3]]],
					"mask": "11010" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[1], flop[4]]],
					"mask": "11001" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[2], flop[3]]],
					"mask": "10110" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[2], flop[4]]],
					"mask": "10101" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[0], flop[3], flop[4]]],
					"mask": "10011" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[1], flop[2], flop[3]]],
					"mask": "01110" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[1], flop[2], flop[4]]],
					"mask": "01101" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[1], flop[3], flop[4]]],
					"mask": "01011" + maskk,
					"r": r
				});
				hands.push({
					"hand": [usd, [flop[2], flop[3], flop[4]]],
					"mask": "00111" + maskk,
					"r": r
				});
				break;
		}
	}
	return hands;
}
AnalClass.mixOmaha_old = function(usercards, flop) {
	hands = [];
	game = {
		2: [
			[0, 1]
		],
		4: [
			[0, 1],
			[0, 2],
			[0, 3],
			[1, 2],
			[1, 3],
			[2, 3]
		],
		5: [
			[0, 1],
			[0, 2],
			[0, 3],
			[0, 4],
			[1, 2],
			[1, 3],
			[1, 4],
			[2, 3],
			[2, 4],
			[3, 4]
		]
	};
	masks = {
		2: [
			[0, 1]
		],
		4: [
			[1100],
			[1010],
			[1001],
			[0110],
			[0101],
			[0011]
		],
		5: [
			[11000],
			[10100],
			[10010],
			[10001],
			[01100],
			[01010],
			[01001],
			[00110],
			[00101],
			[00011]
		]
	};
	co = usercards.length;
	selected = game[co];
	for (var vs in selected) {
		var selc = selected[vs];
		var usd = [usercards[selc[0]], usercards[selc[1]]];
		var maskk = masks[co][vs];
		switch (flop.length) {
			case 3:
				hands.push([usd, flop]);
				break;
			case 4:
				out.push({
					"hand": thand,
					"mask": masks[merged.length][i],
					"r": r
				});
				hands.push([usd, [flop[0], flop[1], flop[2]]]);
				hands.push([usd, [flop[0], flop[1], flop[3]]]);
				hands.push([usd, [flop[0], flop[2], flop[3]]]);
				hands.push([usd, [flop[1], flop[2], flop[3]]]);
				break;
			case 5:
				hands.push([usd, [flop[0], flop[1], flop[2]]]);
				hands.push([usd, [flop[0], flop[1], flop[3]]]);
				hands.push([usd, [flop[0], flop[1], flop[4]]]);
				hands.push([usd, [flop[0], flop[2], flop[3]]]);
				hands.push([usd, [flop[0], flop[2], flop[4]]]);
				hands.push([usd, [flop[0], flop[3], flop[4]]]);
				hands.push([usd, [flop[1], flop[2], flop[3]]]);
				hands.push([usd, [flop[1], flop[2], flop[4]]]);
				hands.push([usd, [flop[1], flop[3], flop[4]]]);
				hands.push([usd, [flop[2], flop[3], flop[4]]]);
				break;
		}
	}
	return hands;
}
AnalClass.getfinalhand = function(allusercards, allflopcards, gametype,callback) {
	usercards = [];
	//console.log("getfinalhand",allusercards);
	for (iee = 0; iee < allusercards.length; iee++) {
		if (allusercards[iee] != 0) {
			usercards.push(AnalClass.numtocard(allusercards[iee]));
		}
	}
	//console.log("getfinalhand 2",usercards);
	flopcards = [];
	for (iew = 0; iew < allflopcards.length; iew++) {
		if (typeof allflopcards[iew] != "undefined" && allflopcards[iew] != 0) {
			flopcards.push(AnalClass.numtocard(allflopcards[iew]));
		}
	}
	if(allflopcards.length == 4)
	{
	}
	
	if (flopcards.length == 0) {
		var analpre = AnalClass.getpreflop(usercards, gametype);
		callback(analpre);
		return analpre;
	}
	
	switch (gametype) {
		case "holdem":
			var mixed = AnalClass.mixHoldem(usercards, flopcards);
			break;
		case "omaha":
		case "omaha5":
			var mixed = AnalClass.mixOmaha(usercards, flopcards);
			break;
	}
	
	var tophand = AnalClass.gettophand(mixed);
	callback(tophand);
//////console.log("tophand",tophand);
	//return tophand;
}
AnalClass.gettophandOLD = function(hands) {
	outa = {};
	for (var ee in hands) {
		h = hands[ee];
		merged = h[0].concat(h[1]);
		res = AnalClass.analhand(merged);
		var handstr = handpoint.getCardsString(res['mvtitle']);
		var point = handpoint.gethandpoint(handstr.type, handstr.cards);
		outa[parseInt(point['handpoint'])] = {
			"hand": h,
			"helper": res['mvtitle'],
			"handtype": res['handTitle'],
			"point": point.point,
			"handpoint": point.point,
			"mask": "0110111"
		};
	}
	var kss = Object.keys(outa);
	kss.sort(AnalClass.compareNumbers);
	kss.reverse();
	var ret = outa[kss[0]];
	return ret;
}
AnalClass.gettophand = function(hands) {
	outa = [];
	for (var ee in hands) {
		h = hands[ee].hand;
		merged = h[0].concat(h[1]);

		res = AnalClass.analhand(merged);
		var handstr = handpoint.getCardsString(res['mvtitle']);
		var point = handpoint.gethandpoint(handstr.type, handstr.cards);
		outa.push({
			"hand": h,
			"helper": res['mvtitle'],
			"handtype": res['handTitle'],
			"colwin":res['colwin'],
			"point": point.point,
			"handpoint": res['colwin'],
			"mask": hands[ee].mask,
			"r": hands[ee].r
		});
	}
	
	outa.sort(function compareByAge(a, b) {return b.point - a.point;});
	
	var ret = outa[0];

	return ret;
}



module.exports = AnalClass;