function actions() {}

actions.handTen = function (callback, obj, showAll, AllBots, OtherBlof) {
    if (obj.state < 3) {
        actions.check(callback, obj, showAll, AllBots, OtherBlof);
        return false;
    } else {
        if (obj.Button2 == "Check") {
            actions.raise(obj.Chips, callback, obj, showAll, AllBots, OtherBlof);
            return false;
        } else if (obj.Button2 == "Call") {
            actions.raise(obj.Call * 2, callback, obj, showAll, AllBots, OtherBlof);
            return false;
        }
    }
};
actions.getLog = function (obj, action, showAll, AllBots, OtherBlof) {
    //console.log(showAll, AllBots, OtherBlof + " " + obj.handnumber + " " + obj.Player + " ---  " + obj.state + " " + obj.Helper + " " + obj.Button2 + " " + action, obj.convertedCards, obj.flopCards);
    if (obj.state == 0) {
        //console.log(JSON.stringify(obj));
    }
    if (obj.state > 0) {
        if (obj.Button2 == "Call") {
            //console.log("showAll", showAll, "AllBots", AllBots, "CallAmunt:", obj.Call, "inpot:", obj.inPot, "pot:", obj.Pot, obj.convertedCards, obj.flopCards, OtherBlof);
        }
    }
};
actions.call = function (callback, obj, showAll, AllBots, OtherBlof) {
    var rest = obj.Chips;

    var callAm = obj.Call;
    if (rest - callAm < callAm && obj.state <= 2) {
        if (obj.Pot == 0) {
            actions.getLog(obj, "Call-Allin", showAll, AllBots, OtherBlof);
            callback({
                Button: "Call",
                Amount: 0,
            });
            return false;
        } else {
            actions.getLog(obj, "RaiseCall-myAllin", showAll, AllBots, OtherBlof);
            callback({
                Button: "Bet",
                Amount: parseInt(rest),
            });
            return false;
        }
    } else {
        actions.getLog(obj, "Call", showAll, AllBots, OtherBlof);

        callback({
            Button: "Call",
            Amount: 0,
        });
        return false;
    }
};
actions.fold = function (callback, obj, showAll, AllBots, OtherBlof) {
    var rest = obj.Chips;
    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
    if (obj.state < 6 && (rest < total / 30 || callAm < total / 25)) {
        actions.getLog(obj, "FoldtoCall", showAll, AllBots, OtherBlof);
        callback({
            Button: "Call",
            Amount: 0,
        });
        return false;
    } else {
        actions.getLog(obj, "Fold", showAll, AllBots, OtherBlof);
        callback({
            Button: "Fold",
            Amount: 0,
        });
        return false;
    }
};
actions.raise = function (amount, callback, obj, showAll, AllBots, OtherBlof) {
    if (obj.Pot == 0 && obj.Button2 == "Call") {
        actions.getLog(obj, "RaiseCall-Allin", showAll, AllBots, OtherBlof);
        callback({
            Button: "Call",
            Amount: 0,
        });
        return false;
    } else {
        if (OtherBlof > 0 && obj.state < 3 && obj.state > 10 && showAll && !AllBots && obj.Button2 == "Check") {
            actions.getLog(obj, "RaiseCheck-Sleep", showAll, AllBots, OtherBlof);
            callback({
                Button: "Check",
                Amount: 0,
            });
            return false;
        } else {
            actions.getLog(obj, "Raise", showAll, AllBots, OtherBlof);
            var rest = obj.Chips;

            var amount2 = rest - amount < amount ? rest : amount;
            callback({
                Button: "Bet",
                Amount: parseInt(amount2),
            });

            return false;
        }
    }
};
actions.check = function (callback, obj, showAll, AllBots, OtherBlof) {
    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    if (rest < total / 4 && obj.state < 3) {
        actions.getLog(obj, "CheckRaise-lowResr", showAll, AllBots, OtherBlof);
        callback({
            Button: "Bet",
            Amount: parseInt(rest),
        });

        return false;
    } else {
        actions.getLog(obj, "Check", showAll, AllBots, OtherBlof);
        callback({
            Button: "Check",
            Amount: 0,
        });
        return false;
    }
};
module.exports = actions;
