var config = function(){}



config.Port = 1408; // node socket port ( this script )
config.filePort = 2052; 
config.packetPort = 2082;
config.Version =  7.19;
config.SSL = false;
config.logsDir = "./logs/";
config.mavensUrl='localhost';
//config.dbhost = 'localhost';
//config.dbuser= 'root';
//config.dbpassword= 'SEcurity1721?!@';
//config.dbname= 'pk888_botlogs';
config.APIPass =  "nEw@!@pAsStOkeN2024?@";
config.APIKey = "Maven2024SpringBoot";
config.APIURL = 'http'  + (config.SSL ? "s" : "")  + '://' + config.mavensUrl + ':' + config.filePort  + '/';
config.adminAcc = "manager";



// MAIN SETTINGS
config.showapi = 'http://localhost:8089/botHandApi?cmd=getHand&table=';
config.monitor = true;
config.getCrash = false;
config.showdelay = 3;//seconds
config.showamount = 100;
config.flopRequest=true;
config.getDbLoger =false;

// BOT SETTINGS
config.bot = {
	
			"rebuyDecide" : 90,//precent
			"rebuyTime" : [1,1], //seconds
			"waitToSeat" : [1,4], //seconds
			"waitToLogout" : [10,40], //seconds
			"waitToLeave" :  [4,6], //seconds
			"sitoutLeft" : 10,//precent
			"startButton" : 80,//precent
			"checkTime" : 10, //minutes
			"durationTime" : 30 //seconds
}

// DEBUG SETTINGS
config.debug = {

	"console" : true,
	"system" : true,
	"decide" : false,
	"allhand" : false,
	"sethand" : false,
	"botlogin" : false,
	"botseat" : false,
	"botstatus" : false,
	"tables" : false,
	"tables2" : false,
	"update" : false,
	"buttons" : false,
	"details" : false,
	"updatetable" : false,
	"response" : false,
	"commands" : false,
	"file" : false
// "file" : "C:/Users/Public/Documents/logs.txt"


}


module.exports = config;