function decide() {}
function utils() {}
function actions() {}
actions.handTen = function (obj, callback) {
    if (obj.state < 3) {
        actions.check(callback, obj);
        return false;
    } else {
        if (obj.Button2 == "Check") {
            actions.raise(obj.inPot, callback, obj);
            return false;
        } else if (obj.Button2 == "Call") {
            if (obj.Pot == 0) {
                actions.call(callback, obj);
                return false;
            }

            actions.raise(obj.Call * 2, callback, obj);
            return false;
        }
    }
};
actions.call = function (callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof) {
    if (obj.state > 0) {
        console.log("showAll", showAll, "AllBots", AllBots, "Call", obj.Call, "inpot:", obj.inPot, "pot:", obj.Pot, obj.Player, obj.Helper, obj.convertedCards, obj.flopCards, PlayeroDDs, OtherBlof, obj);
    }
    callback({
        Button: "Call",
        Amount: 0,
    });
};
actions.fold = function (callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof) {
    if (obj.state > 0) {
        console.log("showAll", showAll, "AllBots", AllBots, "fold", obj.Button2, "call:", obj.Call, "inpot:", obj.inPot, "pot:", obj.Pot, obj.Player, obj.Helper, obj.convertedCards, obj.flopCards, PlayeroDDs, OtherBlof, obj);
    }
    callback({
        Button: "Fold",
        Amount: 0,
    });
};
actions.raise = function (amount, callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof) {
    if (obj.state > 0) {
        console.log("showAll", showAll, "AllBots", AllBots, "BetAm", amount, obj.Button2, "call:", obj.Call, "inpot:", obj.inPot, "pot:", obj.Pot, obj.Button2, obj.Call, obj.Player, obj.Helper, obj.convertedCards, obj.flopCards, PlayeroDDs, OtherBlof, obj);
    }
    callback({
        Button: "Bet",
        Amount: parseInt(amount),
    });
};
actions.check = function (callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof) {
    if (obj.state > 0) {
        console.log("showAll", showAll, "AllBots", AllBots, "check", obj.Button2, "call:", obj.Call, "inpot:", obj.inPot, "pot:", obj.Pot, obj.Button2, obj.Call, obj.Player, obj.Helper, obj.convertedCards, obj.flopCards, PlayeroDDs, OtherBlof, obj);
    }
    callback({
        Button: "Check",
        Amount: 0,
    });
};

utils.removeItemAll = function (arr, value) {
    var i = 0;
    while (i < arr.length) {
        if (arr[i] === value) {
            arr.splice(i, 1);
        } else {
            ++i;
        }
    }
    return arr;
};

utils.groupBy = function (xy, f) {
    var x = utils.removeItemAll(xy, "15c");
    x = utils.removeItemAll(x, "1");
    return x.reduce(function (a, b, i) {
        var _a;

        return (a[(_a = f(b, i, x))] || (a[_a] = [])).push(b), a;
    }, {});
};
utils.compareNumbers = function (a, b) {
    return b - a;
};
utils.getKeyNum = function (cn) {
    var inte = 2;
    switch (cn) {
        case "Aces":
            inte = 14;
            break;
        case "Kings":
            inte = 13;
            break;
        case "Queens":
            inte = 12;
            break;
        case "Jacks":
            inte = 11;
            break;
        case "Tens":
            inte = 10;
            break;
        case "Nines":
            inte = 9;
            break;
        case "Eights":
            inte = 8;
            break;
        case "Sevens":
            inte = 7;
            break;
        case "Sixes":
            inte = 6;
            break;
        case "Fives":
            inte = 5;
            break;

        case "Fours":
            inte = 4;
            break;
        case "Threes":
            inte = 3;
            break;
        case "Ace":
            inte = 14;
            break;
        case "King":
            inte = 13;
            break;
        case "Queen":
            inte = 12;
            break;
        case "Jack":
            inte = 11;
            break;
        case "Ten":
            inte = 10;
            break;
        case "Nine":
            inte = 9;
            break;
        case "Eight":
            inte = 8;
            break;
        case "Seven":
            inte = 7;
            break;
        case "Six":
            inte = 6;
            break;
        case "Five":
            inte = 5;
            break;

        case "Four":
            inte = 4;
            break;
        case "Three":
            inte = 3;
            break;
    }

    return inte;
};
utils.randomIntFromInterval = function (min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
};
utils.getHigh = function (data) {
    var hand = data;
    try {
        hand = data.toString();
    } catch (error) {}

    if (hand.indexOf("A") > -1 || hand == "14" || hand.indexOf("14") > -1) return 14;
    if (hand.indexOf("K") > -1 || hand == "13" || hand.indexOf("13") > -1) return 13;
    if (hand.indexOf("Q") > -1 || hand == "12" || hand.indexOf("12") > -1) return 12;
    if (hand.indexOf("J") > -1 || hand == "11" || hand.indexOf("11") > -1) return 11;
    if (hand.indexOf("T") > -1 || hand == "10" || hand.indexOf("10") > -1) return 10;
    if (hand.indexOf("9") > -1) return 9;
    if (hand.indexOf("8") > -1) return 8;
    if (hand.indexOf("7") > -1) return 7;
    if (hand.indexOf("6") > -1) return 6;
    if (hand.indexOf("5") > -1) return 5;
    if (hand.indexOf("4") > -1) return 4;
    if (hand.indexOf("3") > -1) return 3;
    if (hand.indexOf("2") > -1) return 2;
    if (hand.indexOf("1") > -1) return 1;
    if (hand.indexOf("0") > -1) return 0;

    return utils.getKeyNum(hand);
};
utils.getNumofCard = function (cn) {
    var inte = cn;
    switch (cn) {
        case 10:
            inte = "T";
            break;
        case 11:
            inte = "J";
            break;
        case 12:
            inte = "Q";
            break;
        case 13:
            inte = "K";
            break;
        case 14:
            inte = "A";
            break;
    }

    return inte + "";
};
utils.getNust = function (mode, cards, flop) {
    var highofcard = utils.getHigh(cards);
    if (mode == "flush") {
        var nust = 14 - highofcard;

        for (var i = highofcard + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) > -1) {
                nust = nust - 1;
            }
        }
        return 14 - nust;
    }
    if (mode == "set") {
        var nust = highofcard;

        for (var i = nust + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) == -1) {
                nust = nust + 1;
            }
        }
        return nust;
    }
    if (mode == "three") {
        var nust = highofcard;

        return nust;
    }
    if (mode == "full") {
        var nust = 14;

        for (var i = highofcard + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) > -1) {
                nust = nust - 1;
            }
        }
        return nust;
    }
};

utils.checkBankStat = function (obj) {
    var rest = obj.Chips;
    var winner = rest > obj.amounts.BB * 60 ? true : false;
    var looser = rest < obj.amounts.BB * 15 ? true : false;
    if (winner) {
        return 1;
    }
    if (looser) {
        return -1;
    }
    return 0;
};
utils.CleanOddsPerPlayer = function (obj, Player, Hand, max) {
    var defmax = max ? max : 15;
    var TotalHigh = 0;
    var noOut = 0;
    var DHigh = 0;
    var handPer = utils.groupBy(Hand, (v) => v[0]);
    var perCount = 0;
    //console.log(defmax)

    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length == 2 && utils.getHigh(prop) < defmax) {
                perCount = utils.getHigh(prop);
            }
        }
    }
    if (perCount) {
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop)) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips > 0) {
                    var uOdds = utils.groupBy(obj.pls[prop].Cards, (v) => v[0]);

                    for (var propplayer in uOdds) {
                        if (uOdds.hasOwnProperty(propplayer)) {
                            var propHigh = utils.getHigh(propplayer);
                            if (propHigh == perCount) {
                                noOut = noOut + uOdds[propplayer].length;
                            }
                            if (propHigh > perCount && uOdds[propplayer].length == 1) {
                                //console.log(propplayer)
                                TotalHigh = TotalHigh + uOdds[propplayer].length;
                            }
                        }
                    }
                }
            }
        }
    }
    if (noOut > 0) {
        return utils.CleanOddsPerPlayer(obj, Player, Hand, perCount);
    }

    return [perCount, noOut, TotalHigh];
};
utils.CleanOddsPer = function (obj) {
    var DHigh = 0;
    var PPer = utils.CleanOddsPerPlayer(obj, obj.Player, obj.convertedCards);

    var perCount = PPer[0];
    var noOut = PPer[1];
    var TotalHigh = PPer[2];
    if (perCount) {
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop)) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Bot == false && obj.pls[prop].Cards[0].toString().indexOf("15") == -1 && obj.pls[prop].Chips > 0) {
                    var uOdds = utils.CleanOddsPerPlayer(obj, obj.pls[prop].Player, obj.pls[prop].Cards);
                    if (uOdds[0]) {
                        if (DHigh < utils.getHigh(uOdds[0]) && uOdds[1] <= noOut) {
                            DHigh = utils.getHigh(uOdds[0]);
                        }
                        //console.log(uOdds)
                    }
                }
            }
        }
    }
    perCount = perCount < DHigh ? 0 : perCount;
    noOut = perCount > 0 ? noOut : 0;
    //console.log("DHigh",DHigh,perCount)
    //console.log("uOdds",PlayeroDDsNew,PlayeroDDs.length)

    return [perCount, noOut, TotalHigh];
};

utils.CleanOddsFlsuh = function (obj) {
    var TotalHigh = 0;
    var SHigh = 0;
    var CHigh = 0;
    var HHigh = 0;
    var DHigh = 0;
    var PlayeroDDs = utils.getFlushOdds(obj, obj.convertedCards);

    var PlayeroDDsNew = [];
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = utils.getFlushOdds(obj, obj.pls[prop].Cards);
                // console.log(uOdds)
                for (var j = 0; j < uOdds.length; j++) {
                    if (uOdds[j].cartName == "c") {
                        if (CHigh < uOdds[j].high) {
                            CHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "d") {
                        if (DHigh < uOdds[j].high) {
                            DHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "s") {
                        if (SHigh < uOdds[j].high) {
                            SHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "h") {
                        if (HHigh < uOdds[j].high) {
                            HHigh = uOdds[j].high;
                        }
                    }
                }
            }
        }
    }

    for (var j = 0; j < PlayeroDDs.length; j++) {
        if (PlayeroDDs[j].cartName == "c") {
            if (CHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "d") {
            if (DHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "s") {
            if (SHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "h") {
            if (HHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
    }

    for (var j = 0; j < PlayeroDDsNew.length; j++) {
        TotalHigh = TotalHigh + PlayeroDDsNew[j].high;
    }
    //console.log("DHigh",DHigh)
    //console.log("uOdds",PlayeroDDsNew,PlayeroDDs.length)

    return PlayeroDDsNew;
};
utils.getFlushOddsOut = function (obj, name) {
    var noOut = 0;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = utils.groupBy(obj.pls[prop].Cards, (v) => v[1]);

                for (var propplayer in uOdds) {
                    if (uOdds.hasOwnProperty(propplayer)) {
                        if (propplayer == name) {
                            noOut = noOut + uOdds[propplayer].length;
                        }
                    }
                }
            }
        }
    }
    return noOut;
};
utils.getFlushOdds = function (obj, cards) {
    var flushOdds = utils.groupBy(cards, (v) => v[1]);
    var flush = [];
    var cartFlush = [];

    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 2) {
                cartFlush.push({
                    cartName: prop,
                    Card: flushOdds[prop],
                    high: utils.getHigh(flushOdds[prop]),
                    out: utils.getFlushOddsOut(obj, prop),
                });
            }
        }
    }
    //console.log("cartFlush",cartFlush)
    if (cartFlush.length == 0) {
        return [];
    }
    return cartFlush;
};
utils.getThreeple = function (data) {
    var cards = data;
    var flushOdds = utils.groupBy(cards, (v) => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 3) {
                finalOdds = utils.getHigh(flushOdds[prop]);
            }
        }
    }
    return finalOdds;
};
utils.getDouble = function (data, sum) {
    var cards = data;
    var flushOdds = utils.groupBy(cards, (v) => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length == 2) {
                if (sum) {
                    finalOdds += utils.getHigh(flushOdds[prop]);
                } else {
                    finalOdds = utils.getHigh(flushOdds[prop]);
                }
            }
        }
    }
    return finalOdds;
};
utils.checkHaveFlushOdds = function (flop) {
    var flopOdds = utils.groupBy(flop, (v) => v[1]);
    var isNuts = false;

    //console.log("flopOdds",flopOdds)
    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= 3) {
                isNuts = true;
            }
        }
    }

    return isNuts;
};
utils.SortStraight = function (data) {
    var ranks = [];
    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        var high = utils.getHigh(data[i]);
        if (!ranks.includes(high)) {
            ranks.push(high);
        }

        //Do something
    }

    ranks.sort(utils.compareNumbers);
    //console.log(ranks)
    return ranks;
};
utils.checkHaveStrOdds = function (flop) {
    var isNuts = false;

    var cardsHighFlop = utils.SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1);
    }
    //console.log(cardsHighFlop)
    for (var i = 0; i < cardsHighFlop.length - 2; i++) {
        if (cardsHighFlop[i] - 4 <= cardsHighFlop[i + 2]) {
            isNuts = true;
        }
    }

    return isNuts;
};
utils.getRaiseAmount = function (obj, callback, RaiseAmount, precentage) {
    if (obj.Pot == 0) {
        actions.call(callback, obj);
        return false;
    }

    actions.raise(RaiseAmount, callback, obj);
    return false;
};
utils.getCallAmount = function (obj, callback, precentage, callAm, inPot, rest) {
    if (obj.Pot == 0) {
        actions.call(callback, obj);
        return false;
    }
    if (rest - callAm <= obj.amounts.BB * 5 && rest > callAm) {
        actions.raise(rest, callback, obj);
        return false;
    }
    actions.call(callback, obj);
    return false;
};
utils.checkShow = function (ob) {
    var showAll = true;
    var obj = ob;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Bot == false) {
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                //console.log(allInPot);
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1];
                    for (var i = 2; i < 4; i++) {
                        if (obj.state >= i) {
                            allInPot = allInPot + obj.pls[prop].inPot[i];
                        }
                    }
                }

                if (allInPot >= obj.inPot) {
                    if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                        showAll = false;
                    }
                }
            }
        }
    }

    return showAll;
};
utils.checkAllBots = function (ob) {
    var showAll = true;
    var obj = ob;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Bot == false) {
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1];
                    for (var i = 2; i < 4; i++) {
                        if (obj.state >= i) {
                            allInPot = allInPot + obj.pls[prop].inPot[i];
                        }
                    }
                }
                if (allInPot >= obj.inPot) {
                    showAll = false;
                }
            }
        }
    }

    return showAll;
};
utils.checkInpot = function (ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = obj.state;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Player == obj.Player && obj.pls[prop].inPot[iPoto] > 0) {
                showAll = false;
            }
        }
    }
    return showAll;
};
utils.checkStatus = function (ob) {
    var obj = ob;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Bot == false) {
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1];
                    for (var i = 2; i < 4; i++) {
                        if (obj.state >= i) {
                            allInPot = allInPot + obj.pls[prop].inPot[i];
                        }
                    }
                }
                if (allInPot >= obj.inPot) {
                    if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                        console.log(obj.pls[prop]);
                        console.log(JSON.stringify(obj));
                    }
                }
            }
        }
    }
};
utils.checkPlayerNumber = function (obj) {
    var ob = 0;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0) {
                ob = ob + 1;
            }
        }
    }
    return ob;
};
decide.getDecide = function (obj, callback) {
    //  utils.checkStatus(obj);
    if (obj.state > 0) {
        if (obj.Helper.indexOf("a Royal Flush") > -1) {
            actions.handTen(obj, callback);
            return false;
        }
        if (obj.Helper.indexOf("a Straight Flush") > -1) {
            actions.handTen(obj, callback);
            return false;
        }
    }

    switch (obj.state) {
        case 0:
            decide.preFlop(obj, callback);
            return false;
            break;
        case 1:
            decide.flop(obj, callback);
            return false;
            break;
        case 2:
            decide.flop(obj, callback);
            return false;
            break;
        case 3:
            decide.flop(obj, callback);
            return false;
            break;
    }
};

function isStraight(data) {
    var ranks = [];

    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        if (!ranks.includes(data[i])) {
            ranks.push(data[i]);
        }

        //Do something
    }
    if (ranks.includes(14)) {
        ranks.push(1);
    }
    ranks.sort(utils.compareNumbers);

    return getLoopStrOdds(ranks);
}

function getLoopStrOdds(ranks) {
    var isStr = false;
    var myRankFinal = [];
    var myRank = ranks;

    var arrayLength = myRank.length;

    for (var i = 0; i < arrayLength - 4; i++) {
        if (!isStr) {
            isStr = myRank[i] - 1 == myRank[i + 1] && myRank[i + 1] - 1 == myRank[i + 2] && myRank[i + 2] - 1 == myRank[i + 3] && myRank[i + 3] - 1 == myRank[i + 4];
            if (isStr) {
                myRankFinal = [myRank[i], myRank[i + 1], myRank[i + 2], myRank[i + 3], myRank[i + 4]];
            }
        }
    }
    //console.log(ranks,isStr)
    if (!isStr && arrayLength > 5) {
        var newRank = myRank.slice(1);

        return getLoopStrOdds(newRank);
    } else {
        if (!isStr) {
            return isStr;
        } else {
            return myRankFinal;
        }
    }
}

function getCenStrOdds(cards, flop, nuts, num, showAll) {
    //console.log(cards, flop,nuts,num)
    if (num >= 14) {
        return [];
    }
    var mynum = nuts > 0 ? nuts : 0;
    var finalCardUser = [];
    var finalCardFlop = [];
    var strOds = [];

    var cardsHigh = utils.SortStraight(cards);
    var cardsHighFlop = utils.SortStraight(flop);

    var isNuts = false;

    var carStr = 0;

    for (var j = 0; j < cardsHigh.length - 1; j++) {
        if (cardsHigh[j] - 4 <= cardsHigh[j + 1]) {
            if (!finalCardUser.includes(cardsHigh[j])) {
                finalCardUser.push(cardsHigh[j]);
            }
            if (!finalCardUser.includes(cardsHigh[j + 1])) {
                finalCardUser.push(cardsHigh[j + 1]);
            }
        }
    }
    for (var j = 0; j < cardsHighFlop.length - 1; j++) {
        if (cardsHighFlop[j] - 4 <= cardsHighFlop[j + 1]) {
            if (!finalCardFlop.includes(cardsHighFlop[j])) {
                finalCardFlop.push(cardsHighFlop[j]);
            }
            if (!finalCardFlop.includes(cardsHighFlop[j + 1])) {
                finalCardFlop.push(cardsHighFlop[j + 1]);
            }
        }
    }
    finalCardFlop.sort(utils.compareNumbers);
    finalCardUser.sort(utils.compareNumbers);

    var start = finalCardFlop[1] + 4;
    if (start > 14) {
        start = 14;
    }

    var end = finalCardFlop[finalCardFlop.length - 2] - 5;
    if (end < 1) {
        end = 1;
    }
    //console.log(finalCardFlop, finalCardUser,start,end)

    var defflop = finalCardFlop;
    var newnuts = mynum;
    for (var i = start; i >= end; i--) {
        //console.log(finalCardFlop,i,strOds.includes(i))
        var res = [];

        if (!finalCardFlop.includes(i) && !strOds.includes(i)) {
            defflop = finalCardFlop;

            //defflop = defflop.concat(cards);
            defflop.push(i);

            res = getCenStrOddsIs(cards, defflop, showAll);

            if (res.nuts && num - 4 < i && res.flop[4] <= i && res.nuts > newnuts && res.high > num) {
                //console.log(res)
                if (num) {
                    newnuts = res.nuts;
                }
                strOds.push(i);
            }
            defflop.pop();
        }
        // defflop=  defflop.slice(0,(flop.length+1) * -1)
    }

    if (strOds.length == 0 || flop.length == 5) {
        return [];
    }
    //return strOds
    return {
        flop: finalCardFlop,

        nuts: strOds.length > 2 ? 14 : num > 0 ? newnuts : (strOds.length * 14) / 6,
        cards: strOds,
        high: utils.getHigh(strOds),
        notRaise: (!utils.checkHaveFlushOdds(flop) && !utils.getDouble(flop)) || showAll ? false : true,
        num: num,
    };
}
function getCenStrOddsIs(myCards, flop, showAll) {
    var cards = myCards;
    var cardArr = {};
    if (cards.toString().indexOf("A") > -1 && !cards.includes("1")) {
        cards.push("1");
    }
    //console.log(cards)
    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) - 4 <= utils.getHigh(cards[i]);
            if (utils.getHigh(cards[j]) < utils.getHigh(cards[i])) {
                canAdd = utils.getHigh(cards[i]) - 4 <= utils.getHigh(cards[j]);
                count = cards[i][0] + cards[j][0];
            }
            if (utils.getHigh(cards[j]) == utils.getHigh(cards[i])) {
                canAdd = false;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    //console.log(cardArr)

    var isstr8 = false;
    var strcards = [];
    var strtotalcards = [];

    var cardsHighFlop = utils.SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1);
    }

    for (var prop in cardArr) {
        if (strcards.length >= 0) {
            var defflop = cardsHighFlop;
            var finalCardFlop = [];
            var myhand = utils.SortStraight(cardArr[prop]);
            defflop = defflop.concat(myhand);
            defflop = utils.SortStraight(defflop);
            //console.log(defflop)
            if (defflop.includes(14)) {
                defflop.push(1);
            }
            for (var j = 0; j < defflop.length - 1; j++) {
                if (defflop[j] - 4 <= defflop[j + 1] && defflop[j] - 4 <= myhand[1]) {
                    if (!finalCardFlop.includes(defflop[j]) && finalCardFlop.length <= 5) {
                        finalCardFlop.push(defflop[j]);
                    }
                    if (!finalCardFlop.includes(defflop[j + 1]) && finalCardFlop.length <= 5) {
                        finalCardFlop.push(defflop[j + 1]);
                    }
                }
            }
            //console.log(finalCardFlop,SortStraight(cardArr[prop]))
            //finalCardFlop = SortStraight(finalCardFlop);

            var defstr = isStraight(finalCardFlop);
            var defcard = utils.SortStraight(cardArr[prop]);
            if (defstr && defstr.includes(defcard[0]) && defstr.includes(defcard[1])) {
                strcards = defcard;
                strtotalcards = defstr;
                isstr8 = true;
            }
        }
    }
    if (isstr8) {
        //console.log(finalCardFlop,strtotalcards)
        var muhighCard = strcards[0] - strcards[1] > 3 ? (14 - (strtotalcards[0] - strcards[0]) + (14 - (strtotalcards[1] - strcards[1]))) / 2 : 14 - (strtotalcards[0] - strcards[0]);
        if ((cardsHighFlop.includes(strcards[0]) || cardsHighFlop.includes(strcards[1])) && muhighCard == 14) {
            muhighCard = muhighCard - 1;
        }
        var fnuts = strtotalcards[0] == 14 ? strtotalcards[0] : muhighCard;
        if (flop.length >= 3 && !showAll) {
            if (utils.checkHaveFlushOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (utils.getDouble(flop)) {
                fnuts = fnuts / 2;
            }
        }
        return {
            flop: strtotalcards,
            cards: strcards,
            high: strtotalcards[0] == 14 ? strtotalcards[0] : utils.getHigh(strcards),
            nuts: fnuts,
            notRaise: (!utils.checkHaveFlushOdds(flop) && !utils.getDouble(flop)) || showAll ? false : true,
        };
    }
    return [];
}

function haveFlushOdds(cards, flop, showAll) {
    var flopOdds = utils.groupBy(flop, (v) => v[1]);
    var flushOdds = utils.groupBy(cards, (v) => v[1]);
    var flush = [];
    var cartFlush = [];
    var count = flop.length == 5 ? 3 : 2;

    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= count) {
                flush.push({
                    cartName: prop,
                    flopCard: flopOdds[prop],
                    high: utils.getHigh(flopOdds[prop]),
                });
            }
        }
    }
    for (var propflush in flush) {
        for (var prop in flushOdds) {
            if (flushOdds.hasOwnProperty(prop)) {
                if (flushOdds[prop].length >= 2 && flush[propflush].cartName == prop) {
                    cartFlush.push({
                        cartName: prop,
                        Card: flushOdds[prop],
                        Flop: flush[propflush].flopCard,
                        notRaise: flush[propflush].flopCard.length >= 3 && (!utils.getDouble(flop) || showAll) ? false : true,

                        high: utils.getHigh(flushOdds[prop]),
                        nuts: utils.getNust("flush", flushOdds[prop], flush[propflush].flopCard),
                    });
                }
            }
        }
    }
    if (cartFlush.length == 0) {
        return [];
    }
    return cartFlush;
}
function haveFullOdds(cards, flop, showAll) {
    var full = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 4) {
                havePerUp4Flop = prop;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }
    if (havePerUp4Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < utils.getHigh(prop)) {
                    highPer = utils.getHigh(prop);
                }
            }
        }
        if (highPer == 0) {
            full = [];
        } else {
            full = {
                highSet: utils.getHigh(havePerUp4Flop),
                highPer: highPer,
                nuts: highPer,
                notRaise: highPer > 10 ? false : true,
            };
        }

        return full;
    }
    //console.log(showAll)
    if (havePerUp3Flop) {
        var highPer = 0;

        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2 && highPer < utils.getHigh(prop)) {
                    highPer = utils.getHigh(prop);
                }
            }
        }
        if (highPer == 0) {
            full = [];
        } else {
            full = {
                highSet: utils.getHigh(havePerUp3Flop),
                highPer: highPer,
                nuts: showAll ? highPer : highPer / 4,
                notRaise: showAll && highPer > 10 ? false : true,
            };
        }

        return full;
    }

    if (!havePerUpFlop) {
        return full;
    }
    var cardArr = {};
    for (var j = 0; j < cards.length - 1; j++) {
        for (var i = j + 1; i < cards.length; i++) {
            var count = cards[j][0] + cards[i][0];
            var canAdd = utils.getHigh(cards[j]) == utils.getHigh(cards[i]);
            //console.log(showAll)
            if (!canAdd && flop.toString().indexOf(cards[j][0]) > -1 && flop.toString().indexOf(cards[i][0]) > -1) {
                canAdd = true;
            }

            if (canAdd) {
                cardArr["" + count + ""] = [cards[j], cards[i]];
            }
        }
    }
    //console.log(cardArr)
    var perUp2 = 0;
    var perUp3 = 0;
    var high = 0;
    for (var propcard in cardArr) {
        var total = flop.concat(cardArr[propcard]);

        var tot = utils.groupBy(total, (v) => v[0]);

        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length >= 3 && utils.getHigh(perUp3) <= utils.getHigh(prop)) {
                    perUp3 = prop;
                }
            }
        }

        //console.log(cardArr[propcard])
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //console.log(perUp3,perUp2)

        for (var prop in flopPer) {
            if (flopPer.hasOwnProperty(prop)) {
                if (flopPer[prop].length >= 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    } else {
        //console.log(perUp3,perUp2,handPer,flopPer)
        for (var prop in tot) {
            if (tot.hasOwnProperty(prop)) {
                if (tot[prop].length >= 2 && utils.getHigh(perUp2) <= utils.getHigh(prop) && perUp3 != prop) {
                    perUp2 = prop;
                }
            }
        }
    }
    if (perUp3 == 0 || perUp2 == 0) {
        return [];
    }
    if (handPer[perUp3] && handPer[perUp3].length >= 2) {
        //Hidden Full
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp3, flop);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 10 ? false : true,
                nuts: fnuts,
            };
        }
    } else {
        if (utils.getHigh(perUp3) > utils.getHigh(perUp2)) {
            //Good Full
            var fnuts = utils.getNust("full", perUp2, flop.toString().replace(perUp3, "").replace(perUp3, ""));
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 9 ? false : true,
                nuts: fnuts,
            };
        } else {
            var fnuts = utils.getNust("full", perUp3, flop.toString().replace(perUp2, "").replace(perUp2, "").replace(perUp3, "").replace(perUp3, "")) - (flop.length - 2);
            full = {
                set: perUp3,
                per: perUp2,
                highSet: utils.getHigh(perUp3),
                highPer: utils.getHigh(perUp2),
                notRaise: showAll || fnuts > 8 ? false : true,
                nuts: fnuts,
            };
        }
    }
    //return false

    return full;
}

function haveSetOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var havePerUpHand = false;
    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length >= 2) {
                havePerUpHand = true;
            }
        }
    }

    if (!havePerUpHand) {
        return [];
    }
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            var h = utils.getHigh(prop);
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && high < h) {
                var fnuts = utils.getNust("set", tot[prop], flop);

                if (flop.length >= 3 && !showAll) {
                    if (utils.checkHaveFlushOdds(flop)) {
                        fnuts = fnuts / 2;
                    }
                    if (utils.checkHaveStrOdds(flop)) {
                        fnuts = fnuts / 2;
                    }
                }
                high = h;
                set = {
                    set: prop,
                    high: high,
                    nuts: fnuts,
                    notRaise: !showAll && (utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop)) ? true : false,
                };
            }
        }
    }

    return set;
}
function haveTreeOdds(cards, flop, showAll) {
    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    if (!havePerUpFlop) {
        return [];
    }
    var set = [];

    var high = 0;
    var total = cards.concat(flop);
    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 3 && flop.toString().indexOf(prop) > -1 && cards.toString().indexOf(prop) > -1 && high < utils.getHigh(prop)) {
                high = utils.getHigh(prop);
                var fnuts = utils.getNust("three", cards.toString().replace(prop, "").replace(prop, "").replace(prop, ""), flop);

                set = {
                    set: prop,
                    high: utils.getHigh(prop),
                    nuts: fnuts,
                    notRaise: !showAll && (utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop)) ? true : false,
                };
            }
        }
    }

    return set;
}
function getPerOdds(cards, flop, showAll) {
    var per = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);
    var cardsflop = [];
    var cardsflopDeck = [];

    var arrayLength = flop.length;
    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUpFlop = false;

    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = true;
            }
        }
    }

    for (var i = 0; i < arrayLength; i++) {
        if (cards.toString().indexOf(flop[i][0]) > -1) {
            cardsflop.push(utils.getHigh(flop[i]));
        }
        cardsflopDeck.push(utils.getHigh(flop[i]));
    }
    if (cardsflop.length < 2 && utils.getDouble(flop)) {
        cardsflop = [];
        for (var prop in handPer) {
            if (handPer.hasOwnProperty(prop)) {
                if (handPer[prop].length >= 2) {
                    cardsflop.push(utils.getHigh(handPer[prop]));
                }
            }
        }
        cardsflop.push(utils.getHigh(utils.getDouble(flop)));
    }

    cardsflopDeck.sort(utils.compareNumbers);
    cardsflop.sort(utils.compareNumbers);
    //console.log(cardsflop)

    if (cardsflop.length >= 2) {
        var fnuts = (cardsflop[0] + cardsflop[1]) / 2;

        if (flop.length >= 3 && !showAll) {
            if (utils.checkHaveFlushOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (utils.checkHaveStrOdds(flop)) {
                fnuts = fnuts / 2;
            }
            if (havePerUpFlop) {
                fnuts = fnuts / 2;
            }
        }

        per = {
            //notRaise: showAll ? false : true,
            notRaise: !showAll && (utils.checkHaveFlushOdds(flop) || utils.checkHaveStrOdds(flop) || havePerUpFlop) ? true : false,
            nuts: fnuts,
        };
    }

    return per;
}
function haveFourOdds(cards, flop, showAll) {
    var four = [];

    var handPer = utils.groupBy(cards, (v) => v[0]);

    var flopPer = utils.groupBy(flop, (v) => v[0]);
    var havePerUp4Flop = false;
    var havePerUp3Flop = false;
    var havePerUpFlop = false;
    var haveSet = false;
    for (var prop in flopPer) {
        if (flopPer.hasOwnProperty(prop)) {
            if (flopPer[prop].length == 4) {
                havePerUp4Flop = true;
            }
            if (flopPer[prop].length == 3) {
                havePerUp3Flop = prop;
            }
            if (flopPer[prop].length >= 2) {
                havePerUpFlop = prop;
            }
        }
    }
    if (havePerUp4Flop) {
        return four;
    }

    if (havePerUp3Flop) {
        if (cards.toString().indexOf(havePerUp3Flop) > -1) {
            four = {
                nuts: 14,
                notRaise: flop.length == 5 ? false : true,
            };
        }
        return four;
    }

    if (!havePerUpFlop) {
        return four;
    }
    var total = flop.concat(cards);

    var tot = utils.groupBy(total, (v) => v[0]);

    for (var prop in tot) {
        if (tot.hasOwnProperty(prop)) {
            if (tot[prop].length >= 4) {
                four = {
                    nuts: utils.getHigh(prop),
                    notRaise: false,
                };
            }
        }
    }

    return four;
}

decide.CreateOdds = function (cards, flop, player, showAll) {
    var Odds = {};
    Odds.four = [];
    Odds.full = [];
    Odds.flush = [];
    Odds.set = [];
    Odds.straight = [];
    Odds.isstraight = [];
    Odds.three = [];
    Odds.per = [];

    Odds.Player = player;
    Odds.four = haveFourOdds(cards, flop, showAll);

    if (Odds.four.length == 0) {
        Odds.full = haveFullOdds(cards, flop, showAll);

        if (Odds.full.length == 0) {
            Odds.flush = haveFlushOdds(cards, flop, showAll);
            Odds.set = haveSetOdds(cards, flop, showAll);
            Odds.three = haveTreeOdds(cards, flop, showAll);

            Odds.per = getPerOdds(cards, flop, showAll);
            var isstr = getCenStrOddsIs(cards, flop, showAll);
            Odds.isstraight = isstr;

            if (flop.length < 5) {
                Odds.straight = getCenStrOdds(cards, flop, isstr.cards ? isstr.nuts : 0, isstr.cards ? isstr.cards[0] : 0, showAll);
                // Odds.straight =[]
            }
        }
    }
    return Odds;
};
decide.GetOdds = function (obj) {
    var oDDs = [];
    var fourHigh = 0;
    var flushHigh = 0;
    var setHigh = 0;
    var str8High = 0;
    var fullHigh = 0;
    var perHigh = 0;
    var showAll = utils.checkShow(obj);
    var AllBots = utils.checkAllBots(obj);
    if (AllBots) {
        showAll = false;
    }
    //console.log("showAll",showAll)
    //console.info("showAll", showAll, "AllBots", AllBots);
    var PlayeroDDs = decide.CreateOdds(obj.convertedCards, obj.flopCards, obj.Player, showAll);

    //console.log("PlayeroDDs1", PlayeroDDs)
    if (!AllBots) {
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop)) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                    var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll);
                    //console.log(uOdds)
                    if (uOdds.flush.length > 0) {
                        for (var j = 0; j < uOdds.flush.length; j++) {
                            if (flushHigh < uOdds.flush[j].nuts) {
                                flushHigh = uOdds.flush[j].nuts;
                            }
                            if (uOdds.flush[j].Flop.length >= 3) {
                                PlayeroDDs.isstraight = [];
                                PlayeroDDs.straight = [];
                                PlayeroDDs.per.notRaise = true;
                                PlayeroDDs.set.notRaise = true;
                                PlayeroDDs.three.notRaise = true;
                                if (obj.flopCards.length == 5) {
                                    PlayeroDDs.set = [];
                                    PlayeroDDs.three = [];
                                    PlayeroDDs.per = [];
                                }
                            }
                        }
                    }
                    if (uOdds.four.nuts) {
                        if (fourHigh < uOdds.four.nuts) {
                            fourHigh = uOdds.four.nuts;
                        }
                        PlayeroDDs.full = [];
                        PlayeroDDs.flush = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.set = [];
                        PlayeroDDs.per = [];
                        PlayeroDDs.three = [];
                    }
                    if (uOdds.full.nuts) {
                        if (fullHigh < uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet) {
                            fullHigh = uOdds.full.nuts + uOdds.full.highPer + uOdds.full.highSet;
                        }
                        //console.log("fullHigh",fullHigh)
                        PlayeroDDs.flush = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.per = [];
                        if (uOdds.full.highSet > PlayeroDDs.set.nuts || (uOdds.full.highSet == PlayeroDDs.set.nuts && uOdds.full.highPer > utils.getHigh(obj.convertedCards)) || obj.flopCards.length == 5) {
                            PlayeroDDs.set = [];
                        }

                        if (uOdds.full.highSet > PlayeroDDs.three.high || (uOdds.full.highSet == PlayeroDDs.three.high && uOdds.full.highPer > utils.getHigh(obj.convertedCards)) || obj.flopCards.length >= 4) {
                            PlayeroDDs.three = [];
                        } else {
                            // console.log(uOdds.full.highSet , PlayeroDDs.three.high)
                            if (uOdds.full.highSet <= PlayeroDDs.three.high) {
                                //console.log(PlayeroDDs.three)
                                PlayeroDDs.three.notRaise = true;
                            }
                        }
                    }

                    if (uOdds.set.nuts) {
                        if (setHigh < uOdds.set.nuts) {
                            setHigh = uOdds.set.nuts;
                        }

                        PlayeroDDs.per = [];
                        try {
                            if (obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3) {
                                PlayeroDDs.flush = [];
                            }
                        } catch (err) {}
                    }
                    if (uOdds.three.nuts) {
                        if (setHigh < uOdds.three.nuts) {
                            setHigh = uOdds.three.nuts;
                        }
                        PlayeroDDs.per = [];
                        try {
                            if (obj.flopCards.length == 4 && PlayeroDDs.flush[0].Flop.length < 3) {
                                PlayeroDDs.flush = [];
                            }
                        } catch (err) {}
                    }
                    if (uOdds.per.nuts) {
                        if (perHigh < uOdds.per.nuts) {
                            perHigh = uOdds.per.nuts;
                        }
                    }
                    if (uOdds.isstraight.high) {
                        if (str8High < uOdds.isstraight.high) {
                            str8High = uOdds.isstraight.high;
                        }
                        PlayeroDDs.set.notRaise = true;
                        PlayeroDDs.three.notRaise = true;
                        PlayeroDDs.per.notRaise = true;

                        if (str8High > PlayeroDDs.straight.high || obj.flopCards.length == 5) {
                            PlayeroDDs.straight = [];
                        }
                        if (obj.flopCards.length == 5) {
                            PlayeroDDs.three = [];
                            PlayeroDDs.set = [];
                            PlayeroDDs.per = [];
                        }
                    }
                    if (obj.pls[prop].Helper.indexOf("a Royal Flush") > -1 || obj.pls[prop].Helper.indexOf("a Straight Flush") > -1) {
                        PlayeroDDs.four = [];
                        PlayeroDDs.full = [];
                        PlayeroDDs.flush = [];
                        PlayeroDDs.set = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.three = [];
                        PlayeroDDs.per = [];
                    }
                    oDDs.push(uOdds);
                }
            }
        }
    }
    if (PlayeroDDs.four.nuts) {
        if (fourHigh > PlayeroDDs.four.nuts) {
            PlayeroDDs.four = [];
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        } else {
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.full.nuts) {
        if (fullHigh > PlayeroDDs.full.nuts + PlayeroDDs.full.highPer + PlayeroDDs.full.highSet) {
            PlayeroDDs.full = [];
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        } else {
            PlayeroDDs.flush = [];
            PlayeroDDs.set = [];
            PlayeroDDs.straight = [];
            PlayeroDDs.isstraight = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }

    if (PlayeroDDs.flush.length > 0) {
        for (var j = 0; j < PlayeroDDs.flush.length; j++) {
            if (flushHigh > PlayeroDDs.flush[j].nuts) {
                PlayeroDDs.flush = [];
                PlayeroDDs.isstraight = [];
                PlayeroDDs.straight = [];

                if (obj.flopCards.length == 5) {
                    PlayeroDDs.set = [];
                    PlayeroDDs.three = [];
                    PlayeroDDs.per = [];
                }
            } else {
                if (PlayeroDDs.flush[j].Flop.length >= 3) {
                    PlayeroDDs.isstraight = [];
                    PlayeroDDs.straight = [];
                    if (obj.flopCards.length == 5) {
                        PlayeroDDs.set = [];
                        PlayeroDDs.three = [];
                        PlayeroDDs.per = [];
                    }
                } else {
                    if (obj.flopCards.length == 5) {
                        PlayeroDDs.set = [];
                        PlayeroDDs.three = [];
                        PlayeroDDs.isstraight = [];
                        PlayeroDDs.straight = [];
                        PlayeroDDs.per = [];
                    }
                }
            }
        }
    }
    if (PlayeroDDs.set.nuts) {
        if (setHigh > PlayeroDDs.set.nuts) {
            PlayeroDDs.set = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.three.nuts) {
        if (setHigh > PlayeroDDs.three.nuts) {
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    if (PlayeroDDs.per.nuts) {
        if (perHigh > PlayeroDDs.per.nuts) {
            PlayeroDDs.per = [];
        }
    }

    if (PlayeroDDs.isstraight.high) {
        if (str8High > PlayeroDDs.isstraight.high) {
            PlayeroDDs.isstraight = [];
            PlayeroDDs.straight.notRaise = true;
        }
        if (obj.flopCards.length == 5) {
            PlayeroDDs.set = [];
            PlayeroDDs.three = [];
            PlayeroDDs.per = [];
        }
    }
    //console.log("PlayeroDDs2", PlayeroDDs)
    var odds = 0;
    var oddsName = "";
    var oddsStr = [];
    var oddsCount = 0;
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop)) {
            if (PlayeroDDs[prop].nuts) {
                if (odds < PlayeroDDs[prop].nuts || (odds <= PlayeroDDs[prop].nuts && !PlayeroDDs[prop].notRaise)) {
                    odds = PlayeroDDs[prop].nuts;
                    oddsStr = PlayeroDDs[prop];
                    oddsName = prop;
                }
                if (!PlayeroDDs[prop].notRaise) {
                    oddsCount = oddsCount + 1;
                }
                // odds = odds + PlayeroDDs[prop].nuts
                //oddsCount = oddsCount + 1
            }
        }
    }

    if (PlayeroDDs["flush"].length > 0) {
        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
            if (PlayeroDDs["flush"][i].nuts) {
                if (odds < PlayeroDDs["flush"][i].nuts || (odds <= PlayeroDDs["flush"][i].nuts && !PlayeroDDs["flush"][i].notRaise)) {
                    odds = PlayeroDDs["flush"][i].nuts;
                    oddsStr = PlayeroDDs["flush"][i];
                    oddsName = "flush";
                    if (!PlayeroDDs["flush"][i].notRaise) {
                        oddsCount = oddsCount + 1;
                    }
                }
                if (!PlayeroDDs["flush"][i].notRaise) {
                    oddsCount = oddsCount + 1;
                }
                //odds = odds + PlayeroDDs[prop][i].nuts
                // oddsCount = oddsCount + 1
            }
        }
    }

    var finalcount = oddsCount > 0 ? oddsCount : 1;
    //var finalOds = (odds * 100) / 14 / finalcount;
    var finalOds = (odds * 100) / 14;
    var isFlush = true;
    if (oddsStr.notRaise && oddsCount == 0) {
        isFlush = false;
    }
    if (oddsName == "") {
        isFlush = false;
    }

    if (oddsName == "four") {
        finalOds = 100;
    }
    if (AllBots && !showAll) {
        showAll = true;
    }
    console.log("PlayeroDDs", oddsStr, finalOds, isFlush, showAll, oddsName);
    // if(oddsName=="full" && showAll){finalOds=100}
    return [finalOds, isFlush, showAll, oddsName];
};
decide.GetOtherOdds = function (obj) {
    var oDDs = [];
    var showAll = utils.checkShow(obj);
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll);
                //console.log(uOdds)
                if (uOdds.flush.length > 0) {
                    oDDs.push(uOdds.flush);
                }
                if (uOdds.four.nuts) {
                    oDDs.push(uOdds.four);
                }
                if (uOdds.full.nuts) {
                    oDDs.push(uOdds.full);
                }

                if (uOdds.set.nuts) {
                    oDDs.push(uOdds.set);
                }
                if (uOdds.three.nuts) {
                    oDDs.push(uOdds.three);
                }
                if (uOdds.per.nuts) {
                    oDDs.push(uOdds.per);
                }
                if (uOdds.isstraight.high) {
                    oDDs.push(uOdds.isstraight);
                }
                if (uOdds.straight.nuts) {
                    oDDs.push(uOdds.straight);
                }
            }
        }
    }

    //console.log(oDDs.length)
    return oDDs.length;
};
decide.GetOtherOddsStr = function (obj) {
    var oDDs = [];
    var showAll = utils.checkShow(obj);
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = decide.CreateOdds(obj.pls[prop].Cards, obj.flopCards, obj.pls[prop].Player, showAll);

                oDDs.push(uOdds);
            }
        }
    }

    //console.log(oDDs.length)
    return oDDs;
};

decide.call = function (callback, obj) {
    if (obj.state > 0) {
        var showAll = utils.checkShow(obj);
        var AllBots = utils.checkAllBots(obj);
        var PlayeroDDs = decide.GetOdds(obj);
        var OtherBlof = decide.GetOtherOddsStr(obj);
    }

    actions.call(callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof);
};
decide.fold = function (callback, obj) {
    if (obj.state > 0) {
        var showAll = utils.checkShow(obj);
        var AllBots = utils.checkAllBots(obj);
        var PlayeroDDs = decide.GetOdds(obj);
        var OtherBlof = decide.GetOtherOddsStr(obj);
    }
    actions.fold(callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof);
};
decide.raise = function (amount, callback, obj) {
    if (obj.state > 0) {
        var showAll = utils.checkShow(obj);
        var AllBots = utils.checkAllBots(obj);
        var PlayeroDDs = decide.GetOdds(obj);
        var OtherBlof = decide.GetOtherOddsStr(obj);
    }
    actions.raise(amount, callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof);
};
decide.check = function (callback, obj) {
    if (obj.state > 0) {
        var showAll = utils.checkShow(obj);
        var AllBots = utils.checkAllBots(obj);
        var PlayeroDDs = decide.GetOdds(obj);
        var OtherBlof = decide.GetOtherOddsStr(obj);
    }
    actions.check(callback, obj, showAll, AllBots, PlayeroDDs, OtherBlof);
};

decide.callfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];
    var canRaise = myprecentage[1];

    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;
    var Uipot = utils.checkInpot(obj);

    if (obj.place == 0 && obj.Pot != 0 && canRaise && myprecentage[2] && rest > callAm * 2) {
        //decide.raise(total, callback, obj);
        // return false
    }
    if (obj.place == 0 && myprecentage[2] && callAm <= obj.amounts.BB * 2) {
        //  decide.call(callback, obj);
        //   return false
    }

    if (100 == precentage && canRaise) {
        if (obj.Pot == 0) {
            decide.call(callback, obj);
            return false;
        }
        // if (callAm < total && callAm >= obj.amounts.BB) { total = callAm * 2 }

        decide.raise(total, callback, obj);
        return false;
    }
    if (50 <= precentage && canRaise && myprecentage[2]) {
        if (obj.Pot == 0 || !Uipot) {
            decide.call(callback, obj);
            return false;
        }

        decide.raise(total, callback, obj);
        return false;
    }
    if (50 <= precentage && canRaise && !myprecentage[2]) {
        decide.call(callback, obj);
        return false;
    }
    if (85 <= precentage) {
        if (obj.Pot == 0) {
            decide.call(callback, obj);
            return false;
        }
        if (rest - callAm <= callAm) {
            decide.raise(rest, callback, obj);
            return false;
        }
        decide.call(callback, obj);
        return false;
    }
    //console.log(myprecentage, inPot, callAm * 100 / total)

    if ((callAm * 100) / total <= precentage) {
        decide.call(callback, obj);
        return false;
    }
    if (precentage > 0 && canRaise && myprecentage[2]) {
        decide.call(callback, obj);
        return false;
    }
    if (precentage > 0) {
        if (rest <= total / 4) {
            decide.call(callback, obj);
            return false;
        }
    }
    if (rest <= (rest + inPot) / 4) {
        decide.call(callback, obj);
        return false;
    }

    decide.fold(callback, obj);
    return false;
};

decide.checkfunction = function (obj, callback, myprecentage) {
    var precentage = myprecentage[0];

    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;

    var inPot = obj.inPot > 0 ? obj.inPot : 1;
    var callAm = obj.Call;

    var pNum = utils.checkPlayerNumber(obj);
    //pNum = 2
    var OtherBlof = decide.GetOtherOdds(obj);
    var stt = utils.checkBankStat(obj);
    //console.log(stt, myprecentage)

    if (stt != 1 && OtherBlof == 0 && myprecentage[2] && obj.state == 1) {
        //console.log(OtherBlof,stt)
        decide.raise(total, callback, obj);
        return false;
    }
    var inPotPercent = ((inPot * (pNum / 2)) / total) * 100 * pNum;
    if (inPotPercent > 100) {
        inPotPercent = 100;
    }
    //console.log(inPotPercent,myprecentage)
    if ((myprecentage[3] == "full" || myprecentage[3] == "three" || myprecentage[3] == "set" || myprecentage[3] == "per" || myprecentage[3] == "flush" || myprecentage[3] == "isstraight" || myprecentage[3] == "straight") && myprecentage[1] && myprecentage[2] && obj.state < 3) {
        decide.raise(total, callback, obj);
        return false;
    }
    if ((myprecentage[3] == "full" || myprecentage[3] == "set" || myprecentage[3] == "flush" || myprecentage[3] == "isstraight") && myprecentage[1] && myprecentage[2]) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (myprecentage[3] == "four" && obj.state == 3) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (100 == precentage && myprecentage[1]) {
        decide.raise(total, callback, obj);
        return false;
    }
    if (100 == precentage && !myprecentage[1]) {
        if (stt == -1) {
            //console.log(stt,myprecentage)
            decide.raise(total, callback, obj);
            return false;
        }
    }
    if (inPotPercent <= precentage && myprecentage[1]) {
        if (86 < precentage) {
            decide.raise(total / 2, callback, obj);
            return false;
        }
    }

    if (precentage > 0) {
        if (rest <= (rest + inPot) / 10) {
            decide.raise(rest, callback, obj);
            return false;
        }
    }

    decide.check(callback, obj);
    return false;
};

function calculateFlushOddsOut(obj) {
    var totalout = 0;
    for (var prop in obj) {
        totalout = totalout + obj[prop].out;
        //console.log(obj[prop])
    }
    //console.log(totalout / obj.length)
    return totalout / obj.length;
}
decide.preFlop = function (obj, callback) {
    var rest = obj.Chips;
    var stt = utils.checkBankStat(obj);
    var winner = stt > 0 ? true : false;
    var looser = stt < 0 ? true : false;
    var flushOdds = utils.CleanOddsFlsuh(obj);
    var perOdds = utils.CleanOddsPer(obj);

    //

    var flushout = calculateFlushOddsOut(flushOdds);
    var canCall = false;
    if (flushOdds.length >= 1 && flushout < 4) {
        canCall = true;
    }
    if (perOdds[0] > 0 && perOdds[1] < 2) {
        canCall = true;
    }
    console.log(flushOdds, perOdds, flushout);
    //console.log("canCall", canCall)

    var inPot = obj.inPot > 0 ? obj.inPot : 0;

    if (looser) {
        if (flushOdds.length >= 1) {
            canCall = true;
        }
    }
    //console.log("canCall",canCall,obj.convertedCards)

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
    if (obj.Button2 == "Call") {
        if (utils.getThreeple(obj.convertedCards)) {
            decide.fold(callback, obj);
            return false;
        }

        if (canCall || (callAm <= obj.amounts.BB && inPot > 0)) {
            if (rest - callAm <= callAm) {
                if (obj.Pot == 0) {
                    decide.call(callback, obj);
                    return false;
                }
                decide.raise(rest, callback, obj);
                return false;
            }
            decide.call(callback, obj);
            return false;
        }

        decide.fold(callback, obj);
        return false;
    } else if (obj.Button2 == "Check") {
        if (canCall && !winner) {
            decide.raise(total, callback, obj);
            return false;
        }
        if (rest <= total / 2) {
            decide.raise(rest, callback, obj);
            return false;
        }
        decide.check(callback, obj);
        return false;
    }
};
decide.flop = function (obj, callback) {
    var precentage = decide.GetOdds(obj);
    if (obj.Button2 == "Check") {
        decide.checkfunction(obj, callback, precentage, precentage);
        return false;
    } else if (obj.Button2 == "Call") {
        decide.callfunction(obj, callback, precentage, precentage);

        return false;
    }
};
var obj = {
    Call: 2934000,
    Balance: {
        Available: 4999000000,
        Available2: 500000000,
        InPlay: 0,
        InPlay2: 0,
        Total: 4999000000,
        Total2: 500000000,
    },
    Pot: 2934000,
    inPot: 10000000,
    MinRaise: 2000000,
    MaxRaise: 4934000,
    Button2: "Call",
    seat: 2,
    place: -1,
    Player: "Toos",
    Chips: 21868000,
    Cards: ["3s", "2c", "5c", "4c", "5h"],
    Helper: "a Flush, Ace high +T543",
    total: 2934000,
    state: 2,
    tablename: "12 OM5 500K-1M (8) - Royal",
    gametype: "omaha5",
    handnumber: "#25282663-2",
    flopCards: ["Tc", "Ac", "8d", "5d"],
    convertedCards: ["3s", "2c", "5c", "4c", "5h"],
    amounts: {
        Pot: 2934000,
        Call: 1000000,
        BB: 1000000,
        total: undefined,
        Rest: 21868000,
    },
    pls: {
        2: {
            Player: "Toos",
            Chips: 21868000,
            Helper: "a Flush, Ace high +T543",
            Status: "playing",
            Cards: ["Tc", "Ac", "3c", "5d"],
            Bot: true,
            Dealer: true,
            inPot: [100, 10000, 19999, 100],
        },
        4: {
            Player: "player1",
            Chips: 38000000,
            Helper: "a Pair of undefined +AT3",
            Status: "playing",
            Cards: ["8s", "9c", "Tc", "4c", "5h"],
            Bot: false,
            Dealer: false,
            inPot: [100, 10000, 19990009, 100000],
        },
    },
};
console.log(decide.getDecide(obj));
