let inputConfig = {"configName":"my"}
let configfile = !inputConfig.configName ?  "./config.js"  : "../configs/" + inputConfig.configName + "config.js"  ;
let botfile = !inputConfig.configName ?  "./bots.json"  : "../configs/" + inputConfig.configName + "bots.json"  ;
config = require(configfile);
botData = require(botfile);
maven = require('./mavenapi');
maven.mvapi({"Command":"RingGamesList","Fields":"Name"},(res)=>{
let botList = [];
let bots = {"1":["daad","dafafafa"],"2":["daad","dafafafiiiia"]};
let kes = Object.keys(botData.Bots);

for(let i=0;i<kes.length;i++)
{
	
botList = botList.concat(botData.Bots[kes[i]]);


}

//for(
//connectedBots = connectedBots.concat(bots["2"]);


botList = botList.filter((item, pos) => botList.indexOf(item) === pos)

loop(res["Name"],botList,0,[],(out)=>{
	console.log(out);
	
});


	
});


function loop(list,botList,i,out,callback)
{
	
if(i<list.length)
{
	let tbl = list[i];
	maven.mvapi({"Command":"RingGamesPlaying","Name":tbl},(res2)=>{
		
		if(res2.Count > 0)
		{
			for(let pl of res2.Player)
			{
				if(botList.indexOf(pl) > -1)
				{
					
				out.push({"Player":pl,"Table":tbl});
					
				}
			}
		}

		
	i++;
				loop(list,botList,i,out,callback);
			
		
	});
		
			
	
	
	
	
	
}else{
	callback(out);
	
}
}