function utils() {}

utils.checkInpotLastState = function (ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = obj.state;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Player == obj.Player && obj.pls[prop].inPot[iPoto - 1] > 0) {
                showAll = false;
            }
        }
    }
    return showAll;
};
utils.removeItemAll = function (arr, value) {
    var i = 0;
    while (i < arr.length) {
        if (arr[i] === value) {
            arr.splice(i, 1);
        } else {
            ++i;
        }
    }
    return arr;
};

utils.groupBy = function (xy, f) {
    var x = utils.removeItemAll(xy, "15c");
    x = utils.removeItemAll(x, "1");
    return x.reduce(function (a, b, i) {
        var _a;

        return (a[(_a = f(b, i, x))] || (a[_a] = [])).push(b), a;
    }, {});
};
utils.compareNumbers = function (a, b) {
    return b - a;
};
utils.getKeyNum = function (cn) {
    var inte = 2;
    switch (cn) {
        case "Aces":
            inte = 14;
            break;
        case "Kings":
            inte = 13;
            break;
        case "Queens":
            inte = 12;
            break;
        case "Jacks":
            inte = 11;
            break;
        case "Tens":
            inte = 10;
            break;
        case "Nines":
            inte = 9;
            break;
        case "Eights":
            inte = 8;
            break;
        case "Sevens":
            inte = 7;
            break;
        case "Sixes":
            inte = 6;
            break;
        case "Fives":
            inte = 5;
            break;

        case "Fours":
            inte = 4;
            break;
        case "Threes":
            inte = 3;
            break;
        case "Ace":
            inte = 14;
            break;
        case "King":
            inte = 13;
            break;
        case "Queen":
            inte = 12;
            break;
        case "Jack":
            inte = 11;
            break;
        case "Ten":
            inte = 10;
            break;
        case "Nine":
            inte = 9;
            break;
        case "Eight":
            inte = 8;
            break;
        case "Seven":
            inte = 7;
            break;
        case "Six":
            inte = 6;
            break;
        case "Five":
            inte = 5;
            break;

        case "Four":
            inte = 4;
            break;
        case "Three":
            inte = 3;
            break;
    }

    return inte;
};
utils.randomIntFromInterval = function (min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
};
utils.getHigh = function (data) {
    var hand = data;
    try {
        hand = data.toString();
    } catch (error) {}

    if (hand.indexOf("A") > -1 || hand == "14" || hand.indexOf("14") > -1) return 14;
    if (hand.indexOf("K") > -1 || hand == "13" || hand.indexOf("13") > -1) return 13;
    if (hand.indexOf("Q") > -1 || hand == "12" || hand.indexOf("12") > -1) return 12;
    if (hand.indexOf("J") > -1 || hand == "11" || hand.indexOf("11") > -1) return 11;
    if (hand.indexOf("T") > -1 || hand == "10" || hand.indexOf("10") > -1) return 10;
    if (hand.indexOf("9") > -1) return 9;
    if (hand.indexOf("8") > -1) return 8;
    if (hand.indexOf("7") > -1) return 7;
    if (hand.indexOf("6") > -1) return 6;
    if (hand.indexOf("5") > -1) return 5;
    if (hand.indexOf("4") > -1) return 4;
    if (hand.indexOf("3") > -1) return 3;
    if (hand.indexOf("2") > -1) return 2;
    if (hand.indexOf("1") > -1) return 1;
    if (hand.indexOf("0") > -1) return 0;

    return utils.getKeyNum(hand);
};
utils.getHandRank = function (data) {
    var hand = data;

    if (hand == "high") return 10;
    if (hand == "per") return 4;
    if (hand == "two") return 2;
    if (hand == "three") return 2;
    if (hand == "set") return 1;
    if (hand == "straight") return 2;
    return 1;
};
utils.getRaiseAnount = function (obj, precentage) {
    var rest = obj.Chips;

    var total = obj.total > obj.Pot ? obj.total : obj.Pot;
    var callAm = obj.Call;
    if (rest <= total / 2) {
        return parseInt(rest);
    } else {
        if (callAm > 0) {
            total = (total + callAm) * 2;
        }
        if (rest <= total) {
            return parseInt(rest);
        }
        var tagh = 4;
        if (precentage >= 25) {
            tagh = 3;
        }
        if (precentage >= 50) {
            tagh = 2;
        }
        if (precentage >= 75) {
            tagh = 1;
        }

        return parseInt((total * obj.state) / tagh);
    }
};
utils.getNumofCard = function (cn) {
    var inte = cn;
    switch (cn) {
        case 10:
            inte = "T";
            break;
        case 11:
            inte = "J";
            break;
        case 12:
            inte = "Q";
            break;
        case 13:
            inte = "K";
            break;
        case 14:
            inte = "A";
            break;
    }

    return inte + "";
};
utils.getNust = function (mode, cards, flop) {
    var highofcard = utils.getHigh(cards);
    if (mode == "flush") {
        var nust = 14 - highofcard;

        for (var i = highofcard + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) > -1) {
                nust = nust - 1;
            }
        }
        return 14 - nust;
    }
    if (mode == "set") {
        var nust = highofcard;

        for (var i = nust + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) == -1) {
                nust = nust + 1;
            }
        }
        return nust;
    }
    if (mode == "three") {
        var nust = highofcard;

        return nust;
    }
    if (mode == "full") {
        var nust = 14;

        for (var i = highofcard + 1; i <= 14; i++) {
            if (flop.toString().indexOf(utils.getNumofCard(i)) > -1) {
                nust = nust - 1;
            }
        }
        return nust;
    }
};

utils.checkBankStat = function (obj) {
    var rest = obj.Chips + obj.inPot;
    var winner = rest > obj.amounts.BB * 60 ? true : false;
    var looser = rest < obj.amounts.BB * 10 ? true : false;
    if (winner) {
        return 1;
    }
    if (looser) {
        return -1;
    }
    return 0;
};
utils.CleanOddsPerPlayer = function (obj, Player, Hand, max) {
    var defmax = max ? max : 15;

    var noOut = 0;
    var TotalHigh = 0;
    var DHigh = 0;
    var handPer = utils.groupBy(Hand, (v) => v[0]);
    var perCount = 0;
    //console.log(defmax)

    for (var prop in handPer) {
        if (handPer.hasOwnProperty(prop)) {
            if (handPer[prop].length == 2 && utils.getHigh(prop) < defmax) {
                perCount = utils.getHigh(prop);
            }
        }
    }
    if (perCount) {
        var infoHand = utils.getOut(obj, Hand);
        noOut = infoHand[0].out;
        TotalHigh = infoHand[0].high;
        if (infoHand[0].out > 2) {
            TotalHigh = TotalHigh + 3;
        }
    }
    if (noOut > 3) {
        return utils.CleanOddsPerPlayer(obj, Player, Hand, perCount);
    }

    return [perCount, noOut, TotalHigh];
};
utils.CleanOddsPer = function (obj) {
    var DHigh = 0;
    var PPer = utils.CleanOddsPerPlayer(obj, obj.Player, obj.convertedCards);

    var perCount = PPer[0];
    var noOut = PPer[1];
    var TotalHigh = PPer[2];
    //console.log(PPer, utils.getOut(obj, obj.convertedCards));
    if (perCount) {
        for (var prop in obj.pls) {
            if (obj.pls.hasOwnProperty(prop)) {
                if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                    var uOdds = utils.CleanOddsPerPlayer(obj, obj.pls[prop].Player, obj.pls[prop].Cards);
                    if (uOdds[0]) {
                        if (DHigh < utils.getHigh(uOdds[0]) && uOdds[1] <= noOut) {
                            DHigh = utils.getHigh(uOdds[0]);
                        }
                        //console.log(uOdds)
                    }
                }
            }
        }
    }
    perCount = perCount < DHigh ? 0 : perCount;
    noOut = perCount > 0 ? noOut : 0;
    //console.log("DHigh",DHigh,perCount)
    //console.log("uOdds",PlayeroDDsNew,PlayeroDDs.length)

    return [perCount, noOut, TotalHigh];
};

utils.CleanOddsFlsuh = function (obj) {
    var TotalHigh = 0;
    var SHigh = 0;
    var CHigh = 0;
    var HHigh = 0;
    var DHigh = 0;
    var PlayeroDDs = utils.getFlushOdds(obj, obj.convertedCards);
    // console.log(PlayeroDDs);
    var PlayeroDDsNew = [];
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Player != obj.Player && obj.pls[prop].Cards[0].toString().indexOf("15") == -1) {
                var uOdds = utils.getFlushOdds(obj, obj.pls[prop].Cards);
                // console.log(uOdds);
                for (var j = 0; j < uOdds.length; j++) {
                    if (uOdds[j].cartName == "c") {
                        if (CHigh < uOdds[j].high) {
                            CHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "d") {
                        if (DHigh < uOdds[j].high) {
                            DHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "s") {
                        if (SHigh < uOdds[j].high) {
                            SHigh = uOdds[j].high;
                        }
                    }
                    if (uOdds[j].cartName == "h") {
                        if (HHigh < uOdds[j].high) {
                            HHigh = uOdds[j].high;
                        }
                    }
                }
            }
        }
    }

    for (var j = 0; j < PlayeroDDs.length; j++) {
        if (PlayeroDDs[j].cartName == "c") {
            if (CHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "d") {
            if (DHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "s") {
            if (SHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
        if (PlayeroDDs[j].cartName == "h") {
            if (HHigh < PlayeroDDs[j].high) {
                PlayeroDDsNew.push(PlayeroDDs[j]);
            }
        }
    }

    for (var j = 0; j < PlayeroDDsNew.length; j++) {
        TotalHigh = TotalHigh + PlayeroDDsNew[j].high;
    }
    //console.log("DHigh",DHigh)
    // console.log("uOdds", PlayeroDDsNew, PlayeroDDs.length);

    return PlayeroDDsNew;
};

utils.remove_duplicates_es6 = function (obj, cards) {
    try {
        var arr = obj.allCards.filter((name) => !name.includes(cards[0]) && !name.includes(cards[1]));
    } catch (error) {
        var arr = obj.allCards;
    }

    let s = new Set(arr);
    let it = s.values();
    return Array.from(it);
};
utils.getFlushOddsOut = function (obj, name, cards) {
    var _out = utils.getOutInfoFlush(obj)[name];

    return _out.out;
};
utils.getFlushOdds = function (obj, cards) {
    var flushOdds = utils.groupBy(cards, (v) => v[1]);
    var flush = [];
    var cartFlush = [];

    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 2) {
                var _out = utils.getOutInfoFlush(obj)[prop];
                if (flushOdds[prop].length >= 2 && _out.out < 8) {
                    cartFlush.push({
                        cartName: prop,
                        Card: flushOdds[prop],
                        high: utils.getHigh(flushOdds[prop]),
                        out: _out.out,
                        nuts: _out.nuts,
                    });
                }
            }
        }
    }

    if (cartFlush.length == 0) {
        return [];
    }
    return cartFlush;
};

utils.getThreeple = function (data) {
    var cards = data;
    var flushOdds = utils.groupBy(cards, (v) => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length >= 3) {
                finalOdds = utils.getHigh(flushOdds[prop]);
            }
        }
    }
    return finalOdds;
};
utils.getDouble = function (data, sum) {
    var cards = data;
    var flushOdds = utils.groupBy(cards, (v) => v[0]);
    var finalOdds = 0;
    for (var prop in flushOdds) {
        if (flushOdds.hasOwnProperty(prop)) {
            if (flushOdds[prop].length == 2) {
                if (sum) {
                    finalOdds += utils.getHigh(flushOdds[prop]);
                } else {
                    finalOdds = utils.getHigh(flushOdds[prop]);
                }
            }
        }
    }
    return finalOdds;
};
utils.checkHaveFlushOdds = function (flop) {
    var flopOdds = utils.groupBy(flop, (v) => v[1]);
    var isNuts = false;

    //console.log("flopOdds",flopOdds)
    for (var prop in flopOdds) {
        if (flopOdds.hasOwnProperty(prop)) {
            if (flopOdds[prop].length >= 3) {
                isNuts = true;
            }
        }
    }

    return isNuts;
};
utils.SortStraight = function (data) {
    var ranks = [];
    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        var high = utils.getHigh(data[i]);
        if (!ranks.includes(high)) {
            ranks.push(high);
        }

        //Do something
    }

    ranks.sort(utils.compareNumbers);
    //console.log(ranks)
    return ranks;
};
utils.checkHaveStrOdds = function (flop) {
    var isNuts = false;

    var cardsHighFlop = utils.SortStraight(flop);
    if (cardsHighFlop.includes(14)) {
        cardsHighFlop.push(1);
    }
    //console.log(cardsHighFlop)
    for (var i = 0; i < cardsHighFlop.length - 2; i++) {
        if (cardsHighFlop[i] - 4 <= cardsHighFlop[i + 2]) {
            isNuts = true;
        }
    }

    return isNuts;
};
utils.GetCleanOdds = function (data) {
    var odds = false;
    var PlayeroDDs = data;
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop) && !odds) {
            if (PlayeroDDs[prop].nuts) {
                odds = true;
            }
        }
    }

    if (PlayeroDDs["flush"].length > 0 && !odds) {
        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
            if (PlayeroDDs["flush"][i].nuts && !odds) {
                odds = true;
            }
        }
    }

    return odds;
};
utils.PrintCleanOdds = function (data, name, obj, propname, oDDs) {
    var PoDDs = utils.GetCleanOdds(oDDs);
    var PlayeroDDs = data;
    var PlayeroDDsFinal = {};
    var PlayeroDDsres = oDDs;
    // console.log(PlayeroDDsres)
    var PlayeroDDsFinalres = {};
    for (var prop in PlayeroDDs) {
        if (PlayeroDDs.hasOwnProperty(prop) && (!name || prop == name)) {
            if (PlayeroDDs[prop].nuts) {
                PlayeroDDsFinal[prop] = PlayeroDDs[prop];
            }
        }
    }

    if (PlayeroDDs["flush"].length > 0 && (!name || "flush" == name)) {
        for (var i = 0; i < PlayeroDDs["flush"].length; i++) {
            if (PlayeroDDs["flush"][i].nuts) {
                PlayeroDDsFinal["flush"] = PlayeroDDs["flush"];
            }
        }
    }
    for (var prop in PlayeroDDsres) {
        if (PlayeroDDsres.hasOwnProperty(prop)) {
            if (PlayeroDDsres[prop].nuts) {
                PlayeroDDsFinalres[prop] = PlayeroDDsres[prop];
            }
        }
    }

    if (PlayeroDDsres["flush"].length > 0) {
        for (var i = 0; i < PlayeroDDsres["flush"].length; i++) {
            if (PlayeroDDsres["flush"][i].nuts) {
                PlayeroDDsFinalres["flush"] = PlayeroDDsres["flush"];
            }
        }
    }

    if (PoDDs) {
        if (propname) {
            //console.log(obj.state + " - " + obj.Player + " ---  " + obj.pls[propname].Player, PlayeroDDsFinal, JSON.parse(JSON.stringify(PlayeroDDsFinalres)));
        } else {
            //console.log(obj.state + " - " + obj.Player, PlayeroDDsFinal);
        }
    } else {
        //console.log(obj.state + " - " + obj.Player, PlayeroDDsFinal, []);
    }

    return PoDDs;

    //return PlayeroDDsFinal;
};
utils.checkShow = function (ob) {
    var total = 0;
    var players = 0;
    var showAll = 0;
    var bots = 0;
    var showAllbots = 0;
    var obj = ob;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            total = total + 1;
            if (obj.pls[prop].Bot == false) {
                players = players + 1;
                if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                    showAll = showAll + 1;
                }
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                //console.log(allInPot);
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1];
                    for (var i = 2; i < 4; i++) {
                        if (obj.state >= i) {
                            allInPot = allInPot + obj.pls[prop].inPot[i];
                        }
                    }
                }

                if (allInPot >= obj.inPot) {
                    if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                        //showAll = false;
                    }
                }
            } else {
                bots = bots + 1;
                if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                    showAllbots = showAllbots + 1;
                }
            }
        }
    }

    return { total, players, showAll, bots, showAllbots };
};
utils.checkInpot = function (ob) {
    var showAll = true;
    var obj = ob;
    var iPoto = obj.state;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Player == obj.Player && obj.pls[prop].inPot[iPoto] > 0) {
                showAll = false;
            }
        }
    }
    return showAll;
};
utils.checkStatus = function (ob) {
    var obj = ob;

    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Bot == false) {
                var allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1] + obj.pls[prop].inPot[2] + obj.pls[prop].inPot[3];
                if (obj.state > 0) {
                    allInPot = obj.pls[prop].inPot[0] + obj.pls[prop].inPot[1];
                    for (var i = 2; i < 4; i++) {
                        if (obj.state >= i) {
                            allInPot = allInPot + obj.pls[prop].inPot[i];
                        }
                    }
                }
                if (allInPot >= obj.inPot) {
                    if (obj.pls[prop].Cards.length == 0 || (obj.pls[prop].Cards.length > 0 && obj.pls[prop].Cards[0].toString().indexOf("15") > -1)) {
                        console.log(obj.pls[prop]);
                        console.log(JSON.stringify(obj));
                    }
                }
            }
        }
    }
};
utils.checkPlayerNumber = function (obj) {
    var ob = 0;
    for (var prop in obj.pls) {
        if (obj.pls.hasOwnProperty(prop)) {
            if (obj.pls[prop].Cards.length > 0) {
                ob = ob + 1;
            }
        }
    }
    return ob;
};
utils.isStraight = function (data) {
    var ranks = [];

    var arrayLength = data.length;
    for (var i = 0; i < arrayLength; i++) {
        if (!ranks.includes(data[i])) {
            ranks.push(data[i]);
        }

        //Do something
    }
    if (ranks.includes(14)) {
        ranks.push(1);
    }
    ranks.sort(utils.compareNumbers);

    return utils.getLoopStrOdds(ranks);
};
utils.getLoopStrOdds = function (ranks) {
    var isStr = false;
    var myRankFinal = [];
    var myRank = ranks;

    var arrayLength = myRank.length;
    //console.log("ranks", ranks)
    for (var i = 0; i < arrayLength - 4; i++) {
        if (!isStr) {
            isStr = myRank[i] - 1 == myRank[i + 1] && myRank[i + 1] - 1 == myRank[i + 2] && myRank[i + 2] - 1 == myRank[i + 3] && myRank[i + 3] - 1 == myRank[i + 4];
            if (isStr) {
                myRankFinal = [myRank[i], myRank[i + 1], myRank[i + 2], myRank[i + 3], myRank[i + 4]];
            }
        }
    }
    //
    if (!isStr && arrayLength > 5) {
        var newRank = myRank.slice(1);

        return utils.getLoopStrOdds(newRank);
    } else {
        if (!isStr) {
            return isStr;
        } else {
            if (arrayLength > 5) {
                var newRank = myRankFinal.slice(0, 5);
                return newRank;
            }
            return myRankFinal;
        }
    }
};

utils.getOut = function (obj, cards) {
    var cardsInfo = [];
    var all = utils.getallCards(obj.allCards);

    for (var i = 0; i < cards.length; i++) {
        var CardOdds = all.filter((name) => utils.getHigh(name) > utils.getHigh(cards[i]));
        var CardOddsOut = all.filter((name) => utils.getHigh(name) == utils.getHigh(cards[i]));

        var cardsInfoFilter = [];
        for (var propplayer in CardOdds) {
            if (CardOdds.hasOwnProperty(propplayer)) {
                var highInfo = utils.getOutInfo(obj, CardOdds[propplayer]);
                var CardOddsOutFlushFilter = cardsInfoFilter.filter((name) => name.card[0].includes(highInfo.card[0]));
                if (highInfo.out < 4 && CardOddsOutFlushFilter.length == 0) {
                    cardsInfoFilter.push(highInfo);
                    // console.log(cardsInfoFilter);
                }
            }
        }
        var info = {
            card: cards[i],
            out: CardOddsOut.length,
            high: cardsInfoFilter.length,
        };
        cardsInfo.push(info);
    }
    //console.log(cardsInfo,CardOddsOutFlush,utils.getOutInfoFlush(obj));

    return cardsInfo;
};
utils.getOutInfo = function (obj, cards) {
    var all = utils.getallCards(obj.allCards);

    var CardOdds = all.filter((name) => utils.getHigh(name) > utils.getHigh(cards));
    var CardOddsOut = all.filter((name) => utils.getHigh(name) == utils.getHigh(cards));
    var info = {
        card: cards,
        out: CardOddsOut.length,
        high: CardOdds.length,
    };

    return info;
};
utils.getOutInfoFlush = function (obj) {
    var cardsInfo = {};
    var cards = ["c", "s", "h", "d"];
    var all = utils.getallCards(obj.allCards);
    for (var i = 0; i < cards.length; i++) {
        var CardOddsOutFlush = all.filter((name) => name[1].includes(cards[i]));
        cardsInfo[cards[i]] = {
            card: cards[i],
            out: CardOddsOutFlush.length,
            nuts: utils.getOutFlushNuts(CardOddsOutFlush),
        };
        // console.log(cardsInfo)
    }
    //console.log(cardsInfo);
    return cardsInfo;
};
utils.getOutFlushNuts = function (cards) {
    //console.log(cards)
    var nust = 14;
    if (utils.getHigh(cards) == 14) {
        nust = nust - 1;
        for (var i = nust; i > 9; i--) {
            if (cards.toString().indexOf(utils.getNumofCard(i)) > -1) {
                nust = nust - 1;
            } else {
                i = 9;
            }
        }
    }

    return nust;
};
utils.getallCards = function (data) {
    var cardsInfo = data.toString().split(",");
    var typeno = cardsInfo.filter((d) => d != "15c" && d != "1");
    // console.log(typeno);
    return typeno;
};
module.exports = utils;
