var requestify = require('requestify');
//var decide = require("./decide");
var cp = require("./cp");
//var flopcore = require("./flopcore");
//var flopcoreholdem = require("./flopcoreholdem");
AnalClass = require("./analclass");
var mkTable = function(data) {
	var t = this;
	t.ID = data.ID;
	t.Type = data.Type;
	t.Game = data.Game;
	t.STS = {};
	t.Seats = data.Seats;
	t.Dealer = {"set":0,"dealer":0};
	t.Playing = data.Playing;
	t.Players = {};
	t.Waiting = data.Waiting;
	t.bots = {};
	t.showapi = data.showapi;
	t.state = 0;
	t.flop = [0, 0, 0, 0, 0];
	t.total = 0;
	t.hands = {};
	t.pot = 0;
	t.calculated = false;
	t.SB = data.SB;
	t.BB = data.BB;
	t.BuyinMin = data.BuyinMin;
	t.BuyinMax = data.BuyinMax;
	t.handnumber = false;
	t.dealed = false;
	t._dealed = [];
	t._allcards = [];
	t._cardDealed = [];
	t.allBots = true;
	t.allHands = true;
	t.showDone = false;
	t._loger = {
						1: false,
						2: false,
						3: false
					};
	for (h = 0; h < data.Seats; h++) {
		t.Players[(h + 1)] = new cp({
			"Seat": (h + 1)
		});
	}
	t._players = {};
	t._allhand = true;
	t._seted = false;
	t.Games = {
		"Limit Hold'em": "holdem",
		"NL Hold'em": "holdem",
		"No Limit Hold'em": "holdem",
		"Pot Limit Omaha-5": "omaha5",
		"PL Omaha-5": "omaha5",
		"Pot Limit Omaha": "omaha",
		"PL Omaha": "omaha"
	};
}
mkTable.prototype.getDecide_random = function(ID, callback) {
	var t = this;

	var precentage = Math.floor((Math.random() * (100 - 1)) + 1);
	if (ID.Call > 0) {
		if (precentage < 90) {
			var ret = {
				"Button": "Call",
				"Amount": 0
			};
		} else {
			var ret = {
				"Button": "Fold",
				"Amount": 0
			};
		}
	} else {
		if (precentage < 30) {
			var ret = {
				"Button": "Check",
				"Amount": 0
			};
		} else {
			var raiseam = Math.floor((Math.random() * (20 - 1)) + 2);
			var BB = parseInt(t.BB);
			var ret = {
				"Button": "Raise",
				"Amount": (raiseam * BB)
			};
		}
	}
	
	setTimeout(()=>{
	callback(ret);
	},1000);
}
mkTable.prototype.checkDecide_JSON = function(ID, callback) {
	flopcore.getFlopPoint(ID.cards, ID.flop, ID.state, ID.helper, function(checkedpoint, logparams) {
		callback(checkedpoint);
	});
}
mkTable.prototype.getDecide_JSON = function(ID, callback) {
	bcore.getDecide_JSON(ID, callback);
	return;
}
mkTable.prototype.getDecide_JSON___ = function(ID, callback) {
	var t = this;
	var callValue = ID.points.callValue;
	var raiseValue = ID.points.raiseValue;
	var reraiseValue = ID.points.reraiseValue;
	if (ID.button.Button2 == "Check") {
		if (raiseValue > 0) {
			var decide = "Raise";
			var amount = raiseValue * ID.button.Pot;
		} else {
			var decide = "Check";
			var amount = 0; 
		}
	} else {
		if (ID.button.Button2 == "Call") {
			if (ID.button.Call <= (callValue * ID.button.Pot)) {
				if (reraiseValue > 0) {
					var decide = "Raise";
					var amount = reraiseValue * ID.button.Pot;
				} else {
					var decide = "Call";
					var amount = 0;
				}
			} else {
				var decide = "Fold";
				var amount = 0;
			}
		}
	}
	var ret = {
		"Button": decide,
		"Amount": amount
	};
	callback(ret);
}
mkTable.prototype.checkHelper = function(ID, callback) {
	
	var t = this;
	if(ID.Cards[0] > 0)
	{
		if(ID.Helper == "" )
		{
			AnalClass.getfinalhand(ID.Cards, t.flop, t.Games[t.Game], function(handanal) {
			ID.Helper = handanal.helper;
		//////////(handanal);
			callback(ID);
			
			
			});
		}else{
		
			callback(ID);
			
		}
	}else{
		//////////("checkHelper",ID);
		//erroring();
		callback(ID);
	}
		/*
	if(ID.Helper == "" && ID.Cards[0] > 0 && t.state > 0)
	{
		////////(ID);
	
		erroring();
		});
		
	}else{
		
	}
	*/
}
mkTable.prototype.getFinalDecide = function(ID,logs, callback) {
	var t = this;
	//////////("just odds",ID.odds);
	//////////(t.Players);
	let pls = {};
	for(let sea in t._players)
	{
		let ps = t._players[sea];
			pls[sea] = {Player:ps.Player,Chips:ps.Chips,Helper:(( ps.CLType != "Bot" && ps.Status == "playing" && ps.Cards[0] == 0 ) ? "No Show" : ps.Helper),Status:ps.Status,Cards:ps.Cards,Bot : ps.Bot,Dealer : (sea == t.Dealer.dealer),"inPot":ps.inPot};
		
		
		
		
		
		
		
	}
	
	ID.pls = pls;
	ID.allCards = t._allcards;
	if (t._allhand || 1==1) {
			//console.log(JSON.stringify(ID));
			decideClass.getDecide(ID, function(ret) {
				//console.log("ttt",ret);
					DBG("DECIDE SHOW " + ret.Button + " | Amount : " + ret.Amount,{"type": "allhand","Date":false,"Color":"green"});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDE LOG show hand" + JSON.stringify(logs),{"type": "decide","Date":false,"details":true});
					
					if(config.getDbLoger)
					{
					
						
						callback(ret);
					}else{
						
						callback(ret);
					
					}
					
					
				});
			} else {
				//////console.table(t.Players);
				//erorring();
				
				
				t.getDecide_JSON(ID, function(ret) {
					DBG("DECIDE JSON " + ret.Button + " | Amount : " + ret.Amount ,{"type": "allhand","Date":false,"Color":"red"});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDED JSON " + JSON.stringify(logs),{"type": "decide","Date":false,"details":true});
					if(config.getDbLoger)
					{
						
					flopcore.loger(false, logs, function() {});
					}
					
					callback(ret);
				});
			}
		
	
}
mkTable.prototype.getDecide = function(ID, callback) {
	
	var t = this;
	
	gametype = t.Games[t.Game];
	var pll = t.Players[ID.seat];
	//console.log(t._players,ID.seat);
	if(typeof t._players[ID.seat] != "undefined")
	{
	ID.Cards = t._players[ID.seat]._Cards;
		
		
	}
	if(pll._deciding == false)
	{
		pll._deciding = true;
		setTimeout(function(){
			
			pll._deciding = false;
			
			
		},2000);
		
		var logs = {};
		DBG("checkHelper " + JSON.stringify(ID), {
				"type":"decide",
				"Color": "yellow",
				"details":true,
				"Date":true
			});
	try{
		t.checkHelper(ID,function(ID){
			//var clcards = ID.Cards;
var clcards = bcore.clearplayercards(ID.Cards);
			//var omahahand = AnalClass.getpreflopOmaha(clcards, gametype);
		//	ID.Cards = gametype == "holdem" ? clcards : clcards;//omahahand.cards;
		DBG("getdecide " + JSON.stringify(ID), {
				"type":"decide",
				"Color": "yellow",
				"details":true,
				"Date":true
			});
			DBG("getFlopPoint " + JSON.stringify({"clcards": clcards,"flop": t.flop,"state": t.state,"Helper": ID.Helper,"gametype": gametype,}), {
				"type":"decide",
				"Color": "yellow",
				"details":true,
				"Date":true
			});
		try{	
			//flopcore.getFlopPoint(clcards,bcore.clearplayercards(t.flop),t.state,ID.Helper,gametype,function(checkedpoint, logparams) {
				
				if (t.state == 0) {
					
					//ID.preflopsum = checkedpoint;
				//	checkedpoint = logparams;
					//ID.odds = checkedpoint;
				}else{
					
					//ID.odds = logparams.odds;
				}
				
				
				
		//////////("checkpoint",checkedpoint, logparams);
				
			var amounts = {
				"Pot": ID.Pot,
				"Call": ID.Call,
				"BB": t.BB,
				"total": ID.Total,
				"Rest": ID.Chips
			};
			logs["amounts"] = amounts;
			logs["balance"] = ID.Balance;
			logs["playername"] = ID.Player;
			logs["playercards"] = clcards;
			logs["flopcards"] = bcore.clearplayercards(t.flop);
			logs["helper"] = ID.Helper;
			logs["state"] = t.state;
			logs["button2"] = ID.Button2;
			logs["handnumber"] = t.handnumber;
			logs["handpoint"] = pll.handpoint;
			logs["analedpoint"] = ID.point;
			//logs["checkedpoint"] = checkedpoint;
			logs["gametype"] = gametype;
			logs["amount"] = 0;
			logs["decide"] = "Call";
		//	logs["logs"] = logparams;
			logs["tablename"] = t.ID;
			ID.tablename = t.ID;
			ID.gametype = t.Games[t.Game];
			ID.handnumber = t.handnumber;
			ID.flopCards = bcore.clearplayercards( t.flop);
			ID.convertedCards = clcards;
				/*
				var callValue = parseFloat(checkedpoint[0]);
				var raiseValue = parseFloat(checkedpoint[1]);
				var reraiseValue = parseFloat(checkedpoint[2]);
				ID.points = {
					"reraiseValue": reraiseValue,
					"raiseValue": raiseValue,
					"callValue": callValue
				};*/
				ID.amounts = amounts;

				t.getFinalDecide(ID,logs,function(ret){
					
					callback(ret);
					
				});
				
				
				
				
				
			//});
		}catch (g) {
			//console.log(DBG.getTimer(),pll);
				//console.log(g);
			erroring();
				//////////("getFlopPoint",clcards,bcore.clearplayercards(t.flop),t.state,ID.Helper,gametype,g);
			//erroring();
			}
		
		});
		
	}catch (g) {
	 		//console.log("checkHelper",pll,g);
				erroring();
			}
	}

}
mkTable.prototype.getDecide_ORG = function(ID, callback) {
	var t = this;
	
	gametype = t.Games[t.Game];
	
	var pll = t.Players[ID.seat];
	if(pll._deciding == false)
	{
		pll._deciding = true;
		setTimeout(function(){
			
			pll._deciding = false;
			
			
		},5000);
		DBG(" ------------------------ ", {"type": "decide","Date":false});
		DBG("GET DECIDE | Player : " + ID.self.Player + " | Seat : " + ID.seat, {"type": "decide","Date":true});
		DBG(JSON.stringify({
			"cards": bcore.clearplayercards(ID.self.Cards)
		}), {"type": "decide","Date":false});
		DBG(JSON.stringify({
			"helper": ID.self.Helper
		}), {"type": "decide","Date":false});
		DBG(JSON.stringify({
			"handPoint": ID.self.handpoint,
			"point": ID.self.point,
			"place": ID.self.place
		}), {"type": "decide","Date":false});
		var logs = {};
		DBG(" ALL HAND " + t._allhand,{"type": "decide","Date":false,"Color":(t._allhand ? "green" : "red"),"details":true});
		if(gametype == "holdem")
		{
		
		flopcoreholdem.getFlopPoint(bcore.clearplayercards(ID.self.Cards),bcore.clearplayercards( t.flop), t.state, ID.self.Helper, function(checkedpoint, logparams) {
			DBG("Check Point " + 
			JSON.stringify(checkedpoint), {"type": "decide","Date":false,"Color":(checkedpoint == false ? "red":"green")});
			var amounts = {
				"Pot": ID.button.Pot,
				"Call": ID.button.Call,
				"BB": t.BB,
				"Rest": ID.self.Chips
			};
			if (t.state == 0) {
				checkedpoint = logparams;
			}
			logs["amounts"] = amounts;
			logs["playername"] = ID.self.Player;
			logs["tablename"] = t.ID;
			logs["playercards"] = bcore.clearplayercards(ID.self.Cards);
			logs["flopcards"] = bcore.clearplayercards(t.flop);
			logs["helper"] = ID.self.Helper;
			logs["state"] = t.state;
			logs["button2"] = ID.button.Button2;
			logs["handnumber"] = t.handnumber;
			logs["handpoint"] = pll.handpoint;
			logs["analedpoint"] = ID.self.point;
			logs["checkedpoint"] = checkedpoint;
			logs["amount"] = 0;
			logs["decide"] = "Call";
			logs["logs"] = logparams;
			//t._allhand = false;
			var callValue = parseFloat(checkedpoint[0]);
			var raiseValue = parseFloat(checkedpoint[1]);
			var reraiseValue = parseFloat(checkedpoint[2]);
			ID.flopCards = bcore.clearplayercards( t.flop);
			ID.points = {
				"reraiseValue": reraiseValue,
				"raiseValue": raiseValue,
				"callValue": callValue
			};
			if(amounts.Pot == 0)
			{
				if(amounts.Call > 0)
				{
					
					 ID.button.Pot =  ID.button.Call;
				}
				
				
			}
				
	if (t._allhand || 1==1) {
				decide.getDecide(ID, function(ret) {
					DBG("DECIDE SHOW " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDE LOG show hand" + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
						pll._deciding = false;
						callback(ret);
					
					flopcore.loger(false, logs, function() {
					});
					
				});
			} else {
				t.getDecide_JSON(ID, function(ret) {
					DBG("DECIDE JSON " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDED JSON " + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
						pll._deciding = false;
						callback(ret);
					flopcore.loger(false, logs, function() {
					});
				});
			}
		});
	
	}else{
		if(ID.self.Helper == "" && ID.self.Cards[0] > 0 && t.state > 0)
		{
			//////////(,bcore.clearplayercards( t.flop), t.state, ID.self.Helper);
			//errorring();
			AnalClass.getfinalhand(bcore.clearplayercards(ID.self.Cards), bcore.clearplayercards( t.flop), gametype, function(handanal) {
			var clcards = bcore.clearplayercards(ID.self.Cards);
		var omahahand = AnalClass.getpreflopOmaha(clcards, gametype);
		
		flopcore.getFlopPoint(omahahand.cards,bcore.clearplayercards( t.flop), t.state, ID.self.Helper, function(checkedpoint, logparams) {
			var amounts = {
				"Pot": ID.button.Pot,
				"Call": ID.button.Call,
				"BB": t.BB,
				"Rest": ID.self.Chips
			};
			if (t.state == 0) {
				checkedpoint = logparams;
			}
			DBG("Check Point " + 
			JSON.stringify(checkedpoint), {"type": "decide","Date":false,"Color":(checkedpoint == false ? "red":"green")});
			logs["amounts"] = amounts;
			logs["playername"] = ID.self.Player;
			logs["tablename"] = t.ID;
			logs["playercards"] = bcore.clearplayercards(ID.self.Cards);
			logs["flopcards"] = bcore.clearplayercards(t.flop);
			logs["helper"] = ID.self.Helper;
			logs["state"] = t.state;
			logs["button2"] = ID.button.Button2;
			logs["handnumber"] = t.handnumber;
			logs["handpoint"] = pll.handpoint;
			logs["analedpoint"] = ID.self.point;
			logs["checkedpoint"] = checkedpoint;
			logs["amount"] = 0;
			logs["decide"] = "Call";
			logs["logs"] = logparams;
			//t._allhand = false;
			var callValue = parseFloat(checkedpoint[0]);
			var raiseValue = parseFloat(checkedpoint[1]);
			var reraiseValue = parseFloat(checkedpoint[2]);
			ID.flopCards = bcore.clearplayercards( t.flop);
			ID.points = {
				"reraiseValue": reraiseValue,
				"raiseValue": raiseValue,
				"callValue": callValue
			};
			if(amounts.Pot == 0)
			{
				if(amounts.Call > 0)
				{
					
					 ID.button.Pot =  ID.button.Call;
				}
				
				
			}
			if (t._allhand || 1==1) {
				decide.getDecide(ID, function(ret) {
					DBG("DECIDE SHOW " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDE LOG show hand" + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
						pll._deciding = false;
						callback(ret);
				
					flopcore.loger(false, logs, function() {
					});
					
				});
			} else {
				t.getDecide_JSON(ID, function(ret) {
					DBG("DECIDE JSON " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDED JSON " + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
					//	pll._deciding = false;
						callback(ret);
					flopcore.loger(false, logs, function() {
					});
				});
			}
		});
	

			
			});
			
			
		}
		
var clcards = ID.self.Cards;
		var omahahand = AnalClass.getpreflopOmaha(clcards, gametype);
		
		flopcore.getFlopPoint(omahahand.cards,bcore.clearplayercards( t.flop), t.state, ID.self.Helper, function(checkedpoint, logparams) {
			var amounts = {
				"Pot": ID.button.Pot,
				"Call": ID.button.Call,
				"BB": t.BB,
				"Rest": ID.self.Chips
			};
			if (t.state == 0) {
				checkedpoint = logparams;
			}
			DBG("Check Point " + 
			JSON.stringify(checkedpoint), {"type": "decide","Date":false,"Color":(checkedpoint == false ? "red":"green")});
			logs["amounts"] = amounts;
			logs["playername"] = ID.self.Player;
			logs["tablename"] = t.ID;
			logs["playercards"] = bcore.clearplayercards(ID.self.Cards);
			logs["flopcards"] = bcore.clearplayercards(t.flop);
			logs["helper"] = ID.self.Helper;
			logs["state"] = t.state;
			logs["button2"] = ID.button.Button2;
			logs["handnumber"] = t.handnumber;
			logs["handpoint"] = pll.handpoint;
			logs["analedpoint"] = ID.self.point;
			logs["checkedpoint"] = checkedpoint;
			logs["amount"] = 0;
			logs["decide"] = "Call";
			logs["logs"] = logparams;
			//t._allhand = false;
			var callValue = parseFloat(checkedpoint[0]);
			var raiseValue = parseFloat(checkedpoint[1]);
			var reraiseValue = parseFloat(checkedpoint[2]);
			ID.flopCards = bcore.clearplayercards( t.flop);
			ID.points = {
				"reraiseValue": reraiseValue,
				"raiseValue": raiseValue,
				"callValue": callValue
			};
			if(amounts.Pot == 0)
			{
				if(amounts.Call > 0)
				{
					
					 ID.button.Pot =  ID.button.Call;
				}
				
				
			}
			if (t._allhand || 1==1) {
				decide.getDecide(ID, function(ret) {
					DBG("DECIDE SHOW " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDE LOG show hand" + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
						pll._deciding = false;
						callback(ret);
					
					flopcore.loger(false, logs, function() {
					});
					
				});
			} else {
				t.getDecide_JSON(ID, function(ret) {
					DBG("DECIDE JSON " + ret.Button + " | Amount : " + ret.Amount + " | Player : " + pll.Player,{"type": "decide","Date":false});
					logs["amount"] = ret.Amount;
					logs["decide"] = ret.Button;
					DBG("DECIDED JSON " + JSON.stringify(logs) + " Player : " + pll.Player,{"type": "decide","Date":false,"details":true});
					//	pll._deciding = false;
						callback(ret);
					flopcore.loger(false, logs, function() {
					});
				});
			}
		});
	
	}
	
	}

}
mkTable.prototype.getLogF8ile = function(log, callback) {
	var t = this;
	const d = new Date();
	let day = d.getDate();
	let year = d.getFullYear();
	let month = d.getMonth();
	var dir = config.logsDir;
	var fname = dir + year + "-" + month + "-" + day + " " + t.ID + ".txt";
	if (typeof log == "object") {
		var insertedlog = "\n" + JSON.stringify(log);
	} else {
		var insertedlog = "\n" + log;
	}
	if (!fs.existsSync(fname)) {
		var stream = fs.createWriteStream(fname);
		stream.once('open', function(fd) {
			stream.write("Open file " + t.ID);
			stream.write(insertedlog);
			stream.end();
			callback();
		});
	} else {
		fs.appendFile(fname, insertedlog, function(err) {
			if (err) throw err;
			callback();
		});
	}
}
mkTable.prototype.setFlop = function(k, flop) {
	var t = this;
	if (k == 0) {
		t.flop = flop;
	} else {
		t.flop[k] = flop;
	}
}
mkTable.prototype.getVal = function(k) {
	var t = this;
	return t[k];
}
mkTable.prototype.calculate = function(callback) {
	var t = this;
	var out = [];
	for (pl in t.Players) {
		if (t.Players[pl].Status != "empty" && t.Players[pl].Action == 0) {
			if (t.Players[pl].Cards[0] > 0) {
				out.push({
					"Cards": t.Players[pl].Cards[0],
					"Seat": t.Players[pl].Seat,
					"point": t.Players[pl].point
				});
			}
		} else {}
	}
	if (t._allhand || 1==1) {
		out.sort(function compareByAge(a, b) {
			return a.point - b.point;
		});
		var places = [];
		for (r = 0; r < out.length; r++) {
			t.Players[out[r].Seat].place = t.state == 0 ? r : ((out.length - 1) - r);
			DBG("Set place | Player : " + t.Players[out[r].Seat].Player + " | Seat : " + out[r].Seat + " | Place : " + t.Players[out[r].Seat].place, {"type": "sethand","Date":true});
		}
		callback();
	} else {
		callback();
	}
}
mkTable.prototype.calculateLoop = function(res, i, callback) {
	var t = this;
	if (i < res.length) {
		i++;
		t.calculateLoop(res, i, callback);
	} else {
		callback();
	}
}
mkTable.prototype.calculateAllhand = function(callback) {
	var t = this;
	var out = [];
	t._allhand = true;
	for (pl in t.Players) {
		if (t.Players[pl].Status != "empty" && t.Players[pl].Action == 0) {
			
			t.Players[pl].CCards = JSON.stringify(bcore.clearplayercards(t.Players[pl]["Cards"]));
			if (t.Players[pl].Cards[0] == 0) {
				t._allhand = false;
			}
		} else {}
	}
	if (config.debug.tables) {
		DBG.table(t.Players, ["Player", "Status", "CCards"]);
	}
	DBG("SET HANDS " + (t._allhand ? " OK " : " ERROR "), {"type": "sethand","Date":true,"Color": (t._allhand ? "green" : "red")});
	callback(t._allhand);
}
mkTable.prototype.updateOLD_1 = function(data,params) {
	
	var t = this;
	var playing = 0;
		for(var e=0;e<data.Player.length;e++)
		{
			if (data.Player[e] != "")
			{
				playing++;
			}
			
		}
		////////("tset",t._seted ,"playing",playing,params);
	if(t._seted == false)// && playing >0 ) ||  params.opentable)
	{
		DBG("passed set " + t._seted + " |  playing " + playing + " |  opentable " + params.opentable ,{"type": "updatetable","Date":true,"Color":"red"});
	//////////(data);
		t._seted = true;
		setTimeout(function(){
			
		t._seted = false;
			
			
		},1000);
		//bcore.sendMonitor({"Command":"tablelog","Type":"table","Table":dt.Table,"dt":t});
		
		t.total = data.Total;
		t.flop = data.Board;
		var seted = 0;
		var updated = 0;
		////////////////(data.Player);
		for (i = 0; i < data.Seats; i++) {
			var pls = t.Players[(i + 1)];
		
		//////("---" ,i," ___ " + data.Player[i] + " ___ ");
			if (data.Player[i] != "") {
				var pl = data.Player[i].toLowerCase();
				if (pls.Status == "empty") {
					DBG("Player set :" + t.ID + " -  Player : " + pl + "  - Seat : " + (i + 1),{"type": "updatetable","Date":true,"Color":"green"});
					pls.setPlayer({
						"Player": pl,
						"Chips": data.Chips[i],
						"Action": data.Action[i],
						"Status":"Playing"
					});
					seted++;
				} else {
					if (pls.Player.toLowerCase() == pl)     {
						updated++;
						pls.update({
							"Chips": data.Chips[i],
							"Action": data.Action[i]
						});
						DBG("Update :" + t.ID + " - Player  : " + pl + " - Seat : " + (i + 1), {"type": "updatetable","Date":true});
					} else {
						DBG("Player Reset :" + t.ID + "     -  Player : " + pl + "  - Seat : " + (i + 1), {"type": "updatetable","Date":true});
						pls.setPlayer({
							"Player": pl,
							"Chips": data.Chips[i],
							"Action": data.Action[i]
						});
						seted++;
					}
				}
			} else {
				
				DBG("Player Sitout Seat : " + i + " | Player = " + data.Player[i] + " | Status : " + pls.Status , {"type": "updatetable","Date":true,"Color":"yellow","details":true});
						
				
				
					pls.sitOujjt();
					DBG(" Done" , {"type": "updatetable","Date":true,"Color":"green"});
					
				
				
			}
		}
		if (seted) {
			DBG(seted + " Players Seted " + t.ID, {"type": "update","Date":true});
		}
		if (updated) {
			DBG(updated + " Players Updated " + t.ID, {"type": "update","Date":true});
		}
		
		if(config.debug.updatetable)
		{
			////console.table(t.Players,["Player","Status"]);
			
		}
		
	}else{
		
	}
}
mkTable.prototype.reCreate = function(data,callback) {
	
	
	let t = this;
	for(let pl in t.Players)
	{
		t.Players[pl].reCreate(data.Players[pl]);
		
	}
	t.Dealer = data.Dealer;
	t.state = data.state;
	t.flop = data.flop;
	t.total = data.total;
	t.hands = data.hands;
	t.pot = data.pot;
	
	t._loger = data._loger;
	//////("recreate table done");
	callback();

}
mkTable.prototype.checkAlone = function() {
	var t = this;
	if(t.Type == "T")
	{
		return true;
		
	}
	let playing = 0;
	let botName= "";
	let chips = 0;
	for(let st in t.Players)
	{
		let pls = t.Players[st];
		//////(pls);
		if (pls.Action != 15)
		{
			if(pls.CLType == "Bot")
			{
				chips = pls.Chips;
				botName = pls.Player.toLowerCase();
				////////("check alone",botName);
				if( typeof bcore.Clients[botName] != "undefined" && typeof bcore.Clients[botName].Tables[t.ID] != "undefined" &&  bcore.Clients[botName].Tables[t.ID].sitingOut == false)
				{
					bcore.Clients[botName].Tables[t.ID].alone = false;
					
				}
			}
			playing++;
		}else{
			if(pls.CLType == "Bot")
			{
				let bName = pls.Player.toLowerCase();
				if( typeof bcore.Clients[bName] != "undefined" && typeof bcore.Clients[bName].Tables[t.ID] != "undefined" && bcore.Clients[bName].Tables[t.ID].alone == false)
				{
					
				bcore.Clients[bName].getAlone(t.ID,"sittingOut");
				
				}
			}
		}
		
			
	}
	let BBs = (t.BB * 20);
	let min =   (BBs - (BBs * 0.05));
	let max =   (BBs + (BBs * 0.05));
DBG("check Alone : Player : " +botName   +" (" +chips + ") | playing : " +playing   +"  | typeof : " + typeof bcore.Clients[botName] + " | minmax (" + min + "," + max + ") ", {"type":"botseat","player":botName,"Color":"yellow","details":false,"Date":true}); 
	
	if(playing == 1 && botName != "" && typeof bcore.Clients[botName] != "undefined" )
	{
		DBG("check pass alone . Player : " +botName + " | minmax (" + min + "," + max + ") ",{"type":"botseat","player":botName,"Color":"yellow"});
		if( chips > min  && chips < max)
		{
		
			bcore.Clients[botName].getAlone(t.ID,"Start");
		}else{
			
			bcore.Clients[botName].getAlone(t.ID,"End");
		}
	}
}

mkTable.prototype.playerSeat = function(pl) {
	let t= this;
	let ret = false;

	if((typeof bcore.Clients[pl.toLowerCase()] != "undefined" && typeof bcore.Clients[pl.toLowerCase()].Tables[t.ID] != "undefined") )
	{
		return bcore.Clients[pl.toLowerCase()].Tables[t.ID].Seat;
		//////("inja3 miad",ret,pl,t.ID);
	}
	
	for(let st in t.Players )
	{
		if(t.Players[st].Player.toLowerCase() == pl.toLowerCase() && t.Players[st].Status != "empty" )
		{
		
			ret = st;
			break;
		}
	}

	//////("ret " + ret);
		return ret;
	
	
}

mkTable.prototype.playerExists = function(pl) {
	let t= this;
	let ret = false;
	for(let st in t.Players )
	{
		if(t.Players[st].Player.toLowerCase() == pl.toLowerCase() && t.Players[st].Status != "empty" )
		{
		
			ret = true;
			break;
		}
	}

	if((typeof bcore.Clients[pl.toLowerCase()] != "undefined" && typeof bcore.Clients[pl.toLowerCase()].Tables[t.ID] != "undefined") )
	{
		ret = true;
		//////("inja3 miad",ret,pl,t.ID);
	}
	
	//////("ret " + ret);
		return ret;
	
	
}

mkTable.prototype.update = function(data,params,callback) {
	
	var t = this;
	var playing = 0;
	if(t._seted == false)// && playing >0 ) ||  params.opentable)
	{
		DBG("passed set " + t._seted + " |  playing " + playing + " |  opentable " + params.opentable ,{"type": "updatetable","Date":true,"Color":"red"});
		if(data.Type == "R")
		{
		t._seted = true;
		setTimeout(function(){
			
			t._seted = false;
			
			
		},1000);
		
		}
		//bcore.sendMonitor({"Command":"tablelog","Type":"table","Table":dt.Table,"dt":t});
		
		t.total = data.Total;
		t.flop = data.Board;
		var seted = 0;
		var updated = 0;
		
		for (i = 0; i < data.Seats; i++) {
			var pls = t.Players[(i + 1)];
			
		////////("---" ,i," ___ " + data.Player[i] + " ___ " + data.Action[i] + " ___ ");
			if (data.Player[i] != "") {
				var pl = data.Player[i].toLowerCase();
				/*if (pls.Status == "empty") {
					DBG("Player set :" + t.ID + " -  Player : " + pl + "  - Seat : " + (i + 1),{"type": "updatetable","Date":true,"Color":"green"});
					pls.setPlayer({
						"Player": pl,
						"Chips": data.Chips[i],
						"Action": data.Action[i],
						"Status":"Playing"
					});
					seted++;
				} else {
					
					*/
					////////(pls);
				
					if (pls.Player.toLowerCase() == pl)     {
						updated++;
						pls.update({
							"Chips": data.Chips[i],
							"Action": data.Action[i],
							"Status": (data.Action[i] != 15 ? "playing": "sitingout"),
						});
						DBG("Update :" + t.ID + " - Player  : " + pl + " - Seat : " + (i + 1), {"type": "updatetable","Date":true});
					} else {
						DBG("Player Reset :" + t.ID + "     -  Player : " + pl + "  - Seat : " + (i + 1), {"type": "updatetable","Date":true,"Color":"red"});
						pls.setPlayer({
							"Player": pl,
							"Chips": data.Chips[i],
							"Action": data.Action[i],
							"Status": (data.Action[i] != 15 ? "playing": "sitingout")
						});
						seted++;
					}
					
				/*}*/
			} else {
				
				DBG("Player Sitout Seat : " + pls.Seat + " | Player = " + data.Player[i] + " | Status : " + pls.Status , {"type": "updatetable","Date":true,"Color":"yellow","details":true});
						
				if(pls.Status != "empty")
				{
					// just for cleaning sit
					pls.sitOut(function(){
						
					DBG(" Sitout Done" , {"type": "updatetable","Date":true,"Color":"green"});
						
						
					});
					
				
				}
				
			}
		}
		if (seted) {
			DBG(seted + " Players Seted " + t.ID, {"type": "update","Date":true});
		}
		if (updated) {
			DBG(updated + " Players Updated " + t.ID, {"type": "update","Date":true});
		}
		
		if(config.debug.updatetable)
		{
			DBG.table(t.Players,["Player","Status","Action"]);
			
		}
		callback();
	}else{
		
	}
}
mkTable.prototype.setVal = function(k, v) {
	var t = this;
	t[k] = v;
}
mkTable.prototype.resetHands = function(callback) {
	var t = this;
	for (ssp in t.Players) {
		t.Players[ssp].reset();
		if (t.Players[ssp].Action == 14) {
			t.Players[ssp].Action = 0;
		}
	}
	callback();
}
mkTable.prototype.SetHands = function(callback) {
	var t = this;
	//////////////("sethands",typeof t.hands[t.handnumber],t.hands[t.handnumber]);
	//////////////("Get SET Hand PREFLOP | Hand Number : " + t.handnumber,{"type": "sethand","Date":true});
	DBG("Get SET Hand PREFLOP | Hand Number : " + t.handnumber + " | " + typeof t.hands[t.handnumber] + " + "+ JSON.stringify(t.hands[t.handnumber]), {"type": "sethand","Date":true});
	DBG("Get SET Hand DEALED | DEALED : " + t.dealed + " - " + JSON.stringify(t._players), {"type": "sethand","Date":true});
		var ttd = new Date();
		if (typeof t.hands[t.handnumber] == "undefined") {
			//console.log("get SEt HAND" + t.handnumber,t._players);
			t.hands = {};
			t.hands[t.handnumber] = {0: [false, false],1: [false, false],2: [false, false],3: [false, false]};
		
				//	atatafA();
				
			////////////("hand get seted ",ttd.getMinutes() + ":" + ttd.getSeconds() );
				setTimeout(function() {
					DBG("Get Show Hand " + t.ID + " All Bots : " + t.allBots, {"type": "sethand","Date":false,"color":"red"});
		
					if(t.allBots ==  false)
					{
					////////////("hand set Done ",typeof t.hands[t.handnumber],t.hands[t.handnumber],ttd.getMinutes() + ":" + ttd.getSeconds());
					DBG("Get Show Hand " + t.ID + " Hand Number : " + t.handnumber, {"type": "sethand","Date":false});
					t.getShowData(function(data) {
						
						DBG("Data fetched " + t.ID + "  " + data.length + " Players ", {"type": "sethand","Date":false});
						////////////(data,ttd.getMinutes() + ":" + ttd.getSeconds());
						for (x = 0; x < data.length; x++) {
							DBG("Player : " + data[x].username + "  Helper : " + data[x].data,  {"type": "sethand","Date":false});
						}
						DBG("Get Convert " + t.ID + " Hand Number : " + t.handnumber,  {"type": "sethand","Date":false});
						t.convertShowHand(data, function(converted) {
							DBG("Converted Hand Number : " + t.handnumber,  {"type": "sethand","Date":false});
							DBG("Players : " + JSON.stringify(Object.keys(converted)),  {"type": "sethand","Date":false});
							t.convertShowHandLoop(converted, 0, function() {
							//console.log(t._players,"Allbot",t.allBots);
								t.showDone = true;
								callback();
							});
						});
					});
					}else{
						t.showDone = true;
						callback();
						
					}
					
				}, (config.showdelay * 1000));
					
					
					
			} else {
				////////////("Seted Already : " + t.handnumber, ttd.getMinutes() + ":" + ttd.getSeconds());
				//(t.Players);
				console.table(t._players,["Player","Helper","Cards"]);
				DBG("Seted Already : " + t.handnumber, {"type": "sethand","color":"red","Date":false});
				callback(t._allhand);
			}
	
}
mkTable.prototype.convertShowHandLoop = function(out, inz, callback) {
	var t = this;
	for(let pl in t._players)
	{
	//console.log("===================== her",t._players[pl]);
		
		if(t._players[pl].Bot == false)
		{
			if(typeof out[t._players[pl].Player.toLowerCase()] != "undefined")
			{
				t._players[pl].Cards = out[t._players[pl].Player.toLowerCase()].cards;
				t._players[pl]._Cards = out[t._players[pl].Player.toLowerCase()]._cards;
				t._players[pl].Helper = out[t._players[pl].Player.toLowerCase()].helper;
				
			}else{
				t._players[pl].Cards = bcore.clearplayercards([53,53,53,53,53]);
				t._players[pl]._Cards = [53,53,53,53,53];
				t._players[pl].Helper = "No show data";
			}
		
		
			t._allcards = [t._players[pl].Cards ,...t._allcards];
		
		
		}
	}
	
	callback();
	
}
mkTable.prototype.convertShowHandLoopOLD = function(out, inz, callback) {
	var t = this;
	
	
	var kes = Object.keys(out);
	if (inz < kes.length) {
		var ou = out[kes[inz]];
		var seat = 0;
		for (ssp in t.Players) {
			if (t.Players[ssp].Player.toLowerCase() == ou.player.toLowerCase()) {
				seat = ssp;
				break;
			}
		}
		if (seat > 0) {
			t._players[seat]["Cards"] = ou["cards"];
			t._players[seat]["Helper"] = ou["helper"];
			DBG("Set show hand to Player : " + t.ID, {"type": "sethand","Date":true});
			DBG("Cards: " + JSON.stringify(bcore.clearplayercards(t.Players[seat]["Cards"])) + " Player : " + t.Players[seat]["Player"],{"type": "sethand","Date":false});
		}
		inz++;
		t.convertShowHandLoop(out, inz, callback);
	} else {
		callback();
	}
}
mkTable.prototype.SetHandsFlop = function(callback) {
	var t = this;
	t._allhand = false;
	var states = ["Flop", "Turn", "River"];
	if (t.state > 0) {
		if (t.hands[t.handnumber][t.state.toString()][0] == false) {
			DBG(" ---------------------------------- ",{"type": "sethand","Date":false});
			DBG("SET Hand " + states[(t.state - 1)] + " | Hand Number : " + t.handnumber + " - " + t.state, {"type": "sethand","Date":false});
			t.hands[t.handnumber][t.state.toString()][0] = true;
			DBG("Get Show Hand " + t.ID + " Hand Number : " + t.handnumber,{"type": "sethand","Date":false});
			t.getShowData(function(data) {
				DBG("Data fetched " + t.ID + "  " + data.length + " Players ", {"type": "sethand","Date":false});
				for (x = 0; x < data.length; x++) {
					DBG("Player : " + data[x].username + "  Helper : " + data[x].data, "yellow4");
				}
				DBG("Get Convert " + t.ID + " Hand Number : " + t.handnumber, "yellow4");
				t.convertShowHand(data, function(converted) {
					DBG("Converted Hand Number : " + t.handnumber, "yellow4");
					DBG("Players : " + JSON.stringify(Object.keys(converted)), "yellow4", true);
					for (var pl in converted) {
						var seat = 0;
						for (ssp in t.Players) {
							if (t.Players[ssp].Player.toLowerCase() == pl.toLowerCase()) {
								seat = ssp;
								break;
							}
						}
						t.Players[ssp]["point"] = converted[pl]["point"];
						t.Players[ssp]["handpoint"] = converted[pl]["handpoint"];
						t.Players[ssp]["Helper"] = converted[pl]["helper"];
						t.Players[ssp]["Cards"] = converted[pl]["cards"];
						DBG("Set show hand to Player : " + pl + " | Point : " + t.Players[ssp]["point"] + " |  Handpoint : " + t.Players[ssp]["handpoint"], "blue4");
						DBG("Helper: " + t.Players[ssp]["Helper"] + " |  Cards : " + JSON.stringify(bcore.clearplayercards(t.Players[ssp]["Cards"])), "blue4", true);
					}
					t.calculate(function() {
						callback(t._allhand);
					});
				});
			});
		} else {
			callback(t._allhand);
		}
	}
}

mkTable.prototype.cleanPosition = function(pos)
{
	let ret = ((parseInt(pos.split("px")) * -1) / 46) + 1;
	ret = !isNaN(ret) ? ret : 53;
	return ret;
	
}

mkTable.prototype.convertShowHand = function(data, callback) {
	var t = this;
	var Games = {
		"Limit Hold'em": "holdem",
		"NL Hold'em": "holdem",
		"PL Omaha-5": "omaha5",
		"Limit Omaha-5": "omaha5",
		"PL Omaha": "omaha"
	};
	gametype = Games[t.Game];
	var out = {};
	
	
	for (z = 0; z < data.length; z++) {
		var row = data[z];
		if (row.data != "" && row.data != false) {
			var ex1 = t.cleanPosition(row.position1);
			var ex2 = t.cleanPosition(row.position2);
			var ex3 = t.cleanPosition(row.position3);
			var ex4 = t.cleanPosition(row.position4);
			var ex5 = t.cleanPosition(row.position5);
			if(row.data)
			{
			out[row.username.toLowerCase()] = {
				"cards": bcore.clearplayercards([ex1, ex2, ex3, ex4, ex5]),
				"_cards": [ex1, ex2, ex3, ex4, ex5],
				"helper": row.data,
				"player": row.username.toLowerCase(),
				"chelper": ""
			}
			DBG("Player : " + row.username.toLowerCase() + "  Cards : " + JSON.stringify(bcore.clearplayercards([ex1, ex2, ex3, ex4, ex5])), {"type": "sethand","Date":true});
			}else{
				
					DBG("data null " + row.username.toLowerCase() , {"type": "sethand","Date":true});
				
			}
		}
	}
	
	/*
	for(let pl in t.Players)
	{
		
		if(t.Players[pl].CLType != "Bot" && typeof out[t.Players[pl].Player] == "undefined" && t.dealed.indexOf(pl) > -1 )
		{
			out[t.Players[pl].Player] = {
				"cards": [53,53,53,53,53,53,53],
				"helper": "Disconnected",
				"player": t.Players[pl].Player.toLowerCase(),
				"chelper": ""
			}
			
		}
		
		
	}*/
	callback(out);
}
mkTable.prototype.converterShowloop = function(data, flop, gametype, i, callback) {
	var t = this;
	var kes = Object.keys(data);
	var allhands = true;
	if (i < kes.length) {
		var row = data[kes[i]];
		for (z = 0; z < row.cards.length; z++) {
			row.cards[z] = row.cards[z] == "-0" ? 0 : row.cards[z];
			row.cards[z] = row.cards[z] + 1;
		}
		AnalClass.getfinalhand(row.cards, flop, gametype, function(handanal) {
			var cnhelper = row.helper.replace("You have ", "");
			row.chelper = handanal.helper;
			row.handpoint = handanal.handpoint;
			row.point = handanal.point;
			var compare = cnhelper == handanal.helper;
			i++;
			t.converterShowloop(data, flop, gametype, i, callback);
		});
	} else {
		callback(data);
	}
}
mkTable.prototype.CheckHandsLoop = function(pls, i, callback) {
	var t = this;
	
	if (config.debug.tables) {
	}
			
	if (i < pls.length) {
		//////////////////("this pls",pls,i,pls[i]);
		//console.log("inp",pls[i].Player, pls[i].Cards ,t.flop, t.Games[t.Game]);
		AnalClass.getfinalhand(pls[i]._Cards, t.flop, t.Games[t.Game], function(handanal) {
			//console.log("helper set",handanal);
			t._players[pls[i].Seat].Helper = handanal.helper;
		//	t.Players[pls[i].Seat].point = handanal.point;
		//	t.Players[pls[i].Seat].handpoint = handanal.handpoint;
		});;
		i++;
		t.CheckHandsLoop(pls, i, callback);
/*		try{
		}catch(g)
		{
			////////("CheckHandsLoop",pls[i].Cards, t.flop, t.Games[t.Game]);
			i++;
			t.CheckHandsLoop(pls, i, callback);
		}*/
	} else {
		callback();
	}
}
mkTable.prototype.ClearCards = function(cards) {
	var out = [];
	for(i=0;i<cards.length;i++)
	{
		if(cards[i] > 0)
		{
			out.push(cards[i]);
		}
		
	}
	return out;
}
mkTable.prototype.CheckHands = function(callback) {
	var t = this;
	var out = [];
		//////////////("settinng",t.state,t.hands[t.handnumber][t.state][1]);
	if(typeof t.hands[t.handnumber] == "undefined" || typeof t.hands[t.handnumber][t.state] == "undefined")
	{
		callback();
		return true;
		
	}
	if(t.hands[t.handnumber][t.state][1] == false)
	{
		t.hands[t.handnumber][t.state][1] = true;
		//console.log("\n---------\n---------\n---------seted",t.hands[t.handnumber][t.state],t.state);
		for (pl in t._players) {
			//console.log("thiiii",t._players[pl]);
					t._players[pl].Cards = bcore.clearplayercards(t._players[pl]._Cards);
					out.push(t._players[pl]);
			
			
		}
		//console.log("this check hadnd",out);
		t.CheckHandsLoop(out, 0, function() {
			var states = ["Preflop", "Flop", "Turn", "River"];
			DBG("Hand Helper seted : " + states[t.state] + "  | Hand Number : " + t.handnumber, {"type": "sethand","Date":false});
			t.calculate(function() {
				if (config.debug.tables) {
					DBG.table(t._players, [  "Player","Helper", "Cards"]);
				}
				callback();
			});
		});
		
	}else{
		callback();
		//////////////("seted already",t.hands[t.handnumber][t.state],t.state);
	}
}
mkTable.prototype.checkSitoutBots = function() {
	var t = this;
	for (var st in t.Players) {
		var pl = t.Players[st];
	}
}
mkTable.prototype.getHelper = function(data, i, callback) {
	var t = this;
	if (typeof config.flopRequest && config.flopRequest) {
		t.SetHandsFlop(callback);
		return;
	}
	t.SetHandsFlop(function() {
		if (t.hands[t.handnumber][t.state.toString()][1] == false) {
			var kes = Object.keys(data);
			if (i < kes.length) {
				var row = data[kes[i]];
				var Games = {
					"Limit Hold'em": "holdem",
					"NL Hold'em": "holdem",
					"PL Omaha-5": "omaha5",
					"Limit Omaha-5": "omaha5",
					"PL Omaha": "omaha"
				};
				gametype = Games[t.Game];
				if (row.Status != "empty" && row.Action == 0 && row.Cards[0] != 0) {
					handanal = AnalClass.getfinalhand(row.Cards, t.flop, gametype);
					DBG("Set Show hand helper : Seat " + row.Seat + " | Player : " + row.Player + " | State : " + t.state, "gray");
					DBG("Cards : " + JSON.stringify(row.Cards) + " | Cards 2 : " + JSON.stringify(bcore.clearplayercards(row.Cards)), "red2", true, true);
					DBG("Get Helper | Player: " + row.Player + " | MV Helper " + row.Helper.replace("You have ", ""), "red2", true, true);
					DBG("Get Helper | Player: " + row.Player + " | AN Helper " + handanal.helper, "red2", true, true);
					DBG("------------------------------------------------------", "red2", true, true);
					DBG("ANAL Helper | Player: " + row.Player + " |  Hand Point : " + row.handpoint + " | Point : " + handanal.point, "green", true, true);
					DBG("Flop : " + JSON.stringify(t.flop) + " | Flop 2 : " + JSON.stringify(bcore.clearplayercards(t.flop)), "red", true, true);
					row.handhelper = handanal.helper;
					row.handpoint = handanal.handpoint;
					row.point = handanal.point;
				}
				i++;
				t.getHelper(data, i, callback);
			} else {
				t.calculate(function() {
					t.hands[t.handnumber][t.state.toString()][1] = true;
					callback(data);
				});
			}
		} else {
			DBG("Seted already " + t.ID + " HN : " + t.handnumber + " | State : " + t.state, "red");
			callback(data);
		}
	});
}
mkTable.prototype.getShowData = function(callback) {
	var t = this;
	if (t.showapi != false) 
	{
					
		if(t.BB >= config.showamount ||  1== 1)
		{			
			//let showAdd = t.showapi + t.ID + "&type=" + t.Type;
			let showAdd = t.showapi + t.ID + "&type=" + t.Type;
			////("show adres",showAdd);
			DBG("get show hand from  : " + showAdd,  {"type": "sethand","Date":false,"color":"white"});
			requestify.get(showAdd).then(function(response) {
				var body = response.getBody();
				if (body != ""){ 
				try{
				var res = JSON.parse(body);
				//////////(res)
				callback(res);
				}catch(err){
					callback([]);
				}
				}else{
					callback([]);
				}
			}).fail(function (response) {
				callback([]);
   
  });
		}else{
			callback([]);
			
		}
	} else {
		callback([]);
		
		/*callback([{"left1":"557px","position1":"-2392px 0px","left2":"571px","position2":"-2392px 0px","left3":"585px","position3":"-2392px 0px","left4":"599px","position4":"-2392px 0px","left5":"613px","position5":"-2392px 0px","username":"farshad","tableName":"R00 OM5 250-500 (5)","action":"","data":"a Pair of Eights +T96"}]);*/
		/*callback([{"left1":"557px","position1":"-2208px 0px","left2":"571px","position2":"-414px 0px","left3":"585px","position3":"-1196px 0px","left4":"599px","position4":"-552px 0px","left5":"613px","position5":"-1104px 0px","username":"farshad","tableName":"R00 OM5 250-500 (5)","action":"","data":"a Pair of Eights +T96"}]);*/
	}
	return;
}
mkTable.prototype.getHands = function(callback) {
	var t = this;
	callback(t.hands[t.handnumber]);
}
mkTable.prototype.seatoutBot = function(seat, cl, callback) {
	var t = this;
						
	cl.seatOut(t.ID, function() {
		t.Players[seat].sitOut();
		
		DBG("Bot sitout : " + cl.Player.toLowerCase(), {"type":"botseat","player":t.Player,"Date":true});

	
		//bcore.WaitingLogout.push(cl.Player);
		//////////(bcore.WaitingLogout);
		if (config.debug.tables2) {
		  DBG.table(t.Players, ["Player", "Status", "Action","Seat"]);
		}
	});
}
mkTable.prototype.getEmptySeat = function(player,callback,expect) {
	var t =this;
	var emptys = [];
	//////console.info("expect", typeof expect,expect);
	expect = typeof expect != "undefined" && expect != false ? expect : 0;
	//////console.info("expect",expect);
	for (st in t.Players) {
		if (t.Players[st].Status == "empty" && st != expect) {
			emptys.push(st);
		}
	
	}
	var Seat = -1;
	if (emptys.length < 1) {
		
		var Seat = -1;
		DBG("No EMPTY SEAT LOGOUT IN 3 Seconds" ,{"type":"botseat","player":player,"Date":true});
		//DBG("Player : " +cl.Player + "  - Table : "+ t.ID ,{"type":"botseat","player":t.Player,"Date":false});
		//bcore.WaitingLogout[cl.Player.toLowerCase()] = "emptyseat";

		//DBG("Logout No EMPTY SEAT - Player : " +cl.Player,{"type":"botseat","player":t.Player,"Date":true,"Colro":"gray"});
		DBG("Table : "+ t.ID ,{"type":"botseat","player":player,"Date":false,"Colro":"gray"});
		

			
		
	}else{
		if (emptys.length > 1) {
			var rand = Math.floor((Math.random() * (emptys.length - 1)) + 1);
			var Seat = emptys[rand];
		} else {
			var Seat = emptys[0];
		}
	}
//////console.info("getEmptySeat",Seat);
	callback(parseInt(Seat));
	
	
}
mkTable.prototype.seatBot = function(row,callback) {
	var t = this;

		t.Players[row.Seat].Sit({"Player":row.Player,"Chips":row.Chips,"CLType":"Bot"},function()
		{
					
			if(config.debug.updatetable)
			{
				DBG("Sited bot", {
					"type":"updatetable",
					"Color": "green"
				});
				DBG.table(t.Players,["Player","Status"]);
				
			}
			callback(true);
			
			
		});
	
	/*
	else{
			
					
			callback(false);
			

			//////////("siting",Seat,t.ID,cl.Player);
			settings.buyin = t.BuyinMin;
			DBG("Sitting " +cl.Player + "  - : "+ t.ID + " - Seat " + Seat,{"type":"botseat","player":t.Player,"Date":true,"details":true});
			DBG(JSON.stringify(settings),{"type":"botseat","player":t.Player,"Date":true,"details":true,"Color":"yellow"});
			cl.Seat(t.ID, Seat, settings, function(pl) {
				
				t.Players[Seat].setPlayer({
					"Status":"Playing",
					"Player": pl,
					"Chips": settings.buyin,
					"Action": 0,
					"CLType": "Bot"
				});
				//////////("BOt seated",pl);
				if (config.debug.tables2) {
				  DBG.table(t.Players, ["Player", "Status", "Action","Seat"]);
				}
				callback();
			});
		}
		*/
}
mkTable.prototype.SeatHand = function() {
	var t = this;
	if (typeof t.hands[tbs.handnumber] == "undefined") {}
}
module.exports = mkTable; 