var request = require("request");
//var config = require("./config");
var apiPass  =config.APIPass;
var url = config.APIURL + config.APIKey;

	
exports.mvapi = function(params, callback) {
	
	var dt = {
		url: url,
		form: params
	};
	//console.log(dt);
	var jsonData = {};
	var le = {};
	le.Password = apiPass;
	le.JSON = "Yes";
	for (var attrname in le) {
		params[attrname] = le[attrname];
	}
	
	request.post(dt, function(err, httpResponse, body) {
		//console.log("bo",body);
		try{
			jsonData = JSON.parse(body);
			callback(jsonData);
			return jsonData;
		}catch(g){
			console.log(g);
			//console.log("mvapi",body);
		}
	});
}
