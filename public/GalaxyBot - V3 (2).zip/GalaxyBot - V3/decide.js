actions = require("./actions.js");
utils = require("./utils.js");


let decideomahaout = require("./decideomahaout.js");

let decideholdemout = require("./decideholdemout.js");
function getDecideType(user) {
    const alphaVal = (user) => user.toLowerCase().charCodeAt(0) - 97 + 1;
    const dur = 24;

    const d = new Date();
    let getHours = d.getHours();

    var alpha = alphaVal(user);
    if (alpha < 0) {
        alpha = alpha + 77;
    }
    alpha = alpha - getHours + 24;
    alpha = alpha % dur;

    if (getHours >= alpha && getHours <= alpha + 2) {
        //console.log(user, alpha, getHours);
        return true;
    }
    return false;
}

function checkBankStat(obj) {
    var rest = obj.Balance.Total;
    var winner = rest > 60000000 ? true : false;
    var looser = rest < 50000000 ? true : false;
    if (winner) {
        return 1;
    }
    if (looser) {
        return -1;
    }
    return 0;
}
function decide() {}



	// request Time 
	// bcore.Clients[obj.Player.toLowerCase()].requestTime(obj.tablename,()=>{});

   

	// showCard
	// bcore.Clients[obj.Player.toLowerCase()].Tables[obj.tablename].showCard = true;

   




decide.getDecide = function (obj, callback) {
    //console.log(JSON.stringify(obj));
    var typeno = obj.convertedCards.filter((d) => d != "15c" && d != "1");
    //console.log(typeno);
	
    if (typeno.length == 2) {
        //console.info("ho");
        if (getDecideType(obj.Player) || checkBankStat(obj) == -1) {
            decideholdemout.getDecide(obj, callback);
            return false;
        } else {
            decideholdemout.getDecide(obj, callback);
            return false;
        }
    } else {
        //console.info("om");
        if (getDecideType(obj.Player) || checkBankStat(obj) == -1) {
            decideomahaout.getDecide(obj, callback);

            return false;
        } else {
            decideomahaout.getDecide(obj, callback);

            return false;
        }
    }
};
module.exports = decide;
