const WebSocket = require('ws');
//flopcore = require("./flopcore");
//flopcoreholdem = require("./flopcoreholdem");


let adminClient = function (data) {
    let t = this;
    t.ws = data.ws;
    t.username = data.username;
    return t;
}
adminClient.prototype.sendCommand = function (req) {
    let t = this;
    ////////("sendCommand",req,t.username,typeof t.ws,typeof t.ws.send);
    if (typeof t.ws != "undefined" && typeof t.ws.send == "function") {

        t.ws.send(JSON.stringify(req));
    } else {
        //////("here");
    }
}

let BCORE = function (conf) {
    var t = this;
    t.fileVersion = 15;
    t.packetPort = conf.packetPort;
    t.version = conf.Version;
    t.adminacc = conf.adminAcc;
    t.PLS = conf.BotList;
    t.showapi = conf.showapi;
    t.Clients = typeof conf.Clients != "undefined" ? conf.Clients : {};
    t.WaitingLogout = typeof conf.WaitingLogout != "undefined" ? conf.WaitingLogout : {};
    t.Tables = typeof conf.Tables != "undefined" ? conf.Tables : {};
    t.Tournaments = typeof conf.Tournaments != "undefined" ? conf.Tournaments : {};
    t.wsclient = typeof conf.wsclient != "undefined" ? conf.wsclient : false;
    t.commands = typeof conf.commands != "undefined" ? conf.commands : [];
    t.loaded = typeof conf.loaded != "undefined" ? conf.loaded : false;
    t.wss = typeof conf.wss != "undefined" ? conf.wss : false;
    t.runBots = typeof conf.runBots != "undefined" ? conf.runBots : true;
    t.reset = typeof conf.reset != "undefined" ? conf.reset : false;
    t.SessionKey = typeof conf.SessionKey != "undefined" ? conf.SessionKey : false;
    t.PNum = typeof conf.PNum != "undefined" ? conf.PNum : 0;
    t.Seats = typeof conf.Seats != "undefined" ? conf.Seats : {};
    t.monitor = typeof conf.monitor != "undefined" ? conf.monitor : {};
    t.monitorStatus = typeof conf.monitorStatus != "undefined" ? conf.monitorStatus : false;
    t.monitorSocket = typeof conf.monitorStatus != "undefined" ? conf.monitorStatus : false;
    t.finOut = typeof conf.finOut != "undefined" ? conf.finOut : {}
    t.finOutCounter = typeof conf.finOutCounter != "undefined" ? conf.finOutCounter : 0;
    t.spendedTime = typeof conf.spendedTime != "undefined" ? conf.spendedTime : 0;
    t.spendedTourTime = typeof conf.spendedTourTime != "undefined" ? conf.spendedTourTime : 0;
    t.botTimers = typeof conf.botTimers != "undefined" ? conf.botTimers : [];
    t.botTourTimers = typeof conf.botTourTimers != "undefined" ? conf.botTourTimers : [];
    t.tourPlayers = typeof conf.tourPlayers != "undefined" ? conf.tourPlayers : [];
    t.currendAdmin = typeof conf.currendAdmin != "undefined" ? conf.currendAdmin : "";
    t.transferList = [];
    t.transferNum = 0;
    t.transferWS = false;

}

BCORE.prototype.replaceBots = function (list, i, callback) {
    //
    ////////(i,list.length);
    if (i < list.length) {
        let row = list[i];
        //////('rrhhhhhrr',row);

        bcore.createBot(row, (newBot) => {
            //////(newBot);


        });
        i++;
    } else {
        callback();

    }
}
BCORE.prototype.replaceLoop = function (list, botList, i, out, callback) {

    if (i < list.length) {
        let tbl = list[i];
        maven.mvapi({
            "Command": "RingGamesPlaying",
            "Name": tbl
        }, (res2) => {

            if (res2.Count > 0) {
                for (let pl of res2.Player) {
                    if (botList.indexOf(pl) > -1) {

                        out.push({
                            "Player": pl,
                            "Table": tbl
                        });

                    }
                }
            }

            i++;
            bcore.replaceLoop(list, botList, i, out, callback);

        });

    } else {
        callback(out);

    }
}
BCORE.prototype.sendResponse = function (res) {
    var t = this;
    res.ID = t.SessionKey;
    t.PNum++;
    res.PNum = bcore.PNum;
    var msg = JSON.stringify(res);
    t.wsclient.send(msg);
}
BCORE.prototype.getRandomBot = function (callback) {
    var t = this;
    var pl = t.PLS.splice(0, 1);
    callback(pl[0]);
}
BCORE.prototype.IncBot = function (ID, callback) {
    var t = this;
    t.addBot(ID, function (cl) {
        t.Clients[cl.Player.toLowerCase()] = cl;
        tbs = t.getTable(ID.Table);
        tbs.seatBot(cl, callback);
    });
}
BCORE.prototype.getDecide = function (ID, callback) {
    var tblstate = ID.state;
    flopcore.getFlopPoint(bcore.clearplayercards(ID.usercards), bcore.clearplayercards(ID.flopcards), tblstate, ID.helper, function (checkedpoint) {
        if (ID.Amounts.callAmount > 0) {
            deciding = Flopcore.pointToDecide("call", checkedpoint, ID.Amounts);
            var amount = val * ID.Amounts.myBB;
            var doit = deciding.doit;
        } else {
            var doit = "raise";
            var val = parseFloat(checkedpoint[0]);
            var doit = val > 0 ? "Raise" : "Check";
            var amount = val * ID.Amounts.myBB;
            if (amount > ID.maxraise) {
                amount = ID.maxraise;
            }
        }
        var ret = {
            "Button": doit,
            "Amount": amount
        };
        callback(ret);
    });
}
BCORE.prototype.getTable = function (ID) {
    var t = this;
    if (typeof t.Tables[ID] != "undefined") {
        return t.Tables[ID];
    } else {
        return false;
    }
}
BCORE.prototype.Preload = function (callback) {
    var t = this;
    DBG(" ", {
        "type": "system",
        "Date": false
    });
    DBG("Loading .... ", {
        "type": "system",
        "Date": false
    });
    DBG(" ", {
        "type": "system",
        "Date": false
    });

    if (t.wsclient == false) {
        //t.wsclient = true;
        maven.mvapi({
            "Command": "ConnectionsList",
            "Fields": "IP,SessionID,PC,Status"

        }, (rs) => {
            /*
            for(let i = 0;i<rs.Connections;i++){

            ////////////(rs.IP[i]);
            if(rs.IP[i] == "127.0.0.1" && rs.PC[i].substring(0,2) == "BT" ){
            maven.mvapi({
            "Command": "ConnectionsTerminate",
            "SessionID":rs.SessionID[i]

            },(rs2)=>{




            });



            }

            }*/
            setTimeout(() => {

                maven.mvapi({
                    "Command": "RingGamesList",
                    "Fields": "Name,Game,Seats,SmallBlind,BigBlind,BuyInMin,BuyInMax",
                }, function (result) {

                    for (let i = 0; i < result.RingGames; i++) {
                        var tbs = t.getTable(result.Name[i]);
                        if (tbs == false) {
                            //	//////////////(result.Game[i]);
                            t.Tables[result.Name[i]] = new mkTable({
                                "ID": result.Name[i],
                                "Type": "R",
								"Game": result.Game[i],
                                "Seats": result.Seats[i],
                                "Playing": 0,
                                "Waiting": 0,
                                "bots": {},
                                "state": 0,
                                "flop": [0, 0, 0, 0, 0],
                                "total": 0,
                                "SB": result.SmallBlind[i],
                                "BB": result.BigBlind[i],
                                "BuyinMin": result.BuyInMin[i],
                                "BuyinMax": result.BuyInMax[i],
                                "hands": {
                                    "rrrr": "eeee"
                                },
                                "handnumber": false,
                                "showapi": t.showapi
                            });
                        } else {
                            //tbs.setVal("Playing", dt.Players[i]);
                            //tbs.setVal("Waiting", dt.Waiting[i]);
                        }
                    }
                    //////////("Preload done");


                    bcore.loadTournaments(callback);

                });

            }, 1000);

            //dad(0);

        });

    } else {
        callback();
    }
}
BCORE.prototype.loadTournaments = function (callback) {
    //callback();
	bcore.Tournaments ={}
    maven.mvapi({
        "Command": "TournamentsList",
        "Fields": "Name,Status,StartTime",
    }, (resss) => {
        for (let i = 0; i < resss.Name.length; i++) {
if (resss.Status[i] != "Offline" ) {
          
//let d = Date.parse(resss.StartTime[i])-3600000;

let d = Date.parse(resss.StartTime[i]) -180000;

            bcore.Tournaments[resss.Name[i]] = new tourClass({
                "name": resss.Name[i],
                "StartTime": resss.StartTime[i],
                "runTime": d,
                "status": resss.Status[i]
            });
}
        }

        callback();

    });

}
BCORE.prototype.loopCards = function (dt, i, callback) {
    var t = this;
    var tbs = t.getTable(dt.Table);
    if (i < tbs.Seats) {
        var pl = tbs.Players[(i + 1)];
        if (pl.Status != "empty") {
            var cards = pl.Cards;
            var Com = {
                "Command": "Cards",
                "Table": dt.Table,
                "Type": "R",
                "Card1": cards[0],
                "Card2": cards[1],
                "Card3": cards[2],
                "Card4": cards[3],
                "Card5": cards[4],
                "Card6": cards[5],
                "Card7": cards[6],
                "Seat": pl.Seat,
                "Point": pl.point,
                "Place": pl.place,
                "handpoint": pl.handpoint,
                "Helper": pl.Helper
            }; ;
            t.wsss.send(JSON.stringify(Com));
        }
        i++;
        t.loopCards(dt, i, callback);
    } else {
        callback();
    }
}
BCORE.prototype.LoadCommand = function (ws, callback) {
    var t = this;
    t.LoadCommandLoop(ws, 0, function () {
        t.wss = ws;
        callback();
    });
};
BCORE.prototype.LoadCommandLoop = function (ws, i, callback) {
    var t = this;
    var list = t.commands;
    if (i < list.length) {
        setTimeout(function () {
            var row = list[i];
            ws.send(JSON.stringify(row));
            i++;
            t.LoadCommandLoop(ws, i, callback);
        }, 100);
    } else {
        callback();
    }
}
BCORE.prototype.addBot = function (ID, callback) {
    var t = this;
    t.getRandomBot(function (pl) {
        DBG("Get BOT : " + pl, {
            "type": "botlogin",
            "Date": true
        });
        t.loginBiot(pl, function (cl) {
            var newbot = new bot({
                "Player": pl,
                "SessionKey": cl.SessionKey,
                "ws": cl,
                "ID": cl.mID
            });
            DBG("Login BOT : " + pl, {
                "type": "botlogin",
                "Date": true
            });
            callback(newbot);
        });
    });
}
BCORE.prototype.CleanCards = function (cards) {
    var c = cards.split(",");
    var out = [];
    for (d = 0; d < c.length; d++) {
        if (c[d] != "") {
            out.push(c[d]);
        }
    }
    return out;
}
BCORE.prototype.GetBotLogsLoop = function (res, i, out, callback) {
    var t = this;
    if (i < res.length) {
        var row = res[i];
        //var car = t.CleanCards(row.playercards);
        //var flo = t.CleanCards(row.flopcards);
        flopcore.getFlopPoint(row.playercards.split(","), row.flopcards.split(","), row.state, row.helper, row.gametype, function (checkedpoint, logparams) {
            ////////////////(row.state,checkedpoint, logparams);
            row.rechecked = (row.state == 0 ? logparams : checkedpoint);
            i++;
            t.GetBotLogsLoop(res, i, out, callback);
        });
    } else {
        callback(out);
    }
}
BCORE.prototype.GetBotLogs = function (ws, search, callback) {
    var t = this;
    var sql = "select * from pk888_botlogs " + search + " order by id desc limit 100";
    cn.query(sql, function (error, results, fields) {
        t.GetBotLogsLoop(results, 0, [], function (out) {
            var ht = '<div class="grid_header" style="color: rgb(54, 48, 37); background-color: rgb(195, 186, 167); border-color: rgb(158, 143, 113); visibility: inherit;"><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Player</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Cards</div><div style="width: 110px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Flop</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Helper</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Hand Number</div><div style="width: 50px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Point</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Pot</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">BB</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Rest</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Button2</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">State</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Points</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Decide</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Amount</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Refresh</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Recheck</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">New Decide</div></div><form id="myform"><div class="grid_data" id="grid_data" style="overflow-y:scroll;visibility: inherit;"><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color: ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].playername + '</div>';
            }
            ht += '</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].playercards + '</div>';
            }
            ht += '</div><div style="width: 110px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].flopcards + '</div>';
            }
            ht += '</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].helper + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].handnumber + '</div>';
            }
            ht += '</div><div style="width: 50px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].analedpoint + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].mypot + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].mybb + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].myrest + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].callamount + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">' + results[i].button2 + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + (results[i].state == 0 ? "Preflop" : (results[i].state == 1 ? "Flop" : (results[i].state == 2 ? "Turn" : "River"))) + '</div>';
            }
            ht += '</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].points + '</div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';"><span style="display:block;width: 70px;height: 40px;display: block;text-align: center;font-weight: bold;font-size: 19px;color: ' + (results[i].doit == "Check" ? '#fff' : (results[i].doit == "Raise" ? "#ffa700" : (results[i].doit == "Fold" ? "red" : 'green'))) + ';">' + results[i].doit + '</span></div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';">&nbsp;&nbsp;&nbsp;' + results[i].amount + '</div>';
            }
            ht += '</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';position:relative !important;" ><a class="refresh" style="display: block;width: 100px;border: 1px solid;position: absolute;left: 0;height: 29px;top: 14px;text-align: center;line-height: 29px;cursor: pointer;" data-id="' + results[i].id + '">Refresh</a></div>';
            }
            ht += '</div><div style="width: 80px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';" id="s' + results[i].id + '" class="recheck">&nbsp;&nbsp;&nbsp;' + results[i].rechecked + '</div>';
            }
            ht += '</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">';
            for (i = 0; i < results.length; i++) {
                ht += '<div style="height: 50px; line-height: 50px; font-weight: normal; color:rgb(65, 55, 45); background-color:  ' + (results[i].button2 == "Check" ? "#ddd382" : "#14ff00") + ';" id="d' + results[i].id + '" class="redecide">&nbsp;&nbsp;&nbsp;</div>';
            }
            ht += '</div></div></form>';
            bcore.sendMonitor({
                "Command": "GetBotLogs",
                "str": str,
                "Type": "Terminated"
            });

            callback(results);
        });
    });
}
BCORE.prototype.getDecide_JSON = function (ID, callback) {

    var t = this;
    var callValue = ID.points.callValue;
    var raiseValue = ID.points.raiseValue;
    var reraiseValue = ID.points.reraiseValue;
    ////////////////(ID)
    if (ID.Button2 == "Check") {
        if (raiseValue > 0) {
            var decide = "Raise";
            var amount = raiseValue * ID.Pot;
        } else {
            var decide = "Check";
            var amount = 0;
        }
    } else {
        if (ID.Button2 == "Call") {
            if (ID.Call <= (callValue * ID.Pot)) {
                if (reraiseValue > 0) {
                    var decide = "Raise";
                    var amount = reraiseValue * ID.Pot;
                } else {
                    var decide = "Call";
                    var amount = 0;
                }
            } else {
                if (ID.Chips <= (ID.Pot / 10) || ID.Pot == 0) {
                    var decide = "Call";
                    var amount = 0;
                } else {
                    var decide = "Fold";
                    var amount = 0;
                }
            }
        }
    }
    var ret = {
        "Button": decide,
        "Amount": amount
    };
    callback(ret);
}
BCORE.prototype.refreshBotLogs = function (id, ws, callback) {
    var t = this;
    var sql = "select * from pk888_botlogs where id='" + id + "' ";
    cn.query(sql, function (error, results, fields) {
        var row = results[0];
        //////////////("ca",row.playercards);
        var car = row.playercards.split(",");
        var flo = row.flopcards == "" ? [] : row.flopcards.split(",");
        //////////////("ca2",car, flo, row.state, row.helper);

        flopcore.getFlopPoint(car, flo, row.state, row.helper, row.gametype, function (checkedpoint, logparams) {
            //////////////("this",checkedpoint);
            var ht = row.state == 0 ? logparams : checkedpoint;
            var dt = {
                "Call": row.callamount,
                "Chips": row.myrest,
                "Pot": row.mypot,
                "Button2": row.button2,
                "points": {
                    "callValue": ht[0],
                    "raiseValue": ht[1],
                    "reraiseValue": ht[2]
                }

            };
            t.getDecide_JSON(dt, function (ret) {
                if (typeof logparams.logs != "undefined") {
                    ////////////////////("details",logparams.logs.details);
                    ////////////////////("Return",ret);
                    ////////////////////("points",ht);

                }
                ws.send(JSON.stringify({
                        "Command": "refreshBotLogs",
                        "id": id,
                        "ht": JSON.stringify(ht),
                        "deci": "&nbsp;&nbsp;&nbsp;" + ret.Button + "&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;" + (ret.Button == "Raise" ? ret.Amount : row.callamount)
                    }));
            });
        });
    });
}
BCORE.prototype.getTimer = function (i) {

    if (i <= 0 || isNaN(parseInt(i))) {
        return "00:00:00";

    }
    let mins = i % 3600;
    let hours = (i > 3600 ? ((i - mins) / 3600) : 0);

    let sec = mins > 60 ? mins % 60 : mins;

    let minutes = mins > 60 ? ((mins - sec) / 60) : 0;

    sec = sec < 10 ? "0" + sec : sec;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    hours = hours < 10 ? "0" + hours : hours;

    return hours + ":" + minutes + ":" + sec;

}
BCORE.prototype.addClient = function (ws, res, callback) {

    if (typeof adminclients[res.username] == "undefined") {
        adminclients[res.username] = new adminClient({
            "ws": ws,
            "username": res.username
        });
    } else {
        adminclients[res.username].ws = ws;

    }
    callback(adminclients[res.username]);
}
BCORE.prototype.monitorOff = function (callback) {
    bcore.turnOnMonitor("off");

    callback();
}
BCORE.prototype.monitorOn = function () {
    let t = this;
    //////("Turn on monitor . monitorStatus : ",t.monitorStatus);
    if (t.monitorStatus == false) {
        t.monitorStatus = "trying";
        t.monitorSocket = new WebSocket.Server({
            port: config.Port
        }, function () {

            t.monitorStatus = true;
            //////("monitor turned on . monitorStatus : ",t.monitorStatus);


        });
        t.monitorSocket.on('connection', function connection(ws, req) {
            ws.on('close', function incoming(message) {});
            ws.on('open', function incoming(message) {
                t.monitorStatus = true;
                //////("monitor turned on . monitorStatus : ",t.monitorStatus);

            });
            ws.on('message', function incoming(message) {
                var res = JSON.parse(message);
                //////////////(res.Response);
                switch (res.Response) {
                case "adminSessionOLD": {
                        let sessionID;
                        if (typeof adminclients[res.username] != "undefined") {

                            if (!adminclients[res.username].sessionID) {
                                sessionID = "To player2";

                            } else {
                                sessionID = adminclients[res.username].sessionID;

                            }
                        } else {

                            sessionID = "To player";
                            //////("here2",sessionID);
                        }
                        bcore.sendToAdmins(res.username, {
                            "Command": "adminSession",
                            "sessionID": sessionID
                        });

                    }
                    break;
                case "adminSession": {
                        bcore.addClient(ws, res, (CL) => {

                            bcore.sendToAdmins(res.username, {
                                "Command": "adminSession",
                                "sessionID": res.username
                            });
                            ////////("Sakt",Object.keys(adminclients));

                        });
                    }
                    break;
                case "Session": {
                        bcore.LoadCommand(ws, function () {});

                    }
                    break;
                case "GetBotLogs": {

                        bcore.GetBotLogs(adminclients["loger"], "", function () {});
                    }
                    break;
                case "turnOffMonitor": {
                        bcore.monitorOff(() => {
                            //	bcore.sendToAdmins(res.username,{"Command":"adminSession","sessionID":res.username});

                            //	delete adminclients["farshad"];
                            //wss=false;


                        });

                    }
                    break;
                case "refreshBotLogs": {
                        bcore.refreshBotLogs(res.id, adminclients["loger"], function () {});
                    }
                    break;
                case "incbot": {
                        bcore.IncBot(res, function () {});

                    }
                    break;
                case "RequestSeat": {
                        //////////////////("req",res.Seat,res.Table);
                        bcore.Seats[res.Table] = res.Seat;
                        ws.send(JSON.stringify({
                                "Command": "Invite",
                                "Table": res.Table,
                                "Type": "R",
                                "Timer": 30000,
                                "MinBuyIn": 400,
                                "MaxBuyIn": 2000000,
                                "DefBuyIn": 1200,
                                "Balance": 59990000620,
                                "Primary": "Yes",
                                "Rathole": "No"
                            }));
                    }

                    break;
                case "RSVP": {

                        if (res.BuyIn > 0) {
                            bcore.getRandomBot(function (pl) {
                                bcore.addBot({
                                    "Player": pl,
                                    "Table": res.Table,
                                    "Res": res
                                }, function (cl) {
                                    setTimeout(function () {
                                        bcore.seatBot(cl, function () {});
                                    }, 2000);
                                });
                            });
                        }

                    }
                    break;
                case "RSVP2": {

                        ////////////////("req",res);

                    }
                    break;

                case "Login":
                case "terminateAll": {

                        bcore.terminateAll();

                    }
                    break;
                case "terminateBot": {

                        bcore.currendAdmin = res.username;

                        bcore.terminateBot(res.Player);

                    }
                    break;
                case "sitoutBot": {

                        bcore.currendAdmin = res.username;

                        bcore.sitoutBot(res.Player, res.Table);

                    }
                    break;
                case "SearchLog": {

                        bcore.GetBotLogs(adminclients["loger"], " where handnumber like '%" + res.val + "%' ", function () {});

                    }
                    break;
                case "loadtourSettings": {
                        bcore.currendAdmin = res.username;
                        bcore.loadtourSettings(1);
                    }

                    break;
                case "loadbotSettings": {
                        bcore.currendAdmin = res.username;
                        bcore.loadbotSettings(1);
                    }

                    break;
                case "loadHour": {
                        bcore.loadHour(res.hour);
                    }

                    break;
                case "loadTours": {
                        bcore.loadTours(res.hour);
                    }

                    break;
                case "editJson": {
                        bcore.editJson(res);
                    }

                    break;
                case "loadjson": {

                        var ret = "";

                        if (res["state"] > -1) {
                            var data = Flopcore.keys[res["state"]][res["colwin"]];

                            state = res['state'];

                            if (state == 0) {
                                ret += '<div class="grid_header" style="color: rgb(54, 48, 37); background-color: rgb(195, 186, 167); border-color: rgb(158, 143, 113); visibility: inherit;"><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div></div>';
                            } else {
                                ret += '<div class="grid_header" style="color: rgb(54, 48, 37); background-color: rgb(195, 186, 167); border-color: rgb(158, 143, 113); visibility: inherit;"><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px;border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113);visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div<div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div></div>';

                            }
                            ret += '<form id="myform"><div class="grid_data" id="grid_data" style="visibility: inherit;">';

                            for (var ke in data) {
                                var dt = data[ke];

                                ret += '<div style="width: ' + (state == 0 ? "145" : "300") + 'px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);">' + ke + '</div>';
                                for (var k in dt) {

                                    ret += '<div style="height: 20px; line-height: 20px; font-weight: normal; color:' + (ke == "Flop" ? "red;" : 'rgb(65, 55, 45);') + ' background-color: rgb(228, 222, 216);">&nbsp;&nbsp;&nbsp;' + k + '</div>';

                                }

                                ret += '<div style="height: 20px; line-height: 20px; font-weight: normal; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div><div style="height: 20px; line-height: 20px;"></div><div style="height: 20px; line-height: 20px;"></div></div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';
                                for (var k in dt) {
                                    var v = dt[k];
                                    ret += '<div style="height: 20px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);"><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;"><input type="text" class="input" style="color: rgb(65, 55, 45); background-color: rgb(228, 222, 216); border: 1px solid rgb(48, 36, 22);" spellcheck="false"  value="' + v[0] + '"  name="' + ke + '[' + k + '][0]"></div></div>';

                                }
                                ret += '<div style="height: 20px; line-height: 20px;"></div><div style="height: 20px; line-height: 20px;"></div></div><div style="width:55px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';

                                for (var k in dt) {

                                    var v = dt[k];
                                    ret += '<div style="height: 20px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);"><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;"><input type="text" class="input" style="color: rgb(65, 55, 45); background-color: rgb(228, 222, 216); border: 1px solid rgb(48, 36, 22);" spellcheck="false"  value="' + v[1] + '"  name="' + ke + '[' + k + '][1]"></div></div>';

                                }

                                ret += '   <div style="height: 20px; line-height: 20px;"></div><div style="height: 20px; line-height: 20px;"></div></div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';
                                for (var k in dt) {
                                    var v = dt[k];
                                    ret += '<div style="height: 20px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);"><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;"><input type="text" class="input" style="color: rgb(65, 55, 45); background-color: rgb(228, 222, 216); border: 1px solid rgb(48, 36, 22);" spellcheck="false" value="' + v[2] + '"  name="' + ke + '[' + k + '][2]"></div></div>';

                                }

                                ret += '<div style="height: 20px; line-height: 20px;"></div><div style="height: 20px; line-height: 20px;"></div></div>';

                            }

                            ret += "</div></form>";

                        } else {
                            ret += '<div class="grid_header" style="color: rgb(54, 48, 37); background-color: rgb(195, 186, 167); border-color: rgb(158, 143, 113); visibility: inherit;"><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px;border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113);visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div<div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div><div style="width: 300px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Property</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Call</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Raise</div><div style="width: 55px; border-right-color: rgb(158, 143, 113); visibility: inherit;">ReRaise</div></div>';

                        }

                        adminclients["jsoneditor"].send(JSON.stringify({
                                "Command": "JsonParams",
                                "ht": ret
                            }));

                    }
                    break;

                case "loadLogin": {
                        let out = [];
                        for (let ccl in bcore.Clients) {
                            for (let tbName in bcore.Clients[ccl].Tables) {
                                let tbb = bcore.Clients[ccl].Tables[tbName];

                                out.push({
                                    Hands: tbb.Hands,
                                    Seat: tbb.Seat,
                                    Played: tbb.played,
                                    Status: tbb.Status,
                                    StatusTime: tbb.StatusTime,
                                    Player: tbb.Player,
                                    tbName: tbName,
                                    SitingOut: tbb.sitingOut,
                                    act: (tbb.actionNum >= Object.keys(tbb.actions[tbb.actionType]).length ? "Done" : Object.keys(tbb.actions[tbb.actionType])[(tbb.actionNum - 1)]),
                                    rem: ((tbb.actionNum >= Object.keys(tbb.actions[tbb.actionType]).length ? 0 : tbb.actions[tbb.actionType][Object.keys(tbb.actions[tbb.actionType])[(tbb.actionNum - 1)]]) - parseInt((Date.now() - tbb.actTime) / 1000))
                                });

                            }
                            ////console.table(,["Hands","Seat","played","Status","StatusTime","Player"]);

                        }
                        let kes = Object.keys(DBG.systemLogs);
                        let logtype = "";

                        let last = parseInt(kes[kes.length - 1]);
                        let checkTimetimer = parseInt((((botData.Settings.checkTime * 60 * 1000) + last) - Date.now()) / 1000);
                        kes = kes.reverse();
                        let nh = 0;
                        for (let ti of kes) {
                            let goo = new Date((parseInt(ti)));
                            let hour = DBG.addZero((goo.getHours() - 1));
                            let mon = DBG.addZero((goo.getMonth() + 1));

                            let year = goo.getFullYear();
                            let day = DBG.addZero(goo.getDate());
                            let minu = DBG.addZero(goo.getMinutes());
                            let secs = DBG.addZero(goo.getSeconds());
                            if (nh < 5) {
                                logtype += '<tr><td>' + mon + '/' + day + ' - ' + hour + ':' + minu + ':' + secs + '</td><td>' + Object.keys(DBG.systemLogs[ti].bots).length + '</td></tr>';
                            }
                            nh++;

                        }
                        let cllist = "";
                        let cll = 0;
                        for (let cl in bcore.Clients) {
                            cll++;
                            let vc = bcore.Clients[cl];
                            let act = (vc.actionNum >= Object.keys(vc.actions[vc.actionType]).length ? "Done" : Object.keys(vc.actions[vc.actionType])[(vc.actionNum - 1)]);
                            ////////("here",vc.actionNum,Object.keys(vc.actions[vc.actionType]).length,vc.actions[vc.actionType],Object.keys(vc.actions[vc.actionType]));
                            let rem = ((vc.actionNum >= Object.keys(vc.actions[vc.actionType]).length ? 0 : vc.actions[vc.actionType][Object.keys(vc.actions[vc.actionType])[(vc.actionNum - 1)]]) - parseInt((Date.now() - vc.actTime) / 1000));
                            cllist += "<tr data-player='" + vc.Player.toLowerCase() + "' ><td>" + vc.Player + "</td><td " + (t.Status == "Terminating" ? ' style="color:red;font-weight:bold;" ' : '') + " >" + vc.Status + "</td><!-- <td class='acting'>" + (rem > 0 ? act + " ( <span class='counter' >" + rem + "</span> ) " : "") + "</td>--><td><a class='btn playerlogs'>Logs</a></td><td>" + (vc.Status != "Terminating" ? "<a class='btn terminateBot'>Logout</a>" : "&nbsp;") + "</td></tr>";

                        }

                        let details = {
                            "all": 10
                        };
                        let loginslist = '<table class="mytable" id="checktimes" style="width:100%"><thead><tr><th style="width:40%">Check Time</th><th style="width:50%">Players</th></tr></thead><tbody>' + logtype + '</tbody></table><div class="transfering" style="display:none;"><span>Transfering...</span></div><div class="nextChcktime"><span style="display: block;float: left;margin-right: 23px;width: 48%;">Next Check Time</span><span style="display: block;float: left;" class="' + (bcore.runBots ? 'myTimer' : '') + '" data-timer="' + checkTimetimer + '">' + bcore.getTimer(checkTimetimer) + '</span></div><div class="cllist" style="height: 440px;overflow-y: scroll;"><table class="mytable" style="width:100%;"><thead><tr><th style="width:10%">Player</th><th style="width:100px;">Status</th><th style="width:70px;">Logs</th><th style="width:70px;">Logout</th></tr></thead><tbody>' + cllist + '</tbody></table></div>';
                        let ret = '<table class="mytable" style="width:900px;position:unset;"><thead><tr><th style="width:8%">Player</th><th style="width:12%;">Status</th><th style="width:14%;">Table</th><th style="width:5%;" >Seat</th><th style="width:4%;">Hands</th><th style="width:5%;">Logs</th><th style="width:2%;">Sitout</th></tr></thead><tbody>';

                        for (let row of out) {
                            ret += '<tr data-player="' + row.Player.toLowerCase() + '"  data-table="' + row.tbName + '" ><td>' + row.Player + '</td><td ><span title="' + row.StatusTime + '">' + row.Status + '</span></td><td>' + row.tbName + '</td><td>' + (row.Seat > 0 ? row.Seat : "?") + '</td><!--<td class="acting">' + (row.SitingOut ? 'Sitting Out' : (row.act + (row.act != "Done" ? ' ( ' + row.rem + ' ) ' : ''))) + '</td>--><td>' + (row.Played > row.Hands ? 'Over' : (row.Played + ' / ' + row.Hands)) + '</td><td><a class="btn playerlogs">Logs</a></td><td><a class="btn' + (row.SitingOut ? "" : " sitoutBot") + '">' + (row.SitingOut ? "....." : "Sitout") + '</a></td></tr>';

                        }

                        ret += '</tbody></table>';

                        bcore.sendToAdmins(res.username, {
                            "Command": "loadLogin",
                            "ht": ret,
                            "loginslist": loginslist,
                            "timer": checkTimetimer,
                            "details": details
                        });

                    }
                    break;
                case "startCheckTime": {}
                    break;
                case "loadLogin2": {

                        var dt = Object.keys(bcore.Clients);
                        let out = [];
                        for (let ccl in bcore.Clients) {
                            for (let tbName in bcore.Clients[ccl].Tables) {
                                let tbb = bcore.Clients[ccl].Tables[tbName];
                                out.push({
                                    Hands: tbb.Hands,
                                    Seat: tbb.Seat,
                                    Played: tbb.played,
                                    Status: tbb.Status,
                                    StatusTime: tbb.StatusTime,
                                    Player: tbb.Player,
                                    tbName: tbName,
                                    act: (tbb.actionNum >= Object.keys(tbb.actions[tbb.actionType]).length ? "Done" : Object.keys(tbb.actions[tbb.actionType])[(tbb.actionNum - 1)]),
                                    rem: ((tbb.actionNum >= Object.keys(tbb.actions[tbb.actionType]).length ? 0 : tbb.actions[tbb.actionType][Object.keys(tbb.actions[tbb.actionType])[(tbb.actionNum - 1)]]) - parseInt((Date.now() - tbb.actTime) / 1000))
                                });

                            }
                            ////console.table(,["Hands","Seat","played","Status","StatusTime","Player"]);

                        }
                        //	ta5a();
                        //aata();
                        var cels = Math.ceil((out.length / 20));
                        let details = {
                            "all": out.length
                        };
                        var m = 1;
                        var n = 0;

                        let retold = '<div class="grid_header" style="color: rgb(54, 48, 37); background-color: rgb(195, 186, 167); border-color: rgb(158, 143, 113); visibility: inherit;">';

                        for (var i = 0; i < cels; i++) {

                            retold += '<div style="width: 30px; border-right-color: rgb(158, 143, 113); visibility: inherit;">#</div><div style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Name</div><div style="width: 120px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Status</div><div style="width: 150px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Table</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Status Time</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Logs</div><div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;">Logout</div>';

                        }

                        let ret0 = '<div class="grid_data" id="grid_data" style="visibility: inherit;">';

                        if (out.length) {
                            let ret = "";
                            for (var i = 0; i < cels; i++) {
                                for (var v = 0; v < 20; v++) {
                                    if (typeof dt[((i * 20) + v)] != "undefined") {

                                        let plstatus = bcore.Clients[dt[((i * 20) + v)]].Status;
                                        if (typeof details[plstatus] == "undefined") {
                                            details[plstatus] = 1;

                                        } else {
                                            details[plstatus]++;
                                        }

                                    }
                                }

                                ret += '<div class="num" style="width: 30px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';
                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color:rgb(65, 55, 45); background-color: rgb(228, 222, 216);"   class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '"> ' + (typeof out[((i * 20) + v)] != "undefined" ? '&nbsp;' + (m < 9 ? "&nbsp;" : "") + (m) : '') + '</div>';
                                    m++;

                                }

                                ret += '</div>';

                                ret += '<div class="player" style="width: 145px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';
                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color:rgb(65, 55, 45); background-color: rgb(228, 222, 216);"   class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '" >&nbsp;&nbsp;&nbsp;' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '</div>';
                                    n++
                                }

                                ret += '</div>';

                                ret += '<div style="width: 210px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';

                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);" class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '" ><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;" class="playertable"  data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '">' + (typeof out[((i * 20) + v)] != "undefined" ? (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].tbName + " ( " + (out[((i * 20) + v)].Seat < 0 ? "?" : out[((i * 20) + v)].Seat) + " )" : "") : '') + '</div></div>';

                                }

                                ret += '</div>';

                                ret += '<div style="width: 100px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';

                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);" class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '" ><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;" class="playerstatus"  data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '"  data-table="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].tbName : "") + '">' + (typeof out[((i * 20) + v)] != "undefined" ? (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Status : "") : '') + '</div></div>';

                                }

                                ret += '</div>';

                                ret += '<div style="width: 180px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';

                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);" class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '" ><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;" class="playeract"  data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '">' + (typeof out[((i * 20) + v)] != "undefined" ? (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].act + (out[((i * 20) + v)].act != "Done" ? " ( " + out[((i * 20) + v)].rem + " Seconds )" : "") : "") : '') + '</div></div>';

                                }

                                ret += '</div>';

                                ret += '<div style="width: 60px; border-right-color: rgb(158, 143, 113); visibility: inherit;"><div style="height: 20px; line-height: 20px; font-weight: bold; color: rgb(65, 55, 45); background-color: rgb(228, 222, 216);"></div>';

                                for (var v = 0; v < 20; v++) {

                                    ret += '<div style="height: 30px; line-height: 20px; font-weight: normal; color: rgb(131, 110, 91); background-color: rgb(228, 222, 216);" class="infocol" data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '" ><div id="set_input" style="top: 40px; left: 20px; right: 20px; height: 22px;" class="playerhands"  data-player="' + (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Player : "") + '">' + (typeof out[((i * 20) + v)] != "undefined" ? (typeof out[((i * 20) + v)] != "undefined" ? out[((i * 20) + v)].Played + " / " + out[((i * 20) + v)].Hands : "") : '') + '</div></div>';

                                }

                                ret += '</div>';

                            }

                        } else {

                            let ret = '<div class="Player"></div><div class="ssss3"></div><div class="ssss5"></div><div class="ssss1"></div><div class="ssss8"></div>';
                        }

                        ret0 += "</div>";

                        bcore.sendToAdmins(res.username, {
                            "Command": "loadLogin",
                            "ht": ret,
                            "details": details,
                            "username": res.username
                        });

                        //adminclients["farshad"].send(JSON.stringify({"Command":"loadLogin","ht":ret,"details":details}));

                    }
                    break;

                case "loadFunction": {
                        var fname = res.fnname;
                        let sql = "select fco from fns3 where fname='" + fname + "' and published =1 order by id desc limit 1 ";

                        cn.query(sql, (error, results, fields) => {

                            //adminclients["farshad"].send(JSON.stringify({"Command":"loadFunction","fco":results[0].fco}));


                        });

                    }
                    break;
                case "saveFunction": {
                        var fname = res.fnname;
                        var fco = res.fco;

                        let sql = "update fns3 set fco='" + fco + "' where fname='" + fname + "' and published =1 order by id desc limit 1 ";

                        cn.query(sql, (error, results, fields) => {});

                    }
                    break;
                case "callFunction": {
                        bcore.currendAdmin = res.username;

                        var fco = res.fco;

                        var localf = `var localfn  = function(callback){
								`;
                        localf += fco;
                        localf += `
								
								} `;
                        try {
                            eval(localf);
                            localfn((str) => {
                                //////(str);
                                bcore.sendMonitor({
                                    "Command": "callFunction",
                                    "str": str,
                                    "Type": "Terminated"
                                });

                            });
                        } catch (g) {

                            //////("ERR queueProcess error: " + g, "Fname: " + fname);
                        }

                    }
                    break;

                case "loadTables": {
                        bcore.currendAdmin = res.username;
                        bcore.loadTables();
                    }
                    break;

                case "openTable": {

                        bcore.currendAdmin = res.username;
                        bcore.openTable(res.Table);
                    }
                    break;

                case "system_logs": {
                        bcore.currendAdmin = res.username;
                        bcore.system_logs();
                    }
                    break;

                case "system_logbytime": {
                        bcore.currendAdmin = res.username;
                        bcore.system_logbytime(res.ti);
                    }
                    break;

                case "sitoutFromTable": {
                        bcore.sitoutFromTable(res);
                    }
                    break;

                case "changeSeat": {
                        bcore.changeSeat(res);
                    }
                    break;

                case "x2": {
                        bcore.x2(res);
                    }
                    break;

                case "botLogbytype": {
                        bcore.botLogbytype(res.Player, res.Type);
                    }
                    break;

                case "botLog": {
                        bcore.currendAdmin = res.username;

                        bcore.botLog(res.Player);
                    }
                    break;

                case "checkUpdate": {
                        let ret = {
                            "Command": "checkUpdate",
                            "updates": "",
                            "num": 0,
                            "Type": "Terminated"
                        };
                        const updateFolder = './update/';
                        const curDir = './';
                        let filelist = ["core6", "bot", "mktable", "cp"];
                        bcore.currendAdmin = res.username;
                        fs.readdir(updateFolder, (err, files) => {
                            files.forEach(file => {
                                let ex = file.split(".");

                                if (filelist.indexOf(ex[0]) > -1) {
                                    let fname = updateFolder + file;
                                    let destfile = curDir + file;
                                    var stats = fs.statSync(fname);
                                    var destfilestats = fs.statSync(destfile);
                                    let dtime = new Date(destfilestats.mtime);
                                    let ctime = new Date(stats.mtime);
                                    if (stats.mtimeMs > destfilestats.mtimeMs) {
                                        ret["num"]++;
                                        ret["updates"] += "<span>" + file + " <br>Current file date : " + ctime.getMonth() + "/" + ctime.getDate() + " " + ctime.getHours() + ":" + ctime.getMinutes() + "  <br>Update file date : " + dtime.getMonth() + "/" + dtime.getDate() + " " + dtime.getHours() + ":" + dtime.getMinutes() + " </span>";

                                    }
                                }

                            });

                            bcore.sendMonitor(ret);

                        });

                    }
                    break;

                case "getUpdate": {
                        let ret = {
                            "Command": "confirmUpdate",
                            "Result": "No",
                            "Type": "Terminated",
                            "Msg": []
                        };
                        const updateFolder = './update/';
                        const curDir = './';
                        let filelist = ["core6", "bot", "mktable", "cp"];
                        bcore.currendAdmin = res.username;
                        fs.readdir(updateFolder, (err, files) => {
                            files.forEach(file => {
                                let ex = file.split(".");

                                if (filelist.indexOf(ex[0]) > -1) {
                                    let fname = updateFolder + file;
                                    let destfile = curDir + file;
                                    var stats = fs.statSync(fname);
                                    var destfilestats = fs.statSync(destfile);
                                    let dtime = new Date(destfilestats.mtime);
                                    let ctime = new Date(stats.mtime);
                                    if (stats.mtimeMs > destfilestats.mtimeMs) {
                                        switch (ex[0]) {
                                        case "bot":
                                            //////("okjjjjjj");
                                            break;

                                        case "core6":

                                            let conf = {};
                                            conf.Clients = bcore.Clients;
                                            conf.packetPort = bcore.packetPort;
                                            conf.version = bcore.version;
                                            conf.adminacc = bcore.adminacc;
                                            conf.PLS = bcore.PLS;
                                            conf.showapi = bcore.showapi;
                                            conf.WaitingLogout = bcore.WaitingLogout;
                                            conf.Tables = bcore.Tables;
                                            conf.wsclient = bcore.wsclient;
                                            conf.commands = bcore.commands;
                                            conf.loaded = bcore.loaded;
                                            conf.wss = bcore.wss;
                                            conf.runBots = bcore.runBots;
                                            conf.SessionKey = bcore.SessionKey;
                                            conf.PNum = bcore.PNum;
                                            conf.Seats = bcore.Seats;
                                            conf.monitor = bcore.monitor;
                                            conf.finOut = bcore.finOut;
                                            conf.finOutCounter = bcore.finOutCounter;
                                            conf.spendedTime = bcore.spendedTime;
                                            conf.spendedTourTime = bcore.spendedTourTime;
                                            conf.botTimers = bcore.botTimers;
                                            conf.botTourTimers = bcore.botTourTimers;
                                            conf.currendAdmin = bcore.currendAdmin;
                                            let newobj = require(fname);

                                            global.bcore = new newobj(conf);

                                            fs.copyFile(fname, destfile, fs.constants.COPYFILE_FICLONE, (err) => {
                                                if (err) {
                                                    //////("Error Found:", err);
                                                } else {

                                                    fs.unlink(fname, (err) => {
                                                        ret.Result = "Ok";
                                                        ret.Msg.push("core6 updated");
                                                        bcore.sendMonitor(ret);
                                                    });

                                                    return;
                                                }
                                            });

                                            break;

                                        }

                                    } else {

                                        ret.Result = "Error";
                                        ret.Error = "No file found";
                                    }
                                }

                            });

                            //bcore.sendMonitor(ret);

                        });

                    }
                    break;

                case "updateFile": {

                        bcore7 = require(res.fileName);

                        fs.copyFile(res.fileName, "core6.js", fs.constants.COPYFILE_FICLONE, (err) => {
                            if (err) {
                                //////("Error Found:", err);
                            } else {}
                        });
                        let t = {};
                        t.Clients = bcore.Clients;
                        t.packetPort = bcore.packetPort;
                        t.version = bcore.version;
                        t.adminacc = bcore.adminacc;
                        t.PLS = bcore.PLS;
                        t.showapi = bcore.showapi;
                        t.WaitingLogout = bcore.WaitingLogout;
                        t.Tables = bcore.Tables;
                        t.wsclient = bcore.wsclient;
                        t.commands = bcore.commands;
                        t.loaded = bcore.loaded;
                        t.wss = bcore.wss;
                        t.runBots = bcore.runBots;
                        t.SessionKey = bcore.SessionKey;
                        t.PNum = bcore.PNum;
                        t.Seats = bcore.Seats;
                        t.monitor = bcore.monitor;
                        t.finOut = bcore.finOut;
                        t.finOutCounter = bcore.finOutCounter;
                        t.spendedTourTime = bcore.spendedTourTime;
                        t.spendedTime = bcore.spendedTime;
                        t.botTimers = bcore.botTimers;
                        t.botTourTimers = bcore.botTourTimers;
                        t.currendAdmin = bcore.currendAdmin;

                        global.bcore = new bcore7(t);
                        //bcore.openTable(res.Table);
                    }
                    break;

                case "addBot": {
                        bcore.createBot(res.formdata, (resu) => {
                            setTimeout(() => {

                                bcore.openTable(res.formdata.Table, () => {});

                            }, 2000);

                        });
                        //bcore.openTable(res.Table);
                    }
                    break;

                case "loadTable": {

                        var dt = Object.keys(bcore.Tables);
                        var cels = Math.ceil((dt.length / 20));
                        var m = 1;
                        var n = 0;
                        var ret = "";

                        for (var v = 0; v < dt.length; v++) {
                            var tbs = bcore.Tables[dt[v]];
                            var pls = 0;
                            if (typeof tbs != "undefined") {
                                for (var pl in tbs.Players) {
                                    if (tbs.Players[pl].Status != "empty") {

                                        pls++;

                                    }
                                }

                                if (pls > 0) {
                                    ret += "<div class='tbs' id='R" + tbs.ID + "'><div class='tbname'>" + tbs.ID + "</div><div class='tbsinfo'><div class='flop'><div class='cards'>" + (tbs.flop[0] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[0] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[1] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[1] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[2] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[2] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[3] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[3] - 1) * 23) + "px 0'></div>" : "") + (tbs.flop[4] > 0 ? "<div class='card c1' style='background-position:-" + ((tbs.flop[4] - 1) * 23) + "px 0'></div>" : "") + "</div></div><div class='total'>Total : <span>" + tbs.total.formatMoney(0) + "</span></div><div class='pot'>Pot : <span>" + tbs.pot.formatMoney(0) + "</span></div></div><table class='players' border='1' >";
                                    for (var st in tbs.Players) {
                                        var pss = tbs.Players[st];

                                        ret += "<tr class='" + pss.Status + "' id='seat" + st + "' ><td  style='width:10px;'>" + st + "</td><td  style='width:70px;' 	class='plname' >" + pss.Player + "</td><td  style='width:70px;' class='infos' >Place : <span class='playerplace' >" + pss.place + "</span><br>Action : <span class='playeraction' >" + pss.Action + "</span><br>Point : <span class='playerpoint' >" + pss.point + "</span></td><td  style='width:70px;' class='decide' ></td><td  class='helper' >" + pss.Helper + "</td><td style='width:140px;'><div class='cards'>" + (pss.Cards[0] > 0 ? "<div class='card c1' style='background-position:-" + ((pss.Cards[0] - 1) * 23) + "px 0'></div>" : "") + (pss.Cards[1] > 0 ? "<div class='card c1' style='background-position:-" + ((pss.Cards[1] - 1) * 23) + "px 0'></div>" : "") + (pss.Cards[2] > 0 ? "<div class='card c1' style='background-position:-" + ((pss.Cards[2] - 1) * 23) + "px 0'></div>" : "") + (pss.Cards[3] > 0 ? "<div class='card c1' style='background-position:-" + ((pss.Cards[3] - 1) * 23) + "px 0'></div>" : "") + (pss.Cards[4] > 0 ? "<div class='card c1' style='background-position:-" + ((pss.Cards[4] - 1) * 23) + "px 0'></div>" : "") + "</div></td></tr>";
                                    }

                                    ret += "</table></div>";

                                }

                            }
                        }
                        //adminclients["farshad"].send(JSON.stringify({"Command":"loadLogin","ht":ret}));

                    }
                    break;
                case "errorDetails": {
                        bcore.errorDetails(res.ind);
                    }
                    break;
                case "transferBots": {

                        //ws.send(JSON.stringify({"Command":"botList","List":Object.keys(bcore.Clients)}));
                        bcore.transferWS = ws;
                        bcore.transferList = Object.keys(bcore.Clients);
                        bcore.sendMonitor({
                            "Command": "startTransfer",
                            "Type": "Terminated"
                        });

                        bcore.runBots = false;
                        bcore.makeTransfer(() => {});

                    }
                    break;
                case "transferBotTables": {
                        bcore.Clients[res.Player.toLowerCase()].setStatus("transfering");
                        bcore.loadBotTables(ws, bcore.Clients[res.Player.toLowerCase()].Tables, (tbs) => {
                            ////////(tbs);


                        });
                    }
                    break;
                case "saveJson": {
                        var out = {};
                        for (var k in res["config"]) {
                            var ex = k.split("[");
                            var kk = ex[0];
                            var vv = ex[1];
                            var e1 = ex[1].replace("]", "");
                            var e2 = ex[2].replace("]", "");

                            if (typeof out[kk] == "undefined") {
                                out[kk] = {};
                            }

                            if (typeof out[kk][e1] == "undefined") {
                                out[kk][e1] = [];
                            }

                            out[kk][e1].push(res["config"][k]);

                        }
                        Flopcore.keys[res["state"]][res["colwin"]] = out;

                        fs.writeFile("data.json", JSON.stringify(Flopcore.keys), function (err) {
                            if (err)
                                throw err;
                        });

                    }
                    break;

                default: {
                        bcore.sendResponse(res);

                    }

                }

            });

        });

    }

}
//this function ||| monitorOn


BCORE.prototype.isBot = function (botName) {
	botName = botName.toLowerCase();
	let isBot = false;
	for(let lis in botData.Bots)
	{
		let arr = botData.Bots[lis];
		if(typeof (arr.find((key )=> { if(key.toLowerCase() == botName.toLowerCase()) {return true;} else {return false; } })) != "undefined")
		{
				
				
			isBot = true;
		}
		
	}
	if(typeof (botData.TourBots.find((key )=> { if(key.toLowerCase() == botName.toLowerCase()) {return true;} else {return false; } })) != "undefined")
	{
				
				
			isBot = true;
	}
	return isBot;
	
	
}
BCORE.prototype.transferBots = function (ws, Tables, callback) {}
BCORE.prototype.loadBotTables = function (Player, callback) {
    let botTables = [];
    let Tables = bcore.Clients[Player.toLowerCase()].Tables;
    for (let tb in Tables) {
        let row = Tables[tb];
        botTables.push({
            obj: bcore.getTable(tb),
            actTime: row.actTime,
            chips: row.chips,
            sitingOut: row.sitingOut,
            sitingForce: row.sitingForce,
            timestart: row.timestart,
            Status: row.Status,
            StatusTime: row.StatusTime,
            Seat: row.Seat,
            played: row.played,
            Profile: row.profile,
            inPot: row.inPot,
            addInPot: row.addInPot,
            state: row.state,

            GameID: row.GameID,
            Player: row.Player,
            PlayerID: row.PlayerID,
            Hands: row.Hands,
            Times: row.Times,
            Rebuys: row.Rebuys

        });

    }

    let cmd = JSON.stringify({
        "Command": "transferBotTables",
        "Tables": botTables
    });
    bcore.transferWS.send(cmd);
    //callback(botTables);


}
BCORE.prototype.sendMonitor = function (ID, callback) {
    var t = this;
    var allowedCommand = ["GetBotLogs", "loadLogin", "terminated", "setStatus", "deleteBot", "loadTables", "openTable", "botLog", "botLogbytype", "system_logs", "system_logbytime", "startCheckTime", "startTransfer", "errorDetails", "loadbotSettings", "startTour", "tourstarttime", "loadtourSettings", "loadHour", "loadTours", "checkUpdate", "confirmUpdate", "callFunction", "editJson"];
    var allowed = ["ECards", "HandHelper", "Terminated", "tableStatus", "clientStatus"];
    ////////("sendMonitor",ID.Type,ID.Command,bcore.currendAdmin);
    if (ID.Command == "setStatus" || ID.Command == "startCheckTime" || ID.Command == "startTransfer" || ID.Command == "startTour") {

        for (let admin in adminclients) {
            adminclients[admin].sendCommand(ID);

        }
    } else {

        if (allowed.indexOf(ID.Type) > -1 && allowedCommand.indexOf(ID.Command) > -1 && bcore.currendAdmin != "") {
            bcore.sendToAdmins(bcore.currendAdmin, ID);

        }
    }
    /*
    if(config.monitor && typeof adminclients["farshad"] != "undefined" && typeof adminclients["farshad"].send == "function" && allowedCommand.indexOf(ID.Command) > -1 ){

    var sec = parseInt(Date.now() / 1000);

    if(typeof t.monitor[ID.Table] == "undefined"){
    t.monitor[ID.Table] = {};

    }
    if(typeof t.monitor[ID.Table][sec] == "undefined"){
    t.monitor[ID.Table][sec] = {};

    }
    if(allowed.indexOf(ID.Type) > -1){
    bcore.sendToAdmins(ID.username,ID);

    }else{
    if(typeof t.monitor[ID.Table][sec][ID.Type] == "undefined"){
    //adminclients["farshad"].send(JSON.stringify(ID));



    }
    bcore.sendToAdmins(ID.username,ID);
    //t.monitor[ID.Table][sec][ID.Type] = true;

    }

    }

     */

}
BCORE.prototype.sendToAdmins = function (username, params) {

    if (typeof adminclients[username] != "undefined") //&& typeof adminclients[username].send == "function")
    {
        adminclients[username].sendCommand(params);
        ////////("hast",username);
        ////////(adminclients[username].ws);
        //adminclients[username].send(JSON.stringify(params));
    } else {
        //////(username + " not found");

    }

}
BCORE.prototype.turnOnMonitor = function (turn, username) {
    if (turn == "on") {
        config.monitor = true;

        bcore.monitorOn();
    } else {

        config.monitor = false;
        bcore.monitorOff();

    }
}
BCORE.prototype.jsonWrite = function (filename, data, callback) {
    fs.writeFile(filename, JSON.stringify(data), function (err) {
        if (err) {
            throw err;
        }

        callback();
    });

}
BCORE.prototype.editJson = function (res) {
    switch (res.type) {
    case "addBotTour": {
            if (botData.TourBots.indexOf(res.botname) == -1) {

                maven.mvapi({
                    "Command": "AccountsGet",
                    "Player": res.botname
                }, (msg) => {
                    if (msg.Result == "Ok") {
                        botData.TourBots.push(res.botname);

                        bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {

                            bcore.loadtourSettings(res.list);

                        });

                    } else {

                        bcore.sendMonitor({
                            "Command": "editJson",
                            "Type": "Terminated",
                            "Result": "Error",
                            "Error": msg.Error
                        });

                    }

                    //bcore.sendMonitor({"Command":"editJson","Type":"Terminated","Result":"Error","Error":"Bot " + res.botname " is exists"});

                });
            } else {
                bcore.currendAdmin = res.username;

                bcore.sendMonitor({
                    "Command": "editJson",
                    "Type": "Terminated",
                    "Result": "Error",
                    "Error": "Bot " + res.botname + " is exists"
                });

            }
        }
        break;

    case "addBot": {
            if (botData.Bots[res.list].indexOf(res.botname) == -1) {

                maven.mvapi({
                    "Command": "AccountsGet",
                    "Player": res.botname
                }, (msg) => {
                    if (msg.Result == "Ok") {
                        botData.Bots[res.list].push(res.botname);

                        bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {

                            bcore.loadbotSettings(res.list);

                        });

                    } else {

                        bcore.sendMonitor({
                            "Command": "editJson",
                            "Type": "Terminated",
                            "Result": "Error",
                            "Error": msg.Error
                        });

                    }

                    //bcore.sendMonitor({"Command":"editJson","Type":"Terminated","Result":"Error","Error":"Bot " + res.botname " is exists"});

                });
            } else {
                bcore.currendAdmin = res.username;

                bcore.sendMonitor({
                    "Command": "editJson",
                    "Type": "Terminated",
                    "Result": "Error",
                    "Error": "Bot " + res.botname + " is exists"
                });

            }
        }
        break;
    case "addTable": {
            //////("this hout",res.hour,typeof botData.Hours[res.hour]);
            if (typeof botData.Hours[res.hour] == "undefined") {

                botData.Hours[res.hour] = {
                    "Tables": {}
                };
            }
            botData.Hours[res.hour].Tables[res.tbname] = {
                "players": [res.from, res.to],
                "min": res.min,
                "list": res.list
            };
            bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                //////("loaad hour ",res.hour);
                bcore.loadHour(res.hour);
            });
        }
        break;
    case "addTournnew": {
            bcore.getTourRuntime(res.tourname, (response) => {});
        }
        break;
    case "addTourMY": {
            let tourObj = bcore.Tournaments[res.tourname];

            let result = {
                "Result": "Error"
            };
            if (typeof tourObj != "undefined") {
                if (tourObj.StartTime == "0000-00-00 00:00") {
                    result.Result = "Error";
                    result.Error = "Start time not set";
                } else {
                    let before = (parseInt(res.before) * 60);
                    let st = Date.parse(tourObj.StartTime);
                    let rt = (st - (before * 1000));
                    let now = Date.now() - 3600000;
					bcore.Tournaments[res.tourname].runTime = rt;
					 console.log("rruntime set", bcore.Tournaments[res.tourname].runTime, rt,inputConfig.configName,"before",before);
                    if (st > now) {

                        result.Result = "Ok";
                        botData.Tournaments[res.tourname] = {
                            "MinRebuy": res.min,
                            "MaxRebuy": res.max,
                            "Bots": res.bots,
                            "Before": res.before,
                            "StartTime": st,
                            "runTime": rt
                        }
                        bcore.Tournaments[res.tourname].runTime = rt;
                      
                        bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                            //////("loaad hour ",res.hour);
                            bcore.loadTours();
                        });

                        if (rt < now) {

                            setTimeout(() => {
                                //   //("hetrrddddee3");
                                bcore.startTour(res.tourname, () => {});
                                result.Result = "Error";
                                result.Error = "Expire run time";

                            }, 5000);

                        }
                    } else {

                        //("rqqq");
                        result.Result = "Error";
                        result.Error = "Expire start time";
                    }
                }
            } else {

                result.Result = "Error";
                result.Error = "Tour " + res.tourname + " not found ";

            }
            bcore.currendAdmin = res.username;
            bcore.sendMonitor({
                "Command": "tourstarttime",
                "Type": "Terminated",
                ...result
            });
console.log(result);
        }
        break;
   case "addTour": {
            let tourObj = bcore.Tournaments[res.tourname];

            let result = {
                "Result": "Error"
            };
            if (typeof tourObj != "undefined") {
                if (tourObj.StartTime == "0000-00-00 00:00") {
                    result.Result = "Error";
                    result.Error = "Start time not set";
                } else {
                    let before = (parseInt(res.before) * 60);
                    let st = Date.parse(tourObj.StartTime);
                    let rt = (st - (before * 1000));
                    let now = Date.now() - 3600000;
                    if (st > now) {

                        result.Result = "Ok";
                        botData.Tournaments[res.tourname] = {
                            "MinRebuy": res.min,
                            "MaxRebuy": res.max,
                            "Bots": res.bots,
                            "Before": res.before,
                            "runTime": rt
                        }
                        bcore.Tournaments[res.tourname].runTime = rt;
                     //   //("rruntime set", bcore.Tournaments[res.tourname].runTime, rt);
                        bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                            //////("loaad hour ",res.hour);
                            bcore.loadTours();
                        });

                        if (rt <= now) {

                            setTimeout(() => {
                             //   //("hetrrddddee3");
                                bcore.startTour(res.tourname, () => {});
                                result.Result = "Error";
                                result.Error = "Expire run time";

                            }, 5000);

                        }
                    } else {

                        //("rqqq");
                        result.Result = "Error";
                        result.Error = "Expire start time";
                    }
                }
            } else {

                result.Result = "Error";
                result.Error = "Tour " + res.tourname + " not found ";

            }
            bcore.currendAdmin = res.username;
            bcore.sendMonitor({
                "Command": "tourstarttime",
                "Type": "Terminated",
                ...result
            });

        }
        break;

    case "addTourold": {

            let tourObj = bcore.Tournaments[res.tourname];

            if (typeof tourObj != "undefined") {
                if (tourObj.StartTime == "0000-00-00 00:00") {
                    bcore.currendAdmin = res.username;

                    bcore.sendMonitor({
                        "Command": "tourstarttime",
                        "Type": "Terminated"
                    });

                } else {
                    let rt = (Date.parse(tourObj.StartTime) - (parseInt(res.before) * 60000));
                    botData.Tournaments[res.tourname] = {
                        "MinRebuy": res.min,
                        "MaxRebuy": res.max,
                        "Bots": res.bots,
                        "Before": res.before,

                        "runTime": rt
                    }
                    bcore.Tournaments[res.tourname].runTime = rt;
                    bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                        //////("loaad hour ",res.hour);
                        bcore.loadTours();
                    });
                }
            }
        }
        break;
    case "deleteBot": {
            if (botData.Bots[res.list].indexOf(res.botname) > -1) {
                botData.Bots[res.list].splice(botData.Bots[res.list].indexOf(res.botname), 1);

                bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                    bcore.loadbotSettings(res.list);
                });
            }
        }
        break;

    case "deleteTourBot": {
            if (botData.TourBots.indexOf(res.botname) > -1) {
                botData.TourBots.splice(botData.TourBots.indexOf(res.botname), 1);

                bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                    bcore.loadtourSettings(res.list);
                });
            }
        }
        break;

    case "deleteTour": {
            if (typeof botData.Tournaments[res.tbname] != "undefined") {
                delete botData.Tournaments[res.tbname];
                //botData.Tournaments[
                bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                    bcore.loadTours();
                });
            }
        }
        break;

    case "deleteBotTable": {

            if (typeof botData.Hours[res.hour].Tables[res.tbname] != "undefined") {
                delete botData.Hours[res.hour].Tables[res.tbname];

                bcore.jsonWrite((!inputConfig.configName ? "./bots.json" : "../configs/" + inputConfig.configName + "bots.json"), botData, () => {
                    bcore.loadHour(res.hour);
                });
            }
        }
        break;

    }
    //////(res);
}
BCORE.prototype.loadHour = function (hour) {
    let t = this;

    //hour = hour == 0 ? 23 : (hour);

    var row = botData.Hours[hour];
    //////(hour,row);
    let botTables = "";
    if (typeof row != "undefined") {
        for (let tbs in row.Tables) {

            botTables += '<tr><td>' + tbs + '</td><td>' + row.Tables[tbs].players[0] + '</td><td>' + row.Tables[tbs].players[1] + '</td><td>' + row.Tables[tbs].min + '</td><td>' + row.Tables[tbs].list + '</td><td><a class="btn deleteBotTable" data-table="' + tbs + '" >Delete</a></td></tr>';

        }

    }

    t.sendMonitor({
        "Command": "loadHour",
        "Type": "Terminated",
        "botTables": botTables
    });

}
BCORE.prototype.loadTours = function (hour) {
    let t = this;

    //hour = hour == 0 ? 23 : (hour);

    //var row = botData.Hours[hour];
    //////(hour,row);
    let botTables = "";

    let now = Date.now();
    now -= 3600000;
    for (let tour in botData.Tournaments) {
        let tourObj = bcore.Tournaments[tour];

        let d = new Date(tourObj.runTime);
 let before = (parseInt(botData.Tournaments[tour].Before) * 60);
                    let st = Date.parse(tourObj.StartTime);
                    let rt = (st - (before * 1000));
        var connectTime = DBG.addZero(d.getMonth()) + "/" + DBG.addZero(d.getDate()) + " " + DBG.addZero(d.getHours()) + ":" + DBG.addZero(d.getMinutes());
        let bet = parseInt(((tourObj.runTime - (now + 3600000)) / 1000));
 
        let className = "still";
        let hasTimer = ' hasTimer"  data-timer="' + bet;
		if (bet < 0) {
                bet = parseInt(rt);
            betTimer = "Checking...";
            hasTimer = '';
                className = "running";
            }
            betTimer = bet < 0 ? "EXPIRED TIME" : bcore.getTimer((bet ));
       

        botTables += '<tr class="' + (bet < 0 ? "expire" : className) + '" ><td>' + tour + '</td><td>' + botData.Tournaments[tour].Bots + '</td><td class="tourtime' + hasTimer + '" >' + betTimer + '</td><td>' + botData.Tournaments[tour].MinRebuy + '</td><td>' + botData.Tournaments[tour].MaxRebuy + '</td><td><a class="btn deleteBotTable" data-table="' + tour + '" >Delete</a></td></tr>';

    }

    t.sendMonitor({
        "Command": "loadTours",
        "Type": "Terminated",
        "botTables": botTables
    });

}

BCORE.prototype.loadToursMY = function (hour) {
    let t = this;

    //hour = hour == 0 ? 23 : (hour);

    //var row = botData.Hours[hour];
    //////(hour,row);
    let botTables = "";

    let now = Date.now();
    now -= 3600000;
    for (let tour in botData.Tournaments) {
        let tourObj = bcore.Tournaments[tour];

        let d = new Date(tourObj.runTime);
        let before = (parseInt(botData.Tournaments[tour].Before) * 60);
        let st = Date.parse(tourObj.StartTime);
        let rt = (st - (before * 1000));
        var connectTime = DBG.addZero(d.getMonth()) + "/" + DBG.addZero(d.getDate()) + " " + DBG.addZero(d.getHours()) + ":" + DBG.addZero(d.getMinutes());
        let bet = (parseInt(botData.Tournaments[tour].runTime) )  - now;
console.log(bet);
        let className = "still";
        let hasTimer = ' hasTimer"  data-timer="' + bet;
        if (bet < 0) {
            bet = parseInt(rt);
            betTimer = "Checking...";
            hasTimer = ' hasTimer"  data-timer="' + bet;
            className = "running";
        }else{
        betTimer = bet < 0 ? "EXPIRED TIME" : bcore.getTimer((bet));
		
		}
console.log(betTimer,hasTimer);
        botTables += '<tr class="' + (bet < 0 ? "expire" : className) + '" ><td>' + tour + '</td><td>' + botData.Tournaments[tour].Bots + '</td><td class="tourtime' + hasTimer + '" >' + betTimer + '</td><td>' + botData.Tournaments[tour].MinRebuy + '</td><td>' + botData.Tournaments[tour].MaxRebuy + '</td><td><a class="btn deleteBotTable" data-table="' + tour + '" >Delete</a></td></tr>';

    }

    t.sendMonitor({
        "Command": "loadTours",
        "Type": "Terminated",
        "botTables": botTables
    });

}
BCORE.prototype.loadtourSettings = function (listNumber) {
    let t = this;
    bcore.loadTournaments(() => {
        let bots = '<div class="inputnewbot" style="width: 100%;height: 42px;"><span style="display: block;float: left;color: #333;width: 86px;line-height: 22px;margin-left: 52px;"> Bot Name</span><input type="text" id="newbotname" style="float: left;margin-right: 21px;margin-left: -17px;"><a class="btn" style="float: left;width: 58px;color: #000;">Add</a><span class="addingBot" style="display: none;float: left;color: #333;width: 300px;line-height: 22px;margin-left: 52px;background: green;text-align: center;color: #fff;"></span></div>';
        let limit = 20;
        let bet = botData.TourBots.length % limit;
        if (typeof botData.TourBots != "undefined") {
            let tbls = (botData.TourBots.length - bet) / limit + 1;
            let nx = 0;
            //let botTables = "";
            console.log("this", bcore.tourPlayers);
            for (let i = 0; i < tbls; i++) {
                bots += '<table class="mytable" style="width:23% ;float:left;margin-right: 0.5%;margin-bottom:5%;border-bottom:1px solid #000;"><thead><tr><th style="width:2%">#</th><th style="width:30%">Name</th><th style="width:30%">Delete</th></tr></thead><tbody>';

                for (let n = 0; n < limit; n++) {
                    let bt = botData.TourBots[nx];
                    if (typeof bt != "undefined") {
                        let rs = bcore.tourPlayers.find((row) => row.player === bt.toLowerCase());

                        if (typeof rs != "undefined") {

                            bots += '<tr  class="pending"   data-name="' + bt + '"><td >' + (parseInt(nx) + 1) + '</td><td>' + bt + '</td><td><a data-timer="' + rs.spendTime + '"  class="hasTime">' + bcore.getTimer(rs.spendTime) + '</a></td></tr>';

                        } else {
                            bots += '<tr data-name="' + bt + '"><td >' + (parseInt(nx) + 1) + '</td><td>' + bt + '</td><td><a class="removeBot">X</a></td></tr>';

                        }

                        //	$("#tour_settings #botList tr[data-name='" + pl.Player + "']").addClass("pending").find("a").attr("data-timer",pl.spendTime).startTimer();
                        nx++;
                    }
                }

                bots += '</tbody></table>';

            }
        }

        const d = new Date(Date.now());
        let botTables = '<div class="addform"  style="position:relative !important;"><div class="tourstarttime" style="display:none;position:absolute !important;background: #e4ded8;width: 310px;height: 74px;text-align: center;color: #000;font-size: 18px;line-height: 51px;border: 2px solid #333;padding: 16px;right: 2%;"><span class="txt" style="position:unset !important;" ></span><a class="btn" data-table="farsh" style="width: 90px;margin: 0px auto;">OK</a></div><table class="mytable"  style="width:100%" id="systemlogs"><thead><tr><th style="width:30%">Tournament</th><th style="width:5%">Bots</th><th style="width:4%">Before</th><th style="width:4%">Min Rebuy</th><th style="width:4%">Max Rebuys</th><th style="width:10%">ADD</th></tr></thead><tbody><tr><td ><select style="width: 100%;" name="table"><option>Select Tournament</option>';
        for (let tbname in bcore.Tournaments) {
            if (typeof botData.Tournaments[tbname] == "undefined") {

                botTables += '<option value="' + tbname + '">' + tbname + '</option>';
            }
        }
        botTables += '</select></td><td><select  name="from">';
        for (let i = 1; i <= botData.TourBots.length; i++) {

            botTables += '<option  value="' + i + '">' + i + '</option>';
        }
        botTables += '</select></td><td><select  name="before">';
        for (let i = 10; i < 120; i++) {

            if (i % 10 == 0) {
                botTables += '<option value="' + i + '">' + (i < 60 ? "00:" + i : "01:" + (((i - 60) == 0 ? "0" : "") + (i - 60))) + '</option>';

            }
        }
        botTables += '</select></td><td><select name="min">';
        for (let i = 1; i < 11; i++) {

            botTables += '<option value="' + i + '">' + i + '</option>';
        }

        botTables += '</select></td><td><select name="list">';
        for (let i = 1; i < 11; i++) {

            botTables += '<option value="' + i + '">' + i + '</option>';
        }

        botTables += '</select></td><td><a class="btn addTour">+</a></td></tr></tbody></table></div><table class="mytable"  style="width:100%" id="tables"><thead><tr><th style="width:30%">TourName</th><th style="width:4%">Bots</th><th style="width:10%">Start</th><th style="width:4%">Min Rebuys</th><th style="width:4%">Max Rebuys</th><th style="width:10%">Delete</th></tr></thead><tbody>';

        let now = Date.now();
        now -= 3600000;
        for (let tour in botData.Tournaments) {
            let tourObj = bcore.Tournaments[tour];

            let d = tourObj.StartTime;
            let d2 =tourObj.runTime;
            let before = (parseInt(botData.Tournaments[tour].Before) * 60);
            let st = Date.parse(tourObj.StartTime);
            let rt = (st + (before * 1000));
            
            let bet = parseInt(((tourObj.runTime - (now + 3600000)) / 1000));

            let className = "still";
            if (bet < 0) {

                bet = parseInt(((st - (now + 3600000)) / 1000));
                className = "running";
            }
            betTimer = bet < 0 ? "EXPIRED TIME" : bcore.getTimer((bet));

            botTables += '<tr class="' + (bet < 0 ? "expire" : className) + '" ><td>' + tour + '</td><td>' + botData.Tournaments[tour].Bots + ' ' + d + '</td><td class="hasTimer"  data-timer="' + bet + '" >' + betTimer + '</td><td>' + botData.Tournaments[tour].MinRebuy + ' ' + d2 + '</td><td>' + botData.Tournaments[tour].MaxRebuy + '</td><td><a class="btn deleteBotTable" data-table="' + tour + '" >Delete</a></td></tr>';

        }

        botTables += '</tbody></table>';

        t.sendMonitor({
            "Command": "loadtourSettings",
            "Type": "Terminated",
            "botList": bots,
            "botTables": botTables
        });
    });
}

BCORE.prototype.loadbotSettings = function (listNumber) {
    let t = this;
    let bots = '<div class="inputnewbot" style="width: 100%;height: 42px;"><span style="display: block;float: left;color: #333;width: 86px;line-height: 22px;margin-left: 52px;"> Bot Name</span><input type="text" id="newbotname" style="float: left;margin-right: 21px;margin-left: -17px;"><span style="display: block;float: left;color: #333;width: 86px;line-height: 22px;"> List Number</span><select style="float:left;margin-right: 16px;"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option></select><a class="btn" style="float: left;width: 58px;color: #000;">Add</a><span class="addingBot" style="display: none;float: left;color: #333;width: 300px;line-height: 22px;margin-left: 52px;background: green;text-align: center;color: #fff;"></span></div>';
    let limit = 20;
    let bet = botData.Bots[listNumber].length % limit;
    if (typeof botData.Bots[listNumber] != "undefined") {
        let tbls = (botData.Bots[listNumber].length - bet) / limit + 1;
        let nx = 0;
        //let botTables = "";
        for (let i = 0; i < tbls; i++) {
            bots += '<table class="mytable" style="width:9% ;float:left;margin-right: 0.5%;margin-bottom:5%;border-bottom:1px solid #000;"><thead><tr><th style="width:2%">#</th><th style="width:20%">Name</th><th style="width:10%">Delete</th></tr></thead><tbody>';

            for (let n = 0; n < limit; n++) {
                let bt = botData.Bots[listNumber][nx];
                if (typeof bt != "undefined") {
                    bots += '<tr><td>' + (parseInt(nx) + 1) + '</td><td>' + bt + '</td><td><a class="removeBot" data-name="' + bt + '">X</a></td></tr>';
                    nx++;
                }
            }

            bots += '</tbody></table>';

        }
    }

    const d = new Date(Date.now());
    var hour = d.getHours();
    hour = hour == 0 ? 23 : (hour - 1);
    var row = botData.Hours[hour.toString()];
    let botTables = '<div class="hours" style="background: #302416;height: 50px;padding: 16px;margin-bottom: 11px;"><select style="width: 280px;margin: 0px auto;display: block;height: 49px;text-align: center;font-size: 2em;" id="botHours">';

    for (let i = 0; i < 24; i++) {
        let v = i < 10 ? "0" + i : i;
        let b = (i + 1) < 10 ? "0" + (i + 1) : (i + 1);

        botTables += "<option value=\"" + i + "\" " + (hour == i ? " selected='selected' " : "") + " >" + v + ":00&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;" + (b == "24" ? "00" : b) + ":00</option>";

    }

    botTables += '</select></div><div class="addform"><table class="mytable"  style="width:100%" id="systemlogs"><thead><tr><th style="width:30%">Table</th><th style="width:5%">From</th><th style="width:4%">To</th><th style="width:4%">Min</th><th style="width:4%">List</th><th style="width:10%">ADD</th></tr></thead><tbody><tr><td ><select style="width: 100%;" name="table">';
    for (let tbname in bcore.Tables) {
        botTables += '<option value="' + tbname + '">' + tbname + '</option>';
    }
    botTables += '</select></td><td><select  name="from">';
    for (let i = 1; i <= botData.Bots[listNumber].length; i++) {

        botTables += '<option  value="' + i + '">' + i + '</option>';
    }
    botTables += '</select></td><td><select  name="to">';
    for (let i = 1; i <= botData.Bots[listNumber].length; i++) {

        botTables += '<option value="' + i + '">' + i + '</option>';
    }
    botTables += '</select></td><td><select name="min">';
    for (let i = 1; i < 11; i++) {

        botTables += '<option value="' + i + '">' + i + '</option>';
    }

    botTables += '</select></td><td><select name="list">';
    for (let i = 1; i < 11; i++) {

        botTables += '<option value="' + i + '">' + i + '</option>';
    }

    botTables += '</select></td><td><a class="btn addTable">+</a></td></tr></tbody></table></div><table class="mytable"  style="width:100%" id="tables"><thead><tr><th style="width:30%">Table</th><th style="width:5%">From</th><th style="width:4%">To</th><th style="width:4%">Min</th><th style="width:4%">List</th><th style="width:10%">Delete</th></tr></thead><tbody>';

    if (typeof row != "undefined") {
        for (let tbs in row.Tables) {

            botTables += '<tr><td>' + tbs + '</td><td>' + row.Tables[tbs].players[0] + '</td><td>' + row.Tables[tbs].players[1] + '</td><td>' + row.Tables[tbs].min + '</td><td>' + row.Tables[tbs].list + '</td><td><a class="btn deleteBotTable" data-table="' + tbs + '" >Delete</a></td></tr>';

        }

    }
    botTables += '</tbody></table>';

    t.sendMonitor({
        "Command": "loadbotSettings",
        "Type": "Terminated",
        "botList": bots,
        "botTables": botTables
    });

}

BCORE.prototype.system_logbytime = function (ti) {
    let t = this;
    let logs = "";
    if (typeof DBG.systemLogs[ti] != "undefined") {

        for (let lg of DBG.systemLogs[ti].logs.system) {
            logs += "<tr><td>" + lg.time + "</td><td style='text-align:center;'>" + lg.log + "</td></tr>";
        }

    }
    let bots = "";
    for (let pl in DBG.systemLogs[ti].bots) {

        bots += "<tr><td>" + pl + "</td><td>" + DBG.systemLogs[ti].bots[pl].status + "</td>";
    }
    t.sendMonitor({
        "Command": "system_logbytime",
        "Type": "Terminated",
        "logtype": logs,
        "bots": bots
    });

}
BCORE.prototype.system_logs = function () {

    let t = this;
    let kes = Object.keys(DBG.systemLogs);
    let logtype = "";
    let errors = "";
    let ind = 0;
    for (let ro of DBG.errorLogs) {

        let ex = ro.location.split(":");
        errors += "<tr><td>" + ro.time + "</td><td>" + ro.error + "</td><td>" + ex[0] + ".js</td><td>" + ex[1] + "</td><td><a class='btn'  data-index='" + ind + "' >Details</a></td></tr>";
        ind++;
    }

    for (let ti of kes) {
        let goo = new Date((parseInt(ti)));
        let hour = DBG.addZero((goo.getHours() - 1));
        let mon = DBG.addZero((goo.getMonth() + 1));

        let year = goo.getFullYear();
        let day = DBG.addZero(goo.getDate());
        let minu = DBG.addZero(goo.getMinutes());
        let secs = DBG.addZero(goo.getSeconds());
        logtype += '<div class="typerow" data-ty="' + ti + '" >' + mon + '/' + day + ' - ' + hour + ':' + minu + ':' + secs + '</div>';
    }

    t.sendMonitor({
        "Command": "system_logs",
        "Type": "Terminated",
        "logtype": logtype,
        "checkTime": ti,
        "errors": errors
    });

}
BCORE.prototype.changeSeat = function (res) {

    /*
    //bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].actionType = "changeSeat";
    bcore.Clients[res.Player.toLowerCase()]._changeSeat = "changing";
    //console.info("changing",bcore.Clients[res.Player.toLowerCase()]._changeSeat,res.Player.toLowerCase());
    bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].sitOut(()=>{
    setTimeout(()=>{
    //	//(res);
    //	bcore.Clients[res.Player.toLowerCase()]._changeSeat = false;
    bcore.Clients[res.Player.toLowerCase()].OpenTable(res.Table);


    },1500);

    });
     */
    bcore.Clients[res.Player.toLowerCase()].changeSeat(res.Table);

}
BCORE.prototype.x2 = function (res) {
    //(res);

    /*
    //bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].actionType = "changeSeat";
    bcore.Clients[res.Player.toLowerCase()]._changeSeat = "changing";
    //console.info("changing",bcore.Clients[res.Player.toLowerCase()]._changeSeat,res.Player.toLowerCase());
    bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].sitOut(()=>{
    setTimeout(()=>{
    //	//(res);
    //	bcore.Clients[res.Player.toLowerCase()]._changeSeat = false;
    bcore.Clients[res.Player.toLowerCase()].OpenTable(res.Table);


    },1500);

    });
     */
    bcore.Clients[res.Player.toLowerCase()].runItTwice(res.Table);

}
BCORE.prototype.changeSeatOld = function (res) {

    let tbs = bcore.getTable(res.Table);
    tbs.getEmptySeat(res.Player, (Seat) => {
        bcore.Clients[res.Player.toLowerCase()].Tables[res.Table]._changeSeat = true;
        bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].sitOut(() => {
            setTimeout(() => {
                //("-==========", Seat);
                bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].actionType = "default";
                bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].actionNum = 2;
                bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].Seat = Seat;
                bcore.Clients[res.Player.toLowerCase()].Tables[res.Table].nexActTBL({
                    "Seat": Seat
                });

            }, 3000);

        });

    });

}
BCORE.prototype.sitoutFromTable = function (res) {

    let t = this;
    let tbObj = t.getTable(res.Table);
    let bt = t.Clients[res.Player];
    if (typeof bt.Tables[res.Table] != "undefined") {

        bt.noLogout = true;

        bt.Tables[res.Table].sitingOut = true;
        bt.Tables[res.Table].sitingForce = true;

        if (bt.Tables[res.Table].Seat > 0) {
            let seatObj = tbObj.Players[(bt.Tables[res.Table].Seat)];
            seatObj.sitingOut = true;

        }
        //////("sitoutFromTable",{"table":res.Table,"Player":res.Player,"seatObj":seatObj.sitingOut,"noLogout":bt.noLogout,"bttables":bt.Tables[res.Table].sitingOut});

    }
}
BCORE.prototype.openTable = function (tbname, callback) {

    let t = this;
    let tb = t.Tables[tbname];
    let ht = "";
    for (let st in tb.Players) {
        let pls = tb.Players[st];
        ht += '<tr><td>' + pls.Seat + '</td><td>' + (pls.Status != "empty" ? pls.Player : "") + '</td><td>' + (pls.Status != "empty" ? pls.Chips : "") + '</td><td>' + (pls.CLType ? '<a class="btn rebuy dobtn" data-tbname="' + tbname + '" data-player="' + (pls.Status != "empty" ? pls.Player.toLowerCase() : "") + '" >Rebuy</a><a class="btn dobtn X2" data-tbname="' + tbname + '" data-player="' + (pls.Status != "empty" ? pls.Player.toLowerCase() : "") + '" >X2</a>' : '') + '</td><td>' + (pls.CLType ? '<a class="btn dobtn changeSeat" data-tbname="' + tbname + '" data-player="' + (pls.Status != "empty" ? pls.Player.toLowerCase() : "") + '" >Change</a><a class="btn dobtn sitoutfromtable" data-tbname="' + tbname + '" data-player="' + (pls.Status != "empty" ? pls.Player.toLowerCase() : "") + '" >Sitout</a>' : '') + '</td></tr>';
    }
    t.sendMonitor({
        "Command": "openTable",
        "ht": ht,
        "Type": "Terminated"
    });

}
BCORE.prototype.loadTables = function (callback) {
    let t = this;

    let ht = "";
    let n = 1;
    let out = [];
    for (let tbname in t.Tables) {
        let tb = t.Tables[tbname];
        let playing = 0;
        for (let st in tb.Players) {
            let pls = tb.Players[st];
            if (pls.Status != "empty" && pls.Action != "15") {
                playing++;

            }

        }
        out.push({
            n: n,
            ID: tb.ID,
            playing: playing,
            seats: tb.Seats,
            "sb": (tb.SB < 1000 ? tb.SB : (tb.SB / 1000) + "K"),
            "bb": (tb.BB < 1000 ? tb.BB : (tb.BB / 1000) + "K")
        });

        n++;
    }
    out.sort(function compareByAge(a, b) {
        return a.playing - b.playing;
    });
    out.reverse();
    for (let row of out) {
        ht += "<tr><td>" + row.n + "</td><td>" + row.ID + "</td><td>" + row.sb + " / " + row.bb + "</td><td>" + row.playing + "/" + row.seats + "</td><td><a data-name='" + row.ID + "' >OPEN</a></td></tr>";
    }
    let options = "<option value='0'>Random BOT</option>";
    for (let bn of botData.Bots["1"]) {
        options += "<option value='" + bn.toLowerCase() + "'>" + bn + "</option>";
    }
    t.sendMonitor({
        "Command": "loadTables",
        "ht": ht,
        "options": options,
        "Type": "Terminated"
    });

}
BCORE.prototype.loginBot = function (pl, callback) {
    var t = this;
}
BCORE.prototype.doAction = function (newdt, tbs, seat, bott, time) {

    var t = this;

    setTimeout(function () {

        if (tbs.Players[seat].Player.toLowerCase() == bott.Player.toLowerCase()) {
            var vt = {
                "Call": newdt.Call,
                "Chips": tbs.Players[seat].Chips,
                "Pot": newdt.Pot,
                "MinRaise": newdt.MinRaise,
                "MaxRaise": newdt.MaxRaise,
                "place": tbs.Players[seat].place,
                "Player": tbs.Players[seat].Player,

                "Button2": newdt.Button2,
                "seat": seat,
                "Cards": tbs.Players[seat].Cards,
                "Helper": tbs.Players[seat].Helper,
                "state": tbs.state,
                "total": tbs.total

            };
            var secs = Math.floor((Math.random() * (6 - 1)) + 1);
            //////////////(secs)
            setTimeout(function () {
                tbs.getDecide(vt, function (ret) {

                    //var str = JSON.stringify(resp);

                    //t.sendMonitor({"Command":"tablelog","Type":"decide","Button":ret.Button,"Amount": ret.Amount,"Seat": seat,"Table":newdt.Table});
                    ////////////////(bott.Player,tbs.state)

                    ////////////////(ret)
                    bott.sendMSG({
                        "Response": "Button",
                        "Table": newdt.Table,
                        "Type": "R",
                        "Amount": ret.Amount,
                        "Button": ret.Button
                    });
                    //	bott.ws.send(str);

                });
            }, (secs * 1000));
        } else {

            //////////////("-----------------------",vt);
            //////////////("-----------------------",tbs.Players[seat].Player,seat,bott.Player);
            DBG.error({
                error: "doAction",
                location: "core6:2000",
                "seat": seat,
                "Player": bott.Player,
                "Table": tbs.ID,
                "problem": tbs.Players[seat].Player.toLowerCase() + " !=  " + bott.Player.toLowerCase()
            });

            //	erroring();

        }

    }, time);

}
BCORE.prototype.botLogbytype = function (player, type, callback) {
    let t = this;

    let logs = DBG.store[player];
    let out = "";

    if (typeof logs != "undefined") {
        for (let log of logs[type]) {

            if (type == log.params.type) {

                out += '<tr><td>' + log.time + '</td><td style="max-width:500px;">' + log.log + '</td></tr>';
            }

        }

    }
    t.sendMonitor({
        "Command": "botLogbytype",
        "Type": "Terminated",
        "logtable": out
    });

}
BCORE.prototype.errorDetails = function (ind) {
    let t = this;
    let details = DBG.errorLogs[ind];
    ////////(details);
    if (details.location == "index:850") {

        let errorObj = details.err.split("\n");
        let n = 0;
        details.err = "";
        for (let er of errorObj) {

            details.err += "<span style='display:block;font-size:" + (n < 1 ? "16px;font-weight: bold;text-align: center;margin-bottom: 13px;" : "13px;") + "' >" + er + "</span>";
            n++;
        }
    }
    t.sendMonitor({
        "Command": "errorDetails",
        "Type": "Terminated",
        "details": details
    });

}
BCORE.prototype.botLog = function (player, callback) {
    let t = this;
    let logs = DBG.store[player];
    let types = {};
    let logtype = "";
    if (typeof logs != "undefined") {
        for (let key in logs) {
            logtype += '<div class="typerow" data-ty="' + key + '" >' + key + ' (' + logs[key].length + ')</div>';

        }

    }
    t.sendMonitor({
        "Command": "botLog",
        "Type": "Terminated",
        "logtype": logtype,
        "player": player
    });

}
BCORE.prototype.getAutoLogin = function (botselected, times, i, callback) {
    var t = this;
    if (i < botselected.length) {
        var botname = botselected[i];
        setTimeout(function () {
            if (typeof t.Clients[botname.toLowerCase()] == "undefined") {
                t.loginjBot(botname, function (cl) {
                    var newbot = new bot({
                        "Player": botname,
                        "SessionKey": cl.SessionKey,
                        "ws": cl,
                        "ID": cl.mID
                    });
                    DBG("Login BOT : " + botname + "     |      Next Bot in " + times[(i + 1)] + " seconds", {
                        "type": "botlogin",
                        "Date": true
                    });
                    //////////////("this newbot",newbot);
                    t.Clients[newbot.Player.toLowerCase()] = newbot;
                    i++;
                    t.getAutoLogin(botselected, times, i, callback);
                });
            } else {
                i++;
                t.getAutoLogin(botselected, times, i, callback);
            }
        }, (times[i] * 1000));
    } else {
        callback();
    }
}
BCORE.prototype.splitTime = function (n, time) {

    var out = [];
    if (n == 0) {
        return out;
    }
    let bet = parseInt(time) / parseInt(n);
    let fl = parseInt(bet);
    let ie = parseInt(fl / 2);
    for (i = 0; i < n; i++) {
        var precentage = Math.floor((Math.random() * ((fl + ie) - ie)) + ie);
        out.push(precentage);
    }

    return out;
}
BCORE.prototype.sitoutBot = function (botname, tbname) {
    let t = this;
    t.sitoutFromTable({
        "Player": botname,
        "Table": tbname
    });

}
BCORE.prototype.terminateBot = function (botname) {
    let t = this;

    t.terminateAllLoop([botname], [], [], 0, () => {
        DBG("Terminate Complete", {
            "type": "system",
            "Date": true,
            "Color": "green"
        });
    });

}
BCORE.prototype.terminateAllLoop = function (cls, out, logoutList, i, callback) {
    let t = this;
    if (i < cls.length) {
        let bt = t.Clients[cls[i]];
        //bt.noLogout = true;
        if (typeof bt != "undefined") {
            bt.setStatus({
                "status": "Terminating"
            });
            for (let tbname in bt.Tables) {
                let dt = {
                    "Table": tbname,
                    "Player": cls[i]
                };

                t.sitoutFromTable(dt);
                /*
                let tbObj = t.getTable(tbname);
                bt.Tables[tbname].sitingOut = true;
                let seatObj = tbObj.Players[(bt.Tables[tbname].Seat)];
                seatObj.sitingOut = true;
                t.sendMonitor({"Command":"terminated","Type":"Terminated","Player":seatObj.Player.toLowerCase(),"Table":tbname});
                DBG("Terminate " + seatObj.Player + " from "  + tbname,{"type": "system","Date":true,"Color":"yellow"});
                 */
            }

            i++;
            setTimeout(() => {
                t.terminateAllLoop(cls, out, logoutList, i, callback);

            }, 1000);
        } else {

            i++;

            t.terminateAllLoop(cls, out, logoutList, i, callback);

        }

    } else {

        callback(out, logoutList);

    }
}
BCORE.prototype.autoSitout = function (list, times, i, callback) {

    var t = this;
    if (i < list.length) {
        let row = list[i];

        let bt = t.Clients[row.player];
        //setTimeout(()=>{

        bt.setStatus({
            "status": "waittositouthandlimit",
            "table": row.table
        });

        t.WaitingLogout[bt.Player.toLowerCase()] = "limithand";

        bt.sitOut(row.table);

        i++;
        t.autoSitout(list, times, i, callback);

        //	},times[i]);

    } else {

        callback();
    }
}
BCORE.prototype.autoLogout = function (list, i, callback) {

    var t = this;
    if (i < list.length) {

        let row = list[i];

        let bt = t.Clients[row.player];

        bt.setStatus({
            "status": "waittologout",
            "table": row.table,
            "player": t.Player
        });

        t.WaitingLogout[bt.Player.toLowerCase()] = "limithand";

        bt.Logout(() => {

            i++;
            t.autoLogout(list, times, i, callback);

        });

    } else {

        callback();
    }
}
BCORE.prototype.checkTerminate = function () {

    //boro too sareshoon agar miz nadashtan ke sari khorooj bede
    // agar dashtn bebin vazite sit agar mobham bood ye bar baz sitoutimidiate
    // agar vaziate sit mobham nabood statusesh ebin chie
    setTimeout(() => {
        bcore.terminateAll(true);
        DBG("checkTerminate . Clients : " + Object.keys(bcore.Clients).length, {
            "type": "system",
            "Date": true,
            "Color": "red"
        });
        if (Object.keys(bcore.Clients).length > 0) {
            //console.table(bcore.Clients, ["Status", "Player"]);
            for (let cl in bcore.Clients) {
                let kes = Object.keys(bcore.Clients[cl].Tables);
                if (kes.length) {
                    //console.table(bcore.Clients[cl].Tables, ["Status", "Player", "Seat", "sitingForce", "sitingOut"]);
                    for (let tb in bcore.Clients[cl].Tables) {
                        if (bcore.Clients[cl].Tables[tb].Seat < 1) {

                            let tbs = bcore.getTable(tb);
                            for (st in tbs.Players) {
                                if (tbs.Players[st].Status != "empty" && tbs.Players[st].Player.toLowerCase() == cl.toLowerCase()) {
                                    //(tbs.Players[st]);
                                    gzsttw3();

                                } else {

                                    //(tbs.Players[st]);
                                    gzsttw455();

                                }

                            }
                        }
                    }

                } else {
					
                }

            }
            bcore.checkTerminate();

        } else {
            //console.info("-----------------------------------------");
            //console.info("-----------------------------------------");
            //console.info("-----------------------------------------");
            //console.info("--------   G O O D    B Y E    ----------");
            //console.info("-----------------------------------------");
            //console.info("-----------------------------------------");
            //console.info("-----------------------------------------");

            process.exit(1);

        }

    }, 10000);
}
BCORE.prototype.terminateAll = function (check) {

    //{"Command":"terminateAll","time":120}
    if (typeof check == "undefined") {
        this.checkTerminate();
    }
    var t = this;
    t.runBots = false;
    let kes = Object.keys(t.Clients);
    DBG("Terminate all ( " + kes.length + " ) ", {
        "type": "system",
        "Date": true
    });
    if (kes.length) {
        //////////("terminate "+  kes.length + " Players");

        t.terminateAllLoop(kes, [], [], 0, () => {
            DBG("Terminate Complete", {
                "type": "system",
                "Date": true,
                "Color": "green"
            });
        });

    }

}

BCORE.prototype.startTransfer = function (callback) {
    let t = this;

    DBG(" ---------------- startTransfer ", {
        "type": "botlogin",
        "Date": true,
        "Color": "cyan"
    });

    bcore.transferWS = new WebSocket('ws://' + config.mavensUrl + ':' + config.Port + '/', {
        origin: 'http://' + config.mavensUrl + ':' + config.Port + ''
    });
    bcore.transferWS.on('message', function incoming(message) {

        let msg = JSON.parse(message);

        switch (msg.Command) {
        case "transferBotTables":
            bcore.recreateBot(msg.Tables);

            /*
            for(let tb of msg.Tables){
            bcore.Tables[tb.GameID].reCreate(tb.obj);

            ////////(bcore.Tables[tb.GameID].Players);
            }*/
            break;
        case "botList":
            bcore.transferList = msg.List;
            bcore.makeTransfer(() => {});
            break;

        }

    });
    bcore.transferWS.on('open', function open() {
        DBG(" ---------------- get Transfer Response ", {
            "type": "botlogin",
            "Date": true,
            "Color": "cyan"
        });
        bcore.transferWS.send(JSON.stringify({
                "Response": "transferBots"
            }));
    });

    bcore.transferWS.on('close', function close() {
        setTimeout(() => {
            //////("Trying to turn monitor on");
            bcore.monitorOn();

            DBG("Loaded", {
                "type": "system",
                "Date": true
            });
            setTimeout(() => {

                bcore.checkTimerNew(function () {});

            }, 6000);

        }, 2000);

    });
}
BCORE.prototype.makeTransfer = function (callback) {
    let t = this;

    if (t.transferList.length) {
        let Player = t.transferList[0];
        DBG(" ---------------- makeTransfer " + Player, {
            "type": "botlogin",
            "Date": true,
            "player": Player,
            "Color": "cyan"
        });

        if (typeof Player != "undefined") {
            bcore.Clients[Player.toLowerCase()].setStatus({
                "status": "transfering"
            });

            bcore.loadBotTables(Player, (tbs) => {
                ////////(tbs);


            });

            /*
            bcore.transferWS.send(JSON.stringify({"Response":"transferBotTables","Player":Player}));
             */
        }
    } else {
        //////("get close");
        setTimeout(() => {
            //////("close socket",bcore.monitorSocket._server,typeof bcore.monitorSocket._server.close);

            bcore.monitorSocket._server.close(() => {});
            //////("closed success");
            setTimeout(() => {

                //////("get exit");
                process.exit(1);
                return true;

            }, 500);

            //});


        }, 1500);
    }

}
BCORE.prototype.recreateBot = function (bottables, callback) {
    var t = this;
    //let row = formdata;

    let botName = bottables.length && bottables[0].Player != "" ? bottables[0].Player : false;
    ////////("this bot",botName,bottables);
    if (botName != false) {
        DBG("Created BOT : " + botName, {
            "type": "botseat",
            "Date": true,
            "details": false,
            "player": botName
        });
        //////////("Create BOT : " + row.Player + " | T : " + row.Table + "_" + t.finOutCounter,{"type": "botseat","Date":DBG.getTimer(),"player":row.Player});
        //t.spendedTime += t.botTimers[t.finOutCounter];

        var newbot = t.Clients[botName.toLowerCase()];

        if (typeof newbot == "undefined") {

            DBG("Get new bot " + typeof newbot, {
                "type": "botseat",
                "Date": true,
                "details": false,
                "player": botName
            });
            t.Clients[botName.toLowerCase()] = new botClass({
                "Player": botName
            }, function (bt, row) {

                bt.recreateTable(bottables, 0, () => {
                    //////("bot created success and login",bt.Player);

                    bt.actionType = "recreate";
                    bt.actionNum = 0;
                    bt.nextAct();

                });
                /*

                bt.shouldOpen.push(row.Table);
                bt.nextAct(row,()=>{
                 */

            });

        }

    }

    //	callback(newbot);


}

BCORE.prototype.createTourBot = function (row, callback) {
    var t = this;
    let player = row.Player;

    DBG("Created BOT : " + player + "  time : " + row.Time, {
        "type": "botseat",
        "Date": true,
        "details": false,
        "player": player
    });
    //////////("Create BOT : " + row.Player + " | T : " + row.Table + "_" + t.finOutCounter,{"type": "botseat","Date":DBG.getTimer(),"player":row.Player});
    t.spendedTourTime += row.Time;

    var newbot = t.Clients[player.toLowerCase()];

    if (typeof newbot == "undefined") {

        DBG("Get new bot " + typeof newbot, {
            "type": "botseat",
            "Date": true,
            "details": false,
            "player": player
        });
        t.Clients[player.toLowerCase()] = new botClass({
            "Player": player,
            "actionTimer": t.spendedTourTime
        }, function (bt) {

            //	bt.shouldOpen.push(row.Table);
            ///////(bt.shouldOpen,row);
            bt.actionType = "tour";
            if (typeof bt.tournaments[row.tourName] == "undefined") {

                bt.tournaments[row.tourName] = {
                    "Rebuys": row.Rebuys,
                    "Rebought": 0
                };
            }
            bt.tourRegisterCheck = row.tourName;
            bt.nextAct({}, () => {
                /*
                newB.actionTimer = 3;
                newB.nextAct(row,()=>{


                ////////("end");


                });



                 */

            });

        });

    } else {
        ////////("already login",newbot.Player,newbot.loginStatus,newbot.LoginProcess,newbot.actionNum,newbot.actionType);
        //newbot.shouldOpen.push(row.Table);

        if (newbot.loginStatus == "getlogout" || newbot.loginStatus == "logoutrequest") {
            newbot.loginStatus = "Ok";

        }
        if (newbot.LoginProcess == false) {
            newbot.actionNum = 0;
            newbot.nextAct(row, () => {});

        } else {
            if (newbot.LoginProcess == "pending") {
                setTimeout(() => {
                    //newbot.actionNum = 1;
                    //newbot.nextAct();


                }, 2000);

            } else {
                if (newbot.LoginProcess) {

                    newbot.actionNum = 1;
                    newbot.nextAct();

                }
            }

        }
        DBG("BOT ALREADY Loged in : " + row.Player, {
            "Color": "white",
            "type": "botseat",
            "Date": true,
            "details": false,
            "player": row.Player
        });
        //////////("ALREADY LOGIN",newbot.Status,newbot.Player);

    }

    callback(newbot);

}
BCORE.prototype.createBot = function (formdata, callback) {
    var t = this;
    let row = formdata;
    ////////("por",row);
    if (formdata.Player == 0) {

        var pls = t.myshuffle(botData.Bots["1"]);
        row.Player = pls[0];

    } else {
        if (formdata.Player != "" && formdata.Player.length > 2) {
            row.Player = formdata.Player;

        }
    }
    DBG("Created BOT : " + row.Player + " | T : " + row.Table + "_" + t.finOutCounter, {
        "type": "botseat",
        "Date": true,
        "details": false,
        "player": row.Player
    });
    //////////("Create BOT : " + row.Player + " | T : " + row.Table + "_" + t.finOutCounter,{"type": "botseat","Date":DBG.getTimer(),"player":row.Player});
    t.spendedTime += t.botTimers[t.finOutCounter];

    var newbot = t.Clients[row.Player.toLowerCase()];

    if (typeof newbot == "undefined") {

        DBG("Get new bot " + typeof newbot, {
            "type": "botseat",
            "Date": true,
            "details": false,
            "player": row.Player
        });
        t.Clients[row.Player.toLowerCase()] = new botClass({
            "Player": row.Player,
            "actionTimer": t.spendedTime
        }, function (bt) {

            bt.shouldOpen.push(row.Table);
            //////(bt.shouldOpen,row);
            bt.nextAct(row, () => {
                /*
                newB.actionTimer = 3;
                newB.nextAct(row,()=>{


                ////////("end");


                });



                 */

            });

        });

    } else {
        ////////("already login",newbot.Player,newbot.loginStatus,newbot.LoginProcess,newbot.actionNum,newbot.actionType);
        newbot.shouldOpen.push(row.Table);

        if (newbot.loginStatus == "getlogout" || newbot.loginStatus == "logoutrequest") {
            newbot.loginStatus = "Ok";

        }
        if (newbot.LoginProcess == false) {
            newbot.actionNum = 0;
            newbot.nextAct(row, () => {});

        } else {
            if (newbot.LoginProcess == "pending") {
                setTimeout(() => {
                    //newbot.actionNum = 1;
                    //newbot.nextAct();


                }, 2000);

            } else {
                if (newbot.LoginProcess) {

                    newbot.actionNum = 1;
                    newbot.nextAct();

                }
            }

        }
        DBG("BOT ALREADY Loged in : " + row.Player, {
            "Color": "white",
            "type": "botseat",
            "Date": true,
            "details": false,
            "player": row.Player
        });
        //////////("ALREADY LOGIN",newbot.Status,newbot.Player);

    }

    callback(newbot);

}

BCORE.prototype.nextBot = function (callback) {

    var t = this;
    if (t.finOutCounter < t.finOut.length) {
        var row = t.finOut[t.finOutCounter];
        t.createBot(row, (newBot) => {
            t.finOutCounter++;

            setTimeout(function () {
                t.nextBot(callback);
            }, 1000);
        });
    } else {
        callback();
    }

}
BCORE.prototype.GetAutoSeatBot = function (times, callback) {

    var t = this;
    let data = t.finOut;
    if (t.finOutCounter < data.length) {
        var row = data[t.finOutCounter];
        DBG("Get BOT : " + row.Player + " | T : " + row.Table, {
            "type": "botseat",
            "Date": true,
            "details": true
        });
        var newbot = t.Clients[row.Player.toLowerCase()];
        if (typeof newbot == "undefined") {

            DBG("Get new bot " + typeof newbot, {
                "type": "botseat",
                "Date": true,
                "details": true
            });
            newbot = new bot({
                "Player": row.Player
            }, function (bt) {

                t.Clients[row.Player.toLowerCase()] = bt;

            });

        } else {
            if (newbot.loginStatus == "getlogout") {
                newbot.loginStatus = "Ok";

            }

            DBG("BOT ALREADY Loged in : " + row.Player, {
                "Color": "white",
                "type": "botseat",
                "Date": true,
                "details": false
            });

        }

        DBG("Get SEAT : " + row.Player + " | T : " + row.Table, {
            "Color": "yellow",
            "type": "botseat",
            "Date": true,
            "details": true
        });
        newbot.Seat(row.Table, function () {

            DBG("After sit BOT : " + row.Player + "     | " + (typeof times[(t.finOutCounter + 1)] == "undefined" ? " LAST BOT" : "     Next Bot in " + times[(t.finOutCounter + 1)] + " seconds"), {
                "type": "botseat",
                "Date": true,
                "details": false
            });
            DBG(" --------------------------- ", {
                "type": "botseat",
                "Date": false,
                "details": false,
                "Color": "green"
            });

            setTimeout(function () {
                t.finOutCounter++;
                t.GetAutoSeatBot(times, callback);
            }, (times[t.finOutCounter] * 1000));

        });

    } else {
        callback();
    }

}
BCORE.prototype.checkTimerLoop = function (data, out, i, callback) {
    var t = this;
    let minsec = botData.Settings.durationTime;
    let limitBot = (botData.Settings.checkTime * 60) / minsec;
    ////(limitBot,minsec,i);
    if (i < data.length && i < limitBot) {
        var row = data[i];
        ////(row, (row.Min - row.Count));
        var pls = t.myshuffle(row.Players);
        //var precentage = Math.floor((Math.random() * (row.Max - row.Min)) + row.Min);

        for (z = 0; z < (row.Min - row.Count); z++) {
            if (typeof pls[z] != "undefined") {
                out.push({
                    "Table": row.Table,
                    "Player": pls[z]
                });
            }
        }

        i++;
        t.checkTimerLoop(data, out, i, callback);

    } else {
        //("checkTimerLoop", out);
        callback(out);
    }
}
BCORE.prototype.checkTimerNewLoop = function (tbls, i, out, list, callback) {

    let kes = Object.keys(list);

    let t = this;

    if (i < kes.length) {

        let tbName = kes[i];

        maven.mvapi({
            "Command": "RingGamesPlaying",
            "Name": tbName
        }, (msg) => {
            if (typeof list[tbName] != "undefined") {
                let plsn = parseInt((list[tbName].min - msg.Count));
                list[tbName].count = msg.Count;

                if (plsn > 0) {

                    out[tbName] = list[tbName];

                }

            }

            i++;
            t.checkTimerNewLoop(tbls, i, out, list, callback);

        });

    } else {

        callback(out);

    }

}
BCORE.prototype.checkTimerNew = function (callback) {

    let t = this;
    DBG.checkTime = Date.now();
    DBG("START CHECKING - " + t.runBots, {
        "type": "system",
        "Date": true,
        "Color": "yellow"
    });
    /*setTimeout(()=>{

    bcore.startTour("tour1",()=>{




    });

    },20000);
    return*/
    if (!t.runBots) {
        DBG("CHECK OFF", {
            "type": "system",
            "Date": true,
            "Color": "yellow"
        });
        callback();
        return true;
    }

    //t.loadTourPlayers("Holdem 30M 4Shanbe 9 Shab",10);
    const d = new Date(Date.now());
    var hour = d.getHours();
    hour = hour == 0 ? 23 : (hour - 1);
    //hour = 1;
    var row = botData.Hours[hour.toString()];
    let list = typeof row == "undefined" ? {
        "Tables": {}
    }
     : row;
    list = list.Tables;

    let out = {};
    //let list = {"060 Holdem #1k-2K":"4","370 Omaha #50K-100K":"3"};
    /* list =
{
    "060 Holdem #1k-2K": {
    "players": [459, 468],
    "min": 3,
    "list": 1
    },
    "370 Omaha #50K-100K": {
    "players": [359, 368],
    "min": 4,
    "list": 1
    }
    }*/
    bcore.checkTourTimer(0, () => {
        //("here");
        maven.mvapi({
            "Command": "RingGamesList",
            "Fields": "Name"
        }, (res) => {
            let finout = [];

            t.checkTimerNewLoop(res.Name, 0, {}, list, (out) => {

                for (tbname in out) {

                    var pls = [];
                    var plsOut = [];
                    //	//("this tb",tbname);
                    for (let p = out[tbname].players[0]; p <= out[tbname].players[1]; p++) {
                        let plname = botData.Bots[out[tbname].list][p];
                        pls.push(plname);
                    }
                    console.log("this pls",pls,tbname);

                    for (let z = 0; z < pls.length; z++) {

                        if (bcore.getTable(tbname).playerExists(pls[z])) {

                            pls.splice(z, 1);

                            //plsOut.push(plname);


                        }
                    }
                    let ddt = {
                        "Table": tbname,
                        "Count": out[tbname].count,
                        "Min": out[tbname].min,
                        "Max": out[tbname].min,
                        "Players": pls,
                    };

                    finout.push(ddt);
                }

                t.checkTimerLoop(finout, [], 0, function (finout2) {

                    t.finOut = t.myshuffle(finout2);
                    let systemBots = {};
                    for (let vv of finout2) {
                        systemBots[vv.Player.toLowerCase()] = {
                            "status": "new",
                            "logs": [],
                            "player": vv.Player

                        };

                    }

                    DBG.systemLogs[DBG.checkTime].bots = systemBots;

                    let keyys = Object.keys(DBG.systemLogs).reverse();
                    let logtype = "";
                    let nh = 0;
                    for (let tiss of keyys) {
                        let goo = new Date((parseInt(tiss)));
                        let hour = DBG.addZero((goo.getHours() - 1));
                        let mon = DBG.addZero((goo.getMonth() + 1));

                        let year = goo.getFullYear();
                        let day = DBG.addZero(goo.getDate());
                        let minu = DBG.addZero(goo.getMinutes());
                        let secs = DBG.addZero(goo.getSeconds());
                        if (nh < 5) {
                            logtype += '<tr><td>' + mon + '/' + day + ' - ' + hour + ':' + minu + ':' + secs + '</td><td>' + Object.keys(DBG.systemLogs[tiss].bots).length + '</td></tr>';
                        }
                        nh++;
                    }

                    bcore.sendMonitor({
                        "Command": "startCheckTime",
                        "Type": "Terminated",
                        "timer": (botData.Settings.checkTime * 60),
                        "ht": logtype
                    });
                    let upTo = (botData.Settings.checkTime * 60) / t.finOut.length;
                    upTo = upTo > 10 ? 10 : (upTo > botData.Settings.durationTime ? upTo : botData.Settings.durationTime);

                    var precentage = Math.floor((Math.random() * (upTo - botData.Settings.durationTime)) + botData.Settings.durationTime);
                    let durationTime = t.finOut.length * precentage;
                    //("sli", t.finOut.length, durationTime);
                    var times = t.splitTime(t.finOut.length, durationTime);
                    //(times);
                    var timing = [];
                    for (ti = 0; ti < times.length; ti++) {

                        var Da = new Date(Date.now() + (ti == 0 ? 0 : (times[ti] * 1000)));
                        timing.push({
                            "Player": t.finOut[ti].Player,
                            "Table": t.finOut[ti].Table,
                            "Time": Da.getHours() + ":" + Da.getMinutes() + ":" + Da.getSeconds()
                        });
                    }

                    t.botTimers = times;
                    t.finOutCounter = 0;

                    DBG(t.finOut.length + " Bots add in " + durationTime + " seconds (" + times.length + ")", {
                        "type": "system",
                        "Date": true
                    });
                    DBG("Next Check in " + botData.Settings.checkTime + " minutes", {
                        "type": "system",
                        "Date": true
                    });
                    if (config.debug.system) {
                        DBG.table(timing);
                    }
                    setTimeout(function () {
                        t.checkTimerNew(callback);
                    }, (botData.Settings.checkTime * 60 * 1000));

                    t.nextBot(function () {});
                });

            })
        });

    });

}

BCORE.prototype.getTourRuntime = function (tourName, callback) {
    let tourObj = bcore.Tournaments[tourName];

  

    let start = Date.parse(tourObj.StartTime);
	//now -= 3600000;
	//let iranTime = -3600000;
	let iranTime = 0;
    let now = Date.now() + iranTime;
    let next = DBG.checkTime + (botData.Settings.checkTime * 60 * 1000) + iranTime;
    let rt = tourObj.runTime;

    let d1 = new Date(now);
    let d2 = new Date(rt);
    let d3 = new Date(start);
    let d4 = new Date(next);



	let response = {
        Response: "notyet",
        Remained: 0,
		NOW : "07/" +d1.getDate() + " " + d1.getHours()+":"+d1.getMinutes(), 
		NXT : "07/" +d4.getDate() + " " + d4.getHours()+":"+d4.getMinutes(),
		RUN : "07/" +d2.getDate() + " " + d2.getHours()+":"+d2.getMinutes(),
		STR : "07/" +d3.getDate() + " " + d3.getHours()+":"+d3.getMinutes()
    };
    //console.info("runntime " + tourName, "\n NOW : 07/" +d1.getDate(),d1.getHours()+":"+d1.getMinutes(),  "\n NXT : 07/" +d4.getDate(),d4.getHours()+":"+d4.getMinutes(), "\n RUN : 07/" +d2.getDate(),d2.getHours()+":"+d2.getMinutes(), "\n STR : 07/" +d3.getDate(),d3.getHours()+":"+d3.getMinutes());

    if (start > now) {
        
        if (now > rt) {
//("tourName", rt, tourObj);
            response.Response = "Ok";
            response.Remained = start - rt ;

        } else {

            response.Response = "still";
            response.Remained = rt - next;
        }

    } else {

        response.Response = "expire";
        response.Remained = now - start;
    }
    response.Remained = parseInt((response.Remained / 1000));

    callback(response);

}
BCORE.prototype.getTourRuntimeOLDD = function (tourName, count, callback) {
    //(tourName);
    let tourObj = bcore.Tournaments[tourName];
    let now = Date.now();
    now -= 3600000; // + (botData.Settings.checkTime * 60000) ;
    let StartTime = Date.parse(tourObj.StartTime);

    let nxt = DBG.checkTime + (botData.Settings.checkTime * 60 * 1000) - 3600000;

    let d4 = new Date(nxt);
    let d3 = new Date(StartTime);
    let d2 = new Date(tourObj.runTime);
    let d1 = new Date(now);
    let Response = {
        "Response": "NO",
        "RemainedTime": 0
    };
    if (now < StartTime) {
        if (now > tourObj.runTime) {
            Response.RemainedTime = tourObj.StartTime - now;
            Response.Response = "Start";
        } else {
            Response.RemainedTime = tourObj.runTime - now;
            if (tourObj.runTime < nxt) {
                Response.Response = "Next";
            }

        }
    } else {
        Response.Response = "ExpireStart";

    }

    //console.info("runntime " + tourName, "\n NOW : 07/" + d1.getDate(), d1.getHours() + ":" + d1.getMinutes(), "\n NXT : 07/" + d4.getDate(), d4.getHours() + ":" + d4.getMinutes(), "\n RUN : 07/" + d2.getDate(), d2.getHours() + ":" + d2.getMinutes(), "\n STR : 07/" + d3.getDate(), d3.getHours() + ":" + d3.getMinutes());

}

BCORE.prototype.getTourRuntimeOLD = function (tourName, count, callback) {
    let tourObj = bcore.Tournaments[tourName];

    let limitSec = 30;
    let runTime = tourObj.runTime;
    let StartTime = tourObj.StartTime;
    let now = Date.now();
    now -= 3600000; // + (botData.Settings.checkTime * 60000) ;
    let nxt = now + (botData.Settings.checkTime * 60 * 1000);
    let d5 = new Date(nxt);
    let d3 = new Date(runTime);
    let d2 = new Date(now);
    let d1 = new Date(StartTime);

    //console.info("runntime " + tourName, "\n STR : 07/" + d1.getDate(), d1.getHours() + ":" + d1.getMinutes(), "\n NXT : 07/" + d5.getDate(), d5.getHours() + ":" + d5.getMinutes(), "\n RUN : 07/" + d3.getDate(), d3.getHours() + ":" + d3.getMinutes(), "\n NOW : 07/" + d2.getDate(), d2.getHours() + ":" + d2.getMinutes());
    if (now > tourObj.runTime) {
        //console.info("radshode", tourName);
    } else {
        if (tourObj.runTime <= nxt) {
            //console.info("Start ", tourName);
        }
    }
}
BCORE.prototype.checkTourTimer = function (nu, callback) {


    let t = this;
    let kes = Object.keys(bcore.Tournaments);
    if (nu < kes.length) {

        if (bcore.Tournaments[kes[nu]].tourStatus != "Offline") {
            bcore.getTourRuntime(kes[nu], (response) => {
			//console.log(response);
                if (response.Response != "expire") {
					
					
					console.log(response);
                if (response.Response == "Ok") {
                    t.startTour(kes[nu], () => {
                        nu++;

                        bcore.checkTourTimer(nu, callback);

                    });

                } else {

                    nu++;
                    bcore.checkTourTimer(nu, callback);

                } 
				} else {

                    nu++;
                    bcore.checkTourTimer(nu, callback);

                }
                //(response);

            });
        }

    } else {

        callback();
        return true;

    }
    /*	t.startTour("tour1",(bots)=>{


    t.sendMonitor({"Command":"startTour","Type":"Terminated","botList":bots});


    });
     */
    //t.spendedTourTime = 0;

    /*

    for(let tour in bcore.Tournaments)
{
    if(bcore.Tournaments[tour].tourStatus != "Offline")
{
    let runTime = bcore.getTourRuntime(bcore.Tournaments[tour]);





    }
    }*/
    // agar now + checktim > runtime boro bara start
    //conra();
    //callback();
}
BCORE.prototype.checkTimer = function (callback) {

    var t = this;
    const d = new Date(Date.now());
    var hour = d.getHours();
    if (config.debug.system && t.WaitingLogout.length > 0) {
        DBG("Logout List", {
            "type": "system",
            "Date": true
        });
        DBG.table(t.WaitingLogout);
    }
    var row = botData.Hours[hour.toString()];
    row = typeof row == "undefined" ? botData.Hours["default"] : row;
    var t = this;
    var out = [];
    /*
    maven.mvapi({
    "Command": "ConnectionsList",
    "Fields": "Player"
    }, function(res) {
    for (z = 0; z < res.Player.length; z++) {
    res.Player[z] = res.Player[z].toLowerCase();
    }
    var lgs = row.Logins;
    if (res.Connections < lgs.min) {
    var logincount = lgs.min - res.Connections;
    t.myshuffle(data.Bots);
    var botselected = data.Bots.splice(0, logincount);
    var times = t.splitTime(logincount, 300);
    t.getAutoLogin(botselected, times, 0, function() {});
    }
    });
     */
    /*
    maven.mvapi({
    "Command": "RingGamesList",
    "Fields": "Name",
    }, function(result) {
     */

    for (tbname in row.Tables) {

        var pls = [];
        for (p = row.Tables[tbname].players[0]; p <= row.Tables[tbname].players[1]; p++) {
            pls.push(botData.Bots[row.Tables[tbname].list][p]);

        }
        out.push({
            "Table": tbname,
            "Count": 0,
            "Min": row.Tables[tbname].min,
            "Max": row.Tables[tbname].max,
            "Players": pls,
        });

    }

    t.checkTimerLoop(out, [], 0, function (finout) {
        //////////("rqqrq",t.finOut);
        t.finOut = t.myshuffle(finout);

        var times = t.splitTime(t.finOut.length, botData.Settings.durationTime);
        ////////////(t.finOut,times,botData.Settings.durationTime,t.finOut.length,"ddd");
        var timing = [];
        for (ti = 0; ti < times.length; ti++) {

            var Da = new Date(Date.now() + (ti == 0 ? 0 : (times[ti] * 1000)));
            timing.push({
                "Player": t.finOut[ti].Player,
                "Table": t.finOut[ti].Table,
                "Time": Da.getHours() + ":" + Da.getMinutes() + ":" + Da.getSeconds()
            });
        }
        //////////("ok");
        t.botTimers = times;
        t.finOutCounter = 0;
        DBG("START CHECKING", {
            "type": "system",
            "Date": true,
            "Color": "yellow"
        });
        DBG(t.finOut.length + " Bots add in " + botData.Settings.durationTime + " seconds (" + t.botTimers.length + ")", {
            "type": "system",
            "Date": true
        });
        DBG("Next Check in " + botData.Settings.checkTime + " minutes", {
            "type": "system",
            "Date": true
        });
        if (config.debug.system) {
            DBG.table(timing);
        }
        setTimeout(function () {
            t.checkTimer(botData, callback);
        }, (botData.Settings.checkTime * 60 * 1000));
        t.nextBot(function () {});
    });

    /*
    });

     */
}
/*BCORE.prototype.nextBot = funtion(){




}):*/
BCORE.prototype.myshuffle = function (array) {
    let currentIndex = array.length,
    randomIndex;
    while (currentIndex != 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
    return array;
}
BCORE.prototype.clearplayercards = function (cn) {
    var out = [];
    for (i = 0; i < cn.length; i++) {
        if (cn[i] != 0) {

            out.push(bcore.numtocard(cn[i]));

        }

    }

    return out;
}
BCORE.prototype.numtocard = function (cn) {
    if (cn == 0) {
        return "";
    }
    cn -= 1;
    var bet = cn % 4;
    var rem = cn - bet;
    var n = (rem / 4) + 2;
    var inte = n;
    var kh = "";
    switch (bet) {
    case 0:
        kh = "c";
        break;
    case 1:
        kh = "d";
        break;
    case 2:
        kh = "h";
        break;
    case 3:
        kh = "s";
        break;
    }
    switch (n) {
    case 10:
        inte = "T";
        break;
    case 11:
        inte = "J";
        break;
    case 12:
        inte = "Q";
        break;
    case 13:
        inte = "K";
        break;
    case 14:
        inte = "A";
        break;
    }
    var et = inte + kh;
    return et;
}

BCORE.prototype.registerTourPlayers = (botList, tourName, i, callback) => {
    let t = this;
    if (i < botList.length) {
        let botName = botList[i];
        maven.mvapi({
            "Command": "TournamentsRegister",
            "Name": tourName,
            "Player": botName
        }, (res2) => {
            //("registerTourPlayers", res2, botName);
            i++;
            setTimeout(() => {

                bcore.registerTourPlayers(botList, tourName, i, callback);

            }, 200);

        });

    } else {
        callback();

    }

}
BCORE.prototype.startTourLoop = (tourName, list, i, callback) => {

    if (i < list.length) {
        var row = list[i];
        bcore.createTourBot(row, (newBot) => {
            i++;
            setTimeout(function () {
                bcore.startTourLoop(tourName, list, i, callback);
            }, 1000);
        });
    } else {
        callback();
    }
}

BCORE.prototype.makeTourTables = (tourName, callback) => {
	console.log("========",tourName);
    maven.mvapi({
        "Command": "TournamentsGet",
        "Name": tourName
    }, (tourData) => {
        let n = tourData.Tables;

        console.log(tourData);
        let tbcount = tourData.MaxEntrants / tourData.Seats;
        //let tbcount = tourData.Tables;
		console.log(tbcount);
        for (let i = 1; i <= tbcount; i++) {
            let tourTBname = tourName + " - Table " + i;
            var tbs = bcore.getTable(tourTBname);
			console.log("tbs",tbs);
            if (tbs == false) {
                bcore.Tables[tourTBname] = new mkTable({
                    "ID": tourTBname,
					"Type":"T",
                    "Game": tourData.Game,
                    "Seats": tourData.Seats,
                    "Playing": 0,
                    "Waiting": 0,
                    "bots": {},
                    "state": 0,
                    "flop": [0, 0, 0, 0, 0],
                    "total": 0,
                    "SB": 1,
                    "BB": 2,
                    "BuyinMin": 0,
                    "BuyinMax": 0,
                    "hands": {
                        "rrrr": "eeee"
                    },
                    "handnumber": false,
                    "showapi": bcore.showapi
                });
            }
        }
console.log(Object.keys(bcore.Tables));
        callback();

    });

}
BCORE.prototype.getTourRegisterList = (tourName, callback) => {
    maven.mvapi({
        "Command": "TournamentsWaiting",
        "Name": tourName
    }, (res) => {
        let list = [];

        for (let bb in botData.TourBots) {
            botData.TourBots[bb] = botData.TourBots[bb].toLowerCase();
        }
        for (let pl of res.Wait) {

            let ex = pl.split("|");
            let plnameex = ex[0].split("=");
            if (botData.TourBots.indexOf(plnameex[0].toLowerCase()) > -1) {
                list.push(plnameex[0].toLowerCase()); //,Time:times[n],tourName:tourName});
            }
        }
        callback(list);

    });
}
BCORE.prototype.tourMakeConnectionList = (tourName, callback) => {
    bcore.getTourRegisterList(tourName, (list) => {

        let newlist = [];
        let n = 0;
        for (let bb in botData.TourBots) {
            if (list.indexOf(botData.TourBots[bb].toLowerCase()) == -1) {
                if (typeof botData.Tournaments[tourName] != "undefined") {
                    if (n < botData.Tournaments[tourName].Bots) {
                        newlist.push(botData.TourBots[bb]);
                        n++;
                    }
                }else{
					
					if (n < 30) {
                        newlist.push(botData.TourBots[bb]);
                        n++;
                    }
				}
            }
        }
        let retList = newlist.concat(list);
        callback(retList);

    });

}
BCORE.prototype.startTour = (tourName, callback) => {
    let t = this;
    bcore.runBots = false;

    console.log("startTour", tourName);
    //make tables
	
    bcore.makeTourTables(tourName, () => {
        let spendTime = 0;
        bcore.tourMakeConnectionList(tourName, (list) => {
            bcore.getTourRuntime(tourName, (response) => {
				console.log("reeess",response);
                if (response.Response == "Ok") {
                    let bet = response.Remained % 60;
                    let mins = (response.Remained - bet) / 60;
                    let finalList = [];
                    let times = bcore.splitTime(list.length, response.Remained);
					let minRebuy = (typeof botData.Tournaments[tourName] != "undefined") ? parseInt(botData.Tournaments[tourName].MinRebuy) : 1;
					let maxRebuy = (typeof botData.Tournaments[tourName] != "undefined") ? parseInt(botData.Tournaments[tourName].MaxRebuy) : 2;
                    for (let pl in list) {
                        spendTime += times[pl];
						let botRebuys = Math.floor((Math.random() * (maxRebuy - minRebuy)) + minRebuy);
						finalList.push({
                            "Player": list[pl],
                            "Time": times[pl],
                            "tourName": tourName,
                            "spendTime": spendTime,
                            "status": "pending",
							"Rebuys":botRebuys
                        });
                        bcore.tourPlayers.push({
                            "player": list[pl].toLowerCase(),
                            "spendTime": spendTime
                        });

                    }
                    bcore.sendMonitor({
                        "Command": "startTour",
                        "Type": "Terminated",
                        "botList": finalList,
                        "tourName": tourName,
                        remained: response.Remained
                    });

                    bcore.startTourLoop(tourName, finalList, 0, () => {

                        callback();

                    });

                } else {

                    //("Error : " + response.Response);

                }

            });

            /*let times = bcore.splitTime(res.Count, 600);*/
            /*
            bcore.startTourLoop(tourName,list,0,()=>{
            callback();


            });

             */

        });
    });

}
BCORE.prototype.loadTourPlayersOK = (tourName, count) => {
    let list = [{
            "Player": "888",
            "Time": 5,
            "tourName": tourName
        }, {
            "Player": "797",
            "Time": 5,
            "tourName": tourName
        }
    ];
    bcore.startTourLoop(tourName, list, 0, () => {
        //("end");

    });
}
BCORE.prototype.loadTourPlayers = (tourName, count) => {
    let t = this;
    //console.info("load tour", tourName);
    let botList = [];
    for (let i in botData.Bots[1]) {
        if (i > 0 && i < count) {
            botList.push(botData.Bots[1][i]);

        }

    }
    //console.info("load tour", tourName);
    bcore.registerTourPlayers(botList, tourName, 0, () => {

        bcore.startTour(tourName, () => {});

    });

}

module.exports = BCORE;
