

WebSocket = require('ws');
let monitorSocket = new WebSocket.Server({
			port: 1212
		},function(){
			console.log("ok");
		
		});
		monitorSocket.on('connection', function connection(ws, req) {
			ws.on('message', function incoming(message) {
					var res = JSON.parse(message);
					
					
					switch(res.Response)
					{
						case "Connect":
						setTimeout(function(){
						
						
						//ws.send(JSON.stringify({"Command":"getCards","Table":"R0605 Holdem #1k-2K"}));
						ws.send(JSON.stringify({"Command":"getCards","Table":"R5190 O 5 Cards #5K-5K"}));
						
						
						},10000);
						break;
						case "returnCards":
						
						console.log(res);
						
						break;
						
						
					}
					
					
			});
			
		});