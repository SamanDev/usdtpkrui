function deec(){}


deec.HandHelper = function (ce) {
	var t = this;
		ch = t.bf(ce.eSeed + t.aq(ce.HSalt));
		//ch = m(bn.eSeed + aj(ce.HSalt));
		cj = parseInt(ch.substring(0, 8), 16);
		cg = parseInt(t.aq(ce.HRank), 16) ^ cj;
		cd = t.bf(ce.eSeed + t.aq(ce.LSalt));
		ci = parseInt(cd.substring(0, 8), 16);
		g = parseInt(t.aq(ce.LRank), 16) ^ ci;
		if (g == 0) {
			cf = deec.lang.HandHelper.split("%1%").join(t.bo(cg))
			//cf = bo(cg);
		} else {
			if (cg == 0) {
				cf = deec.lang.HandHelper.split("%1%").join(t.ah(g));
			//	cf = ah(g);
			} else {
				cf = deec.lang.HandHelperHiLo.split("%1%").join(t.bo(cg));
				cf = cf.split("%2%").join(t.ah(g))
				//cf = bo(cg);
			}
		}
		return cf;
	}


deec.bo = function(ci) {
		var g, cd, cj, ch, cg, cf, ce;
		g = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"];
		cj = (ci & 983040) >>> 16;
		ch = (ci & 61440) >>> 12;
		cg = (ci & 3840) >>> 8;
		cf = (ci & 240) >>> 4;
		ce = ci & 15;
		if (ci == 10411194) {
			cd = deec.lang.HandRoyalFlush
		} else {
			if (ci >= 9437184) {
				cd = deec.lang.HandStraightFlushLong.split("%1%").join(deec.N(ce));
				cd = cd.split("%2%").join(deec.N(cj))
			} else {
				if (ci >= 8388608) {
					cd = deec.lang.HandFourOfAKindLong.split("%1%").join(deec.p(cj));
					cd = cd.split("%2%").join(g[ce])
				} else {
					if (ci >= 7340032) {
						cd = deec.lang.HandFullHouseLong.split("%1%").join(deec.p(cj));
						cd = cd.split("%2%").join(deec.p(cf))
					} else {
						if (ci >= 6291456) {
							cd = deec.lang.HandFlushLong.split("%1%").join(deec.N(cj));
							cd = cd.split("%2%").join(g[ch] + g[cg] + g[cf] + g[ce])
						} else {
							if (ci >= 5242880) {
								cd = deec.lang.HandStraightLong.split("%1%").join(deec.N(ce));
								cd = cd.split("%2%").join(deec.N(cj))
							} else {
								if (ci >= 4194304) {
									cd = deec.lang.HandThreeOfAKindLong.split("%1%").join(deec.p(cj));
									cd = cd.split("%2%").join(g[cf] + g[ce])
								} else {
									if (ci >= 3145728) {
										cd = deec.lang.HandTwoPairLong.split("%1%").join(deec.p(cj));
										cd = cd.split("%2%").join(deec.p(cg));
										cd = cd.split("%3%").join(g[ce])
									} else {
										if (ci >= 2097152) {
											if (ce != 0) {
												cd = deec.lang.HandPairLong
											} else {
												cd = deec.lang.HandPairShort
											}
											cd = cd.split("%1%").join(deec.p(cj));
											if (ce != 0) {
												cd = cd.split("%2%").join(g[cg] + g[cf] + g[ce])
											}
										} else {
											if (ci >= 1048576) {
												if (ce != 0) {
													cd = deec.lang.HandHighCardLong
												} else {
													cd = deec.lang.HandHighCardShort
												}
												cd = cd.split("%1%").join(deec.N(cj));
												if (ce != 0) {
													cd = cd.split("%2%").join(g[ch] + g[cg] + g[cf] + g[ce])
												}
											} else {
												cd = "?"
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return cd
	}


	 deec.N = function(g) {
		switch (g) {
			case 1:
				return deec.lang.CardsAce;
			case 2:
				return deec.lang.CardsDeuce;
			case 3:
				return deec.lang.CardsThree;
			case 4:
				return deec.lang.CardsFour;
			case 5:
				return deec.lang.CardsFive;
			case 6:
				return deec.lang.CardsSix;
			case 7:
				return deec.lang.CardsSeven;
			case 8:
				return deec.lang.CardsEight;
			case 9:
				return deec.lang.CardsNine;
			case 10:
				return deec.lang.CardsTen;
			case 11:
				return deec.lang.CardsJack;
			case 12:
				return deec.lang.CardsQueen;
			case 13:
				return deec.lang.CardsKing;
			case 14:
				return deec.lang.CardsAce;
			default:
				return "?"
		}
	}



	deec.p = function(g) {
		switch (g) {
			case 1:
				return deec.lang.CardsAces;
			case 2:
				return deec.lang.CardsDeuces;
			case 3:
				return deec.lang.CardsThrees;
			case 4:
				return deec.lang.CardsFours;
			case 5:
				return deec.lang.CardsFives;
			case 6:
				return deec.lang.CardsSixes;
			case 7:
				return deec.lang.CardsSevens;
			case 8:
				return deec.lang.CardsEights;
			case 9:
				return deec.lang.CardsNines;
			case 10:
				return deec.lang.CardsTens;
			case 11:
				return deec.lang.CardsJacks;
			case 12:
				return deec.lang.CardsQueens;
			case 13:
				return deec.lang.CardsKings;
			case 14:
				return deec.lang.CardsAces;
			default:
				return "?"
		}
	}


deec.ah = function(cg) {
		var g, cd, cf, ce = [];
		g = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"];
		if (cg == 16777215) {
			return "";
		}
		ce[1] = (cg >>> 16) & 15;
		ce[2] = (cg >>> 12) & 15;
		ce[3] = (cg >>> 8) & 15;
		ce[4] = (cg >>> 4) & 15;
		ce[5] = cg & 15;
		cf = "";
		for (cd = 1; cd <= 5; cd++) {
			cf = cf + g[ce[cd]]
		}
		return cf
	}



deec.ECards = function(bg) {
	var t = this;
		//console.log("BBBBBG",bg);
		g = t.bf(bg.eSeed + t.aq(bg.Salt));
		bw = parseInt(g.substring(0, 2), 16);
		bv = parseInt(g.substring(2, 4), 16);
		bu = parseInt(g.substring(4, 6), 16);
		bt = parseInt(g.substring(6, 8), 16);
		bs = parseInt(g.substring(8, 10), 16);
		bq = parseInt(g.substring(10, 12), 16);
		bn = parseInt(t.aq(bg.Card1), 16) ^ bw;
		bm = parseInt(t.aq(bg.Card2), 16) ^ bv;
		bl = parseInt(t.aq(bg.Card3), 16) ^ bu;
		bk = parseInt(t.aq(bg.Card4), 16) ^ bt;
		bj = parseInt(t.aq(bg.Card5), 16) ^ bs;
		bi = parseInt(t.aq(bg.Card6), 16) ^ bq;
		br = t.aq(bg.Hand);
		if (bn < 0 || bn > 53) {
			bn = 0
		}
		if (bm < 0 || bm > 53) {
			bm = 0
		}
		if (bl < 0 || bl > 53) {
			bl = 0
		}
		if (bk < 0 || bk > 53) {
			bk = 0
		}
		if (bj < 0 || bj > 53) {
			bj = 0
		}
		if (bi < 0 || bi > 53) {
			bi = 0
		}
		bp = {"cardNum":[0,0,0,0,0],"holeCards":5};
	
		bp.cardNum[1] = bn;
		bp.cardNum[2] = bm;
		if (bp.holeCards > 2 && bp.holeCards < 7) {
			bp.cardNum[3] = bl;
			bp.cardNum[4] = bk
		}
		if (bp.holeCards > 4 && bp.holeCards < 7) {
			bp.cardNum[5] = bj
		}
		if (bp.holeCards == 6) {
			bp.cardNum[6] = bi
		}
		if (bp.holeCards == 7) {
			bp.cardNum[7] = bl;
			if (bl > 0) {
				bn = bl;
				bm = 0;
				bl = 0
			}
		}
		bh = [];
		for (bo = 0; bo < 5; bo++) {
			bh[bo] = bp.cardNum[bo + 1]
		}
		
		//console.log("bh",bh);
		return bh;
		/*
		bp.replayMyCards.push({
			hand: br,
			cards: bh
		});
		bp.historyAdd(br, U.lang.HHDealt.split("%1%").join(U.loginData.player).split("%2%").join(aC(bn, bm, bl, bk, bj, bi)));
		if (bg.Show == "Yes") {
			bp.isFaceDown = false;
			bp.showHoleCards();
			bp.handHelper = "";
			bp.updateHandHelper()
		}*/
	};
	


deec.bf = function (bs) {
		function bo(bt, bw) {
			var bv, bu;
			bv = (bt & 65535) + (bw & 65535);
			bu = (bt >> 16) + (bw >> 16) + (bv >> 16);
			return (bu << 16) | (bv & 65535)
		}

		function bk(bu, bt) {
			return (bu >>> bt) | (bu << (32 - bt))
		}

		function bl(bu, bt) {
			return (bu >>> bt)
		}

		function g(bt, bv, bu) {
			return ((bt & bv) ^ ((~bt) & bu))
		}

		function bj(bt, bv, bu) {
			return ((bt & bv) ^ (bt & bu) ^ (bv & bu))
		}

		function bm(bt) {
			return (bk(bt, 2) ^ bk(bt, 13) ^ bk(bt, 22))
		}

		function bh(bt) {
			return (bk(bt, 6) ^ bk(bt, 11) ^ bk(bt, 25))
		}

		function br(bt) {
			return (bk(bt, 7) ^ bk(bt, 18) ^ bl(bt, 3))
		}

		function bp(bt) {
			return (bk(bt, 17) ^ bk(bt, 19) ^ bl(bt, 10))
		}

		function bi(bu, bv) {
			var bw, bH, bt, bJ, bI, bG, bF, bD, bB, bA, bz, by, bx, bE, bC;
			bw = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
			bH = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
			bt = new Array(64);
			bu[bv >> 5] |= 128 << (24 - bv % 32);
			bu[((bv + 64 >> 9) << 4) + 15] = bv;
			for (by = 0; by < bu.length; by += 16) {
				bJ = bw[0];
				bI = bw[1];
				bG = bw[2];
				bF = bw[3];
				bD = bw[4];
				bB = bw[5];
				bA = bw[6];
				bz = bw[7];
				for (bx = 0; bx < 64; bx++) {
					if (bx < 16) {
						bt[bx] = bu[bx + by]
					} else {
						bt[bx] = bo(bo(bo(bp(bt[bx - 2]), bt[bx - 7]), br(bt[bx - 15])), bt[bx - 16])
					}
					bE = bo(bo(bo(bo(bz, bh(bD)), g(bD, bB, bA)), bH[bx]), bt[bx]);
					bC = bo(bm(bJ), bj(bJ, bI, bG));
					bz = bA;
					bA = bB;
					bB = bD;
					bD = bo(bF, bE);
					bF = bG;
					bG = bI;
					bI = bJ;
					bJ = bo(bE, bC)
				}
				bw[0] = bo(bJ, bw[0]);
				bw[1] = bo(bI, bw[1]);
				bw[2] = bo(bG, bw[2]);
				bw[3] = bo(bF, bw[3]);
				bw[4] = bo(bD, bw[4]);
				bw[5] = bo(bB, bw[5]);
				bw[6] = bo(bA, bw[6]);
				bw[7] = bo(bz, bw[7])
			}
			return bw
		}

		function bg(bv) {
			var bt, bu, bw;
			bt = "";
			for (bu = 0; bu < bv.length; bu++) {
				bw = bv.charCodeAt(bu);
				if (bw < 128) {
					bt += String.fromCharCode(bw)
				} else {
					if (bw < 2048) {
						bt += String.fromCharCode((bw >> 6) | 192);
						bt += String.fromCharCode((bw & 63) | 128)
					} else {
						bt += String.fromCharCode((bw >> 12) | 224);
						bt += String.fromCharCode(((bw >> 6) & 63) | 128);
						bt += String.fromCharCode((bw & 63) | 128)
					}
				}
			}
			return bt
		}

		function bn(bw) {
			var bv, bt, bu;
			bv = new Array();
			bt = 255;
			for (bu = 0; bu < bw.length * 8; bu += 8) {
				bv[bu >> 5] |= (bw.charCodeAt(bu / 8) & bt) << (24 - bu % 32)
			}
			return bv
		}

		function bq(bv) {
			var bu, bw, bt;
			bu = "0123456789ABCDEF";
			bw = "";
			for (bt = 0; bt < bv.length * 4; bt++) {
				bw += bu.charAt((bv[bt >> 2] >> ((3 - bt % 4) * 8 + 4)) & 15) + bu.charAt((bv[bt >> 2] >> ((3 - bt % 4) * 8)) & 15)
			}
			return bw
		}
		bs = bg(bs);
		return bq(bi(bn(bs), bs.length * 8))
	}
	
	
	
deec.aj = function(bg) {
	var t = this;
		if (bg.length == 0) {
			return ""
		}
		var g, bh;
		g = Math.round(Math.random() * 4294967295).toString(16).toUpperCase();
		while (g.length < 8) {
			g = "0" + g
		}
		bh = t.bf(t.bf(bg + g));
		return g + "-" + bh
	}
	

deec.aq = function(g) {
		if (g == null) {
			return ""
		} else {
			return String(g)
		}
	}	
	
	
deec.lang = {
		"Command": "Language",
		"Language": 0,
		"Languages": 0,
		"FontFamily": "Arial, sans-serif",
		"LanguageTitle": "Language",
		"Language1": "Language 1",
		"Language2": "Language 2",
		"Language3": "Language 3",
		"Language4": "Language 4",
		"Language5": "Language 5",
		"LanguageNote": "Language change will take effect on your next login.",
		"AboutTitle": "About",
		"BalanceTitle": "Account Balance",
		"BalancePrimary": "Primary Balance",
		"BalanceSecondary": "Secondary Balance",
		"BalanceAvailable": "Available:",
		"BalanceInPlay": "In play:",
		"BalanceTotal": "Total:",
		"BalanceTransactions": "Show Transactions",
		"AccountNew": "Create New Account",
		"AccountChange": "Change Account Information",
		"AccountPlayer": "Player name:",
		"AccountPlayerDesc": "This is your login\/screen name (12 characters max). It may include letters, numbers, dashes, and underscores.",
		"AccountReal": "Real name:",
		"AccountRealDesc": "This is an optional field to specify your real name, up to 50 characters.",
		"AccountGender": "Gender:",
		"AccountMale": "Male",
		"AccountFemale": "Female",
		"AccountUnspecified": "Unspecified",
		"AccountEmail": "Email address:",
		"AccountEmailDesc": "Your email address is used for account validation and password recovery. It is not displayed to the other players.",
		"AccountAvatar": "Avatar:",
		"AccountAvatarDesc": "Select an avatar to display in your seat at the tables.",
		"AccountLocation": "Location:",
		"AccountLocationDesc": "This is an optional field to specify your location (city, country, etc.), up to 50 characters.",
		"AccountCustom1": "",
		"AccountCustom2": "",
		"AccountCustom3": "",
		"AccountCustom4": "",
		"AccountCustom5": "",
		"AccountPWSelect": "Select password:",
		"AccountPWConfirm": "Confirm password:",
		"AccountPWDesc": "Longer passwords offer better security.",
		"AccountPWDesc2": "Leave blank to keep current password.",
		"AccountPWError": "Error: second password does not match the first one.",
		"ChipsTitle": "Add chips",
		"ChipsMin": "Up to minimum buy-in",
		"ChipsMax": "Up to maximum buy-in",
		"ChipsOther": "Other amount:",
		"ChipsAuto": "Auto rebuy to new chip count",
		"ChipsInvalid": "Invalid amount specified",
		"ChipsRebuy": "Buy another batch of chips and deduct the rebuy fee (%1%) from your account?",
		"ChopCaption": "Independent Chip Model (ICM) Chop Agreement",
		"ChopPlace": "Place",
		"ChopPayout": "Payout",
		"ChopPlayer": "Player",
		"ChopStack": "Stack",
		"ChopChop": "Chop",
		"ChopAccept": "Accept",
		"ChopDecline": "Decline",
		"ArrangeTitle": "Arrange Windows",
		"ArrangeLobby": "Include lobby window",
		"ArrangeCascade": "Cascade windows",
		"ArrangeTile": "Tile windows",
		"MouseOverSeat": "Seat",
		"MouseOverFrom": "from",
		"MouseOverChips": "Chips",
		"MouseOverTimeBank": "Time bank",
		"MouseOverAway": "Away",
		"MouseOverTitle": "Title",
		"MouseOverLevel": "Level",
		"BuyInTitle": "Seat Available",
		"BuyInMessage": "Select a buy-in amount and then click OK within %1% seconds to accept a seat at %2%",
		"BuyInSeconds": "Seconds:",
		"BuyInTourney": "Do you want to register for this tournament?",
		"BuyInTotal": "Total buy-in: %1%",
		"BuyInBalance": "Your current balance: %1%",
		"BuyInMin": "Minimum Buy-In:",
		"BuyInMax": "Maximum Buy-In:",
		"BuyInOther": "Other Buy-In:",
		"BuyInAuto": "Auto rebuy to this amount",
		"BuyInRathole": "** Rathole period still in effect. You must return with at least as many chips as you had when you left. **",
		"BuyInMessageMin": "Minimum buy-in at this table is %1%",
		"BuyInMessageMax": "Maximum buy-in at this table is %1%",
		"BuyInTicket": "Buy-in ticket: %1%",
		"BuyInHasTicket": "You have ticket: %1%",
		"BuyInSelect": "Select buy-in option:",
		"BuyInUseTicket": "Use ticket: %1%",
		"BuyInPay": "Pay %1% from balance %2%",
		"CardsAce": "Ace",
		"CardsAces": "Aces",
		"CardsDeuce": "Deuce",
		"CardsDeuces": "Deuces",
		"CardsThree": "Three",
		"CardsThrees": "Threes",
		"CardsFour": "Four",
		"CardsFours": "Fours",
		"CardsFive": "Five",
		"CardsFives": "Fives",
		"CardsSix": "Six",
		"CardsSixes": "Sixes",
		"CardsSeven": "Seven",
		"CardsSevens": "Sevens",
		"CardsEight": "Eight",
		"CardsEights": "Eights",
		"CardsNine": "Nine",
		"CardsNines": "Nines",
		"CardsTen": "Ten",
		"CardsTens": "Tens",
		"CardsJack": "Jack",
		"CardsJacks": "Jacks",
		"CardsQueen": "Queen",
		"CardsQueens": "Queens",
		"CardsKing": "King",
		"CardsKings": "Kings",
		"ConnectTitle": "Connection",
		"ConnectRetry": "Connection lost. Retrying...",
		"ContactTitle": "Contact",
		"ContactEmail": "Administrator's Email",
		"ContactWeb": "Administrator's Web Site",
		"ContactNone": "(none given)",
		"DialogMessage": "Message",
		"DialogConfirm": "Confirm",
		"DialogOK": "OK",
		"DialogCancel": "Cancel",
		"DialogSave": "Save",
		"DisplayTitle": "Display Settings",
		"DisplayInterface": "Interface",
		"DisplayDesktop": "Desktop",
		"DisplayMobile": "Mobile",
		"DisplayAutoDetect": "Auto detect",
		"DisplayNumber": "Number Format",
		"DisplayFont": "Font Size",
		"DisplayFontSmall": "Small",
		"DisplayFontNormal": "Normal",
		"DisplayFontLarge": "Large",
		"DisplayBlocked": "Blocked Chat",
		"DisplayAsterisk": "Echo *",
		"DisplayNothing": "Echo nothing",
		"DisplayChatTime": "Chat Timestamps",
		"DisplayLobbyChatTime": "Extended lobby chat",
		"DisplayTableChatTime": "Extended table chat",
		"DisplayTime": "Time Format",
		"DisplayTime12": "12-hour",
		"DisplayTime24": "24-hour",
		"FilterBuyin": "Buy In",
		"FilterCL": "Cap Limit",
		"FilterCurrency": "Currency",
		"FilterEnabled": "Filter Enabled",
		"FilterFixed": "Fixed",
		"FilterFormat": "Format",
		"FilterFreezeout": "Freezeout",
		"FilterFull": "Hide full",
		"FilterGame": "Game",
		"FilterHoldem": "Hold'em",
		"FilterLimit": "Limit",
		"FilterMax": "Max",
		"FilterMin": "Min",
		"FilterMixed": "Mixed",
		"FilterNL": "No Limit",
		"FilterOmaha": "Omaha",
		"FilterOmahaHiLo": "Omaha Hi-Lo",
		"FilterOmahaX": "Omaha-X",
		"FilterOmahaXHiLo": "Omaha-X Hi-Lo",
		"FilterOther": "Other",
		"FilterPL": "Pot Limit",
		"FilterPlayers": "Players",
		"FilterPrimary": "Primary",
		"FilterPrivate": "Hide private",
		"FilterRazz": "Razz",
		"FilterRebuy": "Rebuy",
		"FilterReentry": "Re-Entry",
		"FilterReset": "Reset all",
		"FilterRunning": "Hide running",
		"FilterSeats": "Seats",
		"FilterSecondary": "Secondary",
		"FilterShootout": "Shootout",
		"FilterSize": "Table size",
		"FilterStakes": "Stakes",
		"FilterStarts": "Starts",
		"FilterStud": "Stud",
		"FilterStudHiLo": "StudHiLo",
		"FilterTime": "On time",
		"FilterTitleRing": "Ring Game Filter",
		"FilterTitleSitnGo": "Sit & Go Filter",
		"FilterTitleTourney": "Tournament Filter",
		"GameFinished": "Finished",
		"GameLevelTimer": "Level %1% - %2%",
		"GameNo": "No",
		"GameNone": "None",
		"GamePlayerRemoved": "Removed",
		"GamePlayersChoice": "Player's Choice",
		"GameSeconds": "%1% seconds",
		"GameYes": "Yes",
		"StatusStartsTime": "@ %1%",
		"HHDealt": "Dealt to %1% %2%",
		"HandHelper": "You have %1%",
		"HandHelperHiLo": "Hi: %1%  Lo: %2%",
		"HandRoyalFlush": "a Royal Flush",
		"HandStraightFlushLong": "a Straight Flush, %1% to %2%",
		"HandFourOfAKindLong": "Four of a Kind, %1% +%2%",
		"HandFullHouseLong": "a Full House, %1% full of %2%",
		"HandFlushLong": "a Flush, %1% high +%2%",
		"HandStraightLong": "a Straight, %1% to %2%",
		"HandThreeOfAKindLong": "Three of a Kind, %1% +%2%",
		"HandTwoPairLong": "Two Pair, %1% and %2% +%3%",
		"HandPairShort": "a Pair of %1%",
		"HandPairLong": "a Pair of %1% +%2%",
		"HandHighCardShort": "High Card %1%",
		"HandHighCardLong": "High Card %1% +%2%",
		"LobbyButtonExitFS": "Exit Fullscreen",
		"LobbyButtonChatExt": "Extended Lobby Chat",
		"LobbyButtonBalance": "Account Balance",
		"LobbyButtonSearch": "Player Search",
		"LobbyButtonNotes": "Player Notes",
		"LobbyButtonFilter": "Filter",
		"LobbyButtonLogin": "Login",
		"LobbyButtonLogout": "Logout",
		"LobbyButtonRingInfo": "Table Info",
		"LobbyButtonRingNext": "Next Table",
		"LobbyButtonRingObserve": "Observe Table",
		"LobbyButtonRingPlayers": "Players",
		"LobbyButtonRingPrev": "Previous Table",
		"LobbyButtonRingJoin": "Join Wait List",
		"LobbyButtonRingUnjoin": "Unjoin List",
		"LobbyButtonSnGInfo": "Sit & Go Info",
		"LobbyButtonSnGNext": "Next Sit & Go",
		"LobbyButtonSnGPrev": "Previous Sit & Go",
		"LobbyButtonTrnyInfo": "Tournament Info",
		"LobbyButtonTrnyNext": "Next Tournament",
		"LobbyButtonTrnyObserve": "Observe Table",
		"LobbyButtonTrnyPlayers": "Players",
		"LobbyButtonTrnyPrev": "Previous Tournament",
		"LobbyButtonTrnyRegister": "Register",
		"LobbyButtonTrnyRegLate": "Register Late",
		"LobbyButtonTrnyUnregister": "Unregister",
		"LobbyCaptionTitle": "Lobby",
		"LobbyCaptionTitleLogged": "Lobby - %1% logged in",
		"LobbyCaptionLogins": "Logins",
		"LobbyCaptionOpen": "Open Tables",
		"LobbyCaptionRingGames": "Ring Games",
		"LobbyCaptionTournaments": "Tournaments",
		"LobbyCaptionSitnGos": "Sit & Go's",
		"LobbyCaptionStartNow": "Start Now",
		"LobbyCaptionNoRingGame": "No ring game selected",
		"LobbyCaptionRunning": "%1%  (Running %2%)",
		"LobbyCaptionNoSitnGo": "No sit & go selected",
		"LobbyCaptionNoTournament": "No tournament selected",
		"LobbyCaptionMonth01": "Jan",
		"LobbyCaptionMonth02": "Feb",
		"LobbyCaptionMonth03": "Mar",
		"LobbyCaptionMonth04": "Apr",
		"LobbyCaptionMonth05": "May",
		"LobbyCaptionMonth06": "Jun",
		"LobbyCaptionMonth07": "Jul",
		"LobbyCaptionMonth08": "Aug",
		"LobbyCaptionMonth09": "Sep",
		"LobbyCaptionMonth10": "Oct",
		"LobbyCaptionMonth11": "Nov",
		"LobbyCaptionMonth12": "Dec",
		"LobbyCaptionAMTime": "%1% am",
		"LobbyCaptionPMTime": "%1% pm",
		"LobbyCaptionChat": "Lobby Chat",
		"LobbyCaptionSelect": "Select Table",
		"LobbyCaptionPlayers": "Players",
		"LobbyColumnLoginsPlayer": "Player",
		"LobbyColumnLoginsLocation": "Location",
		"LobbyColumnLoginsColor": "Color",
		"LobbyColumnLoginsNote": "Note",
		"LobbyColumnLoginsBlock": "Block",
		"LobbyColumnLoginsTime": "Login Time",
		"LobbyColumnRingID": "Ring Game ID",
		"LobbyColumnRingGame": "Game",
		"LobbyColumnRingStakes": "Stakes",
		"LobbyColumnRingBuyIn": "Buy In",
		"LobbyColumnRingSeats": "Seats",
		"LobbyColumnRingPlay": "Play",
		"LobbyColumnRingWait": "Wait",
		"LobbyColumnRingPlayer": "Player",
		"LobbyColumnRingChips": "Chips",
		"LobbyColumnRingNet": "Net",
		"LobbyColumnRingWaiting": "Waiting",
		"LobbyColumnSnGID": "Sit & Go ID",
		"LobbyColumnTrnyID": "Tournament ID",
		"LobbyColumnTrnyGame": "Game",
		"LobbyColumnTrnyBuyIn": "Buy In",
		"LobbyColumnTrnyTS": "TS",
		"LobbyColumnTrnyReg": "Reg",
		"LobbyColumnTrnyStarts": "Starts \/ Status",
		"LobbyColumnTrnyPlayer": "Player",
		"LobbyColumnTrnyTable": "Table",
		"LobbyColumnTrnyChips": "Chips",
		"LobbyColumnTrnyRank": "Rank",
		"LobbyColumnTrnyWaiting": "Waiting",
		"LobbyMenuLobby": "Lobby",
		"LobbyMenuAccount": "Account",
		"LobbyMenuOptions": "Options",
		"LobbyMenuHelp": "Help",
		"LobbyMenuTable": "Table",
		"LobbyMenuAccountLogin": "Login...",
		"LobbyMenuAccountLogout": "Logout",
		"LobbyMenuAccountCreate": "Create...",
		"LobbyMenuAccountChange": "Change info...",
		"LobbyMenuAccountBalance": "Show balance...",
		"LobbyMenuAccountTickets": "Show tickets...",
		"LobbyMenuAccountPerm": "Show permissions...",
		"LobbyMenuAccountTransfer": "Transfer chips...",
		"LobbyMenuAccountTransfer1": "Transfer primary chips...",
		"LobbyMenuAccountTransfer2": "Transfer secondary chips...",
		"LobbyMenuAccountRequest": "Request more chips",
		"LobbyMenuAccountRequest1": "Request more primary chips",
		"LobbyMenuAccountRequest2": "Request more secondary chips",
		"LobbyMenuAccountSuspend": "Suspend...",
		"LobbyMenuAccountCustom": "Custom...",
		"LobbyMenuWindowSize": "Default window size",
		"LobbyMenuLobbyExit": "Logout \/ Exit",
		"LobbyMenuOptionsFullScreen": "Fullscreen toggle",
		"LobbyMenuOptionsNoFullScreen": "Fullscreen toggle not supported on this device",
		"LobbyMenuOptionsLanguage": "Language...",
		"LobbyMenuOptionsArrange": "Arrange windows...",
		"LobbyMenuOptionsSound": "Sound effects...",
		"LobbyMenuOptionsTable": "Table settings...",
		"LobbyMenuOptionsDisplay": "Display settings...",
		"LobbyMenuOptionsStart": "Start game...",
		"LobbyMenuOptionsPause": "Pause\/Resume ring game...",
		"LobbyMenuOptionsSearch": "Player search",
		"LobbyMenuOptionsNotes": "Player notes...",
		"LobbyMenuHelpContact": "Contact site administrator...",
		"LobbyMenuHelpNews": "View site news...",
		"LobbyMenuHelpFAQ": "View site FAQ...",
		"LobbyMenuHelpAbout": "About",
		"LoginTitle": "Login",
		"LoginName": "Player Name:",
		"LoginPassword": "Password:",
		"LoginRemember": "Remember Password",
		"LoginAccount": "Create New Account",
		"LoginResetPW": "Reset My Password",
		"LoginResendVC": "Resend Validation Code",
		"LoginValCode": "Validation Code:",
		"LoginNoName": "No player name entered",
		"MessageRingGameLogin": "You must login before requesting a seat",
		"MessageTournamentLogin": "You must login before registering",
		"MessageChatLogin": "You must login before using chat feature",
		"MessageChatPlayer": "No player selected",
		"MessageChatBlock": "Cannot block your own chat",
		"MessageTerminated": "Connection terminated by Administrator",
		"MessageRingGameTab": "Ring Game tab not selected",
		"MessageTournamentTab": "Tournament tab not selected",
		"MessageConfirmFold": "You can check this bet. Do you really want to fold?",
		"MessageConfirmLeave": "You will be placed in Sitting Out mode until you return or are blinded out of the tournament. Are you sure you want to leave?",
		"MessageConfirmResign": "Do you want to surrender your chip stack and leave this tournament after hand completes?",
		"MessageNotSeated": "You are not currently seated at this table",
		"MessageNoSave": "Save function not available in web app mode",
		"MessageReplayNoHands": "No hands played",
		"NoteBlockChat": "Block Chat",
		"NoteBlock": "Block",
		"NoteColor": "Color",
		"NoteDelete": "Delete",
		"NoteEdit": "Edit",
		"NoteEditLabel": "Edit Label",
		"NoteLabel": "Label",
		"NoteNone": "none",
		"NoteNote": "Note",
		"NotePlayer": "Player",
		"NoteTitle": "Player Notes",
		"PasswordTitle": "Private Game",
		"PasswordPrompt": "Password for %1%:",
		"PasswordBad": "Password is incorrect for %1%",
		"PauseCodeTitle": "Pause\/Resume Code:",
		"PlayerActionAddOn": "Add-on",
		"PlayerActionAllIn": "All-in",
		"PlayerActionBet": "Bet",
		"PlayerActionBlind": "Post Blind",
		"PlayerActionBringIn": "Bring in",
		"PlayerActionCall": "Call",
		"PlayerActionCheck": "Check",
		"PlayerActionFold": "Fold",
		"PlayerActionAnte": "Post Ante",
		"PlayerActionBB": "Post BB",
		"PlayerActionSB": "Post SB",
		"PlayerActionSBBB": "Post SB+BB",
		"PlayerActionRaise": "Raise",
		"PlayerActionRebuy": "Rebuy",
		"PlayerActionReserved": "Reserved",
		"PlayerActionSit": "Sitting Out",
		"PlayerActionStraddle": "Straddle",
		"PlayerActionWait": "Wait for BB",
		"PlayerProfile": "Show Profile",
		"PlayerNotes": "Notes",
		"PlayerSearch": "Search",
		"SearchTitle": "Player Search",
		"SearchName": "Player Name:",
		"ReplayTitle": "Replay",
		"ReplayPots": "Pots:",
		"ReplayTotal": "Total:",
		"ReplayRake": "Rake:",
		"ReplayRabbit": "Show rabbit hunt cards",
		"ReservedDealer": "Dealer",
		"ReservedSystem": "System",
		"RotateTitle": "Rotate Seats",
		"RotateStatus": "Rotate Status: %1%",
		"RotateHere": "Rotate Here",
		"RotateCW": "Clockwise (+1)",
		"RotateCCW": "Counterclockwise (-1)",
		"RotateReset": "Reset",
		"H6Caption": "6+Hold'em Rules",
		"H6Rule1": "* Deuces to fives removed from card deck",
		"H6Rule2": "* Flush beats a full house",
		"H6Rule3": "* Low straight is A6789",
		"H6Rule4": "* Every player posts an ante",
		"H6Rule5": "* Only button player posts a blind",
		"H6NoShow": "Don't show this again",
		"NewsTitle": "News",
		"FAQTitle": "Frequently Asked Questions",
		"SoundTitle": "Sound Effects",
		"SoundBeep": "Beep sounds",
		"SoundBet": "Bet sounds",
		"SoundCard": "Card sounds",
		"SoundCheck": "Check sounds",
		"SoundPot": "Pot sounds",
		"SoundLogin": "Login sounds",
		"SoundVolume": "Sound volume:",
		"StartCodeTitle": "Start Code:",
		"SuspendTitle": "Suspend My Account",
		"SuspendText": "<b>WARNING:<\/b> this function implements a self-imposed suspension of your account, preventing you from logging in again until the specified time period has elapsed. The suspension will go into effect immediately after you log out.",
		"SuspendDays": "Days",
		"SuspendHours": "Hours",
		"SuspendMinutes": "Minutes",
		"TableButtonBBx": "%1%bb",
		"TableButtonPot": "Pot",
		"TableButtonMin": "Min",
		"TableButtonMax": "Max",
		"TableButtonFold": "Fold",
		"TableButtonCheck": "Check",
		"TableButtonCall": "Call %1%",
		"TableButtonBring": "Bring in %1%",
		"TableButtonBet": "Bet %1%",
		"TableButtonRaise": "Raise to %1%",
		"TableButtonTime": "Request Time: %1%",
		"TableButtonWait": "Wait for BB",
		"TableButtonReady": "Ready",
		"TableButtonStart": "Start Now",
		"TableButtonMuck": "Muck Cards",
		"TableButtonShow": "Show Cards",
		"TableButtonLeave": "Leave",
		"TableButtonRebuy": "Rebuy",
		"TableButtonDoubleRebuy": "Double Rebuy",
		"TableButtonSitout": "Sitout",
		"TableButtonAddChips": "Add Chips",
		"TableButtonChat": "Enter Chat",
		"TableButtonPrev": "Previous",
		"TableButtonNext": "Next",
		"TableButtonOnce": "Run It Once",
		"TableButtonTwice": "Run It Twice",
		"TableCaptionTable": "Table",
		"TableCaptionLoggedIn": "Logged in as %1%",
		"TableCaptionFoldAnyBet": "Fold to any bet",
		"TableCaptionAwayHand": "Sit out next hand",
		"TableCaptionAwayBlind": "Sit out next blind",
		"TableCaptionChatText": "Chat text:",
		"TableCaptionNextCallAny": "Call Any",
		"TableCaptionNextCallAnyCheck": "Call Any \/ Check",
		"TableCaptionNextCheckFold": "Check \/ Fold",
		"TableCaptionNextCheck": "Check",
		"TableCaptionNextFold": "Fold",
		"TableCaptionNextCall": "Call",
		"TableCaptionShowChat": "Show Chat",
		"TableCaptionShowStats": "Show Statistics",
		"TableCaptionStatistics": "Statistics",
		"TableCaptionStraddle": "Straddle",
		"TableCaptionTime": "Time:",
		"TableCaptionTotal": "Total",
		"TableCaptionRake": "Rake: %1%",
		"TableCaptionRunTwice": "Run it twice",
		"TableCaptionFlipCards": "Click your avatar to turn cards over",
		"InfoTitle": "Information",
		"InfoGeneral": "Info",
		"InfoChat": "Chat",
		"InfoStats": "Stats",
		"InfoHistory": "History",
		"InfoMoveChat": "Move table chat here",
		"InfoSuspendChat": "Chat is suspended when a player is all-in",
		"InfoHistoryOf": "%1% of %2%",
		"TableMenuChatInfo": "Extended chat \/ info",
		"TableMenuAddChips": "Add more chips",
		"TableMenuRefresh": "Refresh table",
		"TableMenuRotate": "Rotate seats",
		"TableMenuReplay": "Replay hand summary",
		"TableMenuWindowSize": "Default window size",
		"TableMenuSettings": "Lobby -> Table Settings",
		"TableMenuLeave": "Leave",
		"TableMenuLeaveSeat": "Leave seat",
		"TableMenuLeaveTable": "Leave table",
		"TableMenuLeaveTourney": "Leave tournament",
		"TableMenuHeaderAnte": "Ante",
		"TableMenuHeaderBlinds": "Blinds",
		"TableMenuHeaderHand": "Hand",
		"TableMenuHeaderStakes": "Stakes",
		"TableMessageMixed": "New Mixed Game",
		"TableSettingsTitle": "Table Settings",
		"TableSettingsFront": "Bring active table to front",
		"TableSettingsSeat": "Remember preferred seat",
		"TableSettingsHandHelper": "Display hand helper",
		"TableSettingsAutoMuck": "Auto muck",
		"TableSettingsFourColor": "Four-color deck",
		"TableSettingsFaceDown": "Deal cards face down",
		"TableSettingsMuteDealer": "Mute dealer chat",
		"TableSettings6Holdem": "Show 6+Hold'em rules",
		"TableSettingsPreFlopBtns": "Pre-flop bet buttons",
		"TableSettingsPostFlopBtns": "Post-flop bet buttons",
		"TableSettingsResetBtns": "Reset all",
		"TransactionsTitle": "Transactions",
		"TransactionsDays": "Days:",
		"TransactionsRefresh": "Refresh",
		"TransactionsLoading": "Loading...",
		"TransactionsRecords": "Records:",
		"TransactionsDate": "Date",
		"TransactionsCurrency": "Currency",
		"TransactionsChange": "Change",
		"TransactionsBalance": "Balance",
		"TransactionsSource": "Source",
		"TransactionsPrimary": "Primary",
		"TransactionsSecondary": "Secondary",
		"TransactionsTicket": "Ticket",
		"TransferTitle": "Transfer Chips",
		"TransferTitle1": "Transfer Primary Chips",
		"TransferTitle2": "Transfer Secondary Chips",
		"TransferChips": "Chips:",
		"TransferRecipient": "Recipient:",
		"ValCodeMsg1": "Resend validation code to the email address on file for this account?",
		"ValCodeMsg2": "Request a password change validation code be sent to the email address on file for this account?"
	}
	
	
module.exports = deec;